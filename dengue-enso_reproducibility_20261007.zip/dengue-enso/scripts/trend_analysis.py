# -*- coding: utf-8 -*-
"""
Task 5: Trend tests on dengue epidemic-season windows (China).

For each province x threshold x season-window metric (onset / offset / length /
peak) computes:
  * Mann-Kendall trend test (tau, p, with tie correction)
  * Sen's slope (median of pairwise slopes, in months per year)
  * piecewise / segmented regression breakpoint (scan break in 2..(n-2),
    keep the one minimising residual sum of squares; F-test p<=0.05 gate)

Two analysis periods are reported:
  * 2012-2024  (main calibration - the WHO-WPRO weekly-report series,
                data-consistent source)
  * 2008-2024  (adds the two low-case early years 2008-2009)

Provinces with n_years < 3 within a period are dropped (too few points for a
trend; documented in the task report).

Inputs (read-only):  data/processed/windows.csv   (Task 4 output)
Outputs:
  results/trends.csv           province,threshold,metric,mk_tau,mk_p,
                               sen_slope_yr,breakpoint_year,breakpoint_p,
                               n_years,period
  figures/trend_length.png     per-province length vs year scatter + Sen line
                               + breakpoint (two periods in different colours)
"""
import os
import sys
import itertools

import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
import numpy as np
import pandas as pd
from scipy import stats

# CJK font for Chinese labels in figures (Windows)
from matplotlib import font_manager
for _f in ["Microsoft YaHei", "SimHei", "SimSun"]:
    try:
        font_manager.findfont(_f, fallback_to_default=False)
        plt.rcParams["font.sans-serif"] = [_f, "DejaVu Sans"]
        plt.rcParams["axes.unicode_minus"] = False
        break
    except Exception:
        continue

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
PROC = os.path.join(ROOT, "data", "processed")
RES = os.path.join(ROOT, "results")
FIG = os.path.join(ROOT, "figures")

IN_WINDOWS = os.path.join(PROC, "windows.csv")
OUT_TRENDS = os.path.join(RES, "trends.csv")
OUT_FIG = os.path.join(FIG, "trend_length.png")

# Provinces that carry a usable season-window trend series. 云南/浙江/福建
# have <=1 valid window year and 广西/海南 have none -> excluded from trending
# (documented in the report).  全国 & 广东 are the main analysis units.
ANALYZED_PROVINCES = ["全国", "广东"]

THRESHOLDS = ["(0.05,0.95)", "(0.01,0.99)", "(0.10,0.90)"]

# metric -> column in windows.csv
METRIC_COLS = {
    "onset": "onset_month",
    "offset": "offset_month",
    "length": "length_months",
    "peak": "peak_month",
}

# period label -> (min_year, max_year) inclusive
PERIODS = [
    ("2012-2024", 2012, 2024),   # main calibration period
    ("2008-2024", 2008, 2024),   # adds early low-case years 2008/2009
]

MIN_N = 3          # minimum observations for a trend to be reported
F_ALPHA = 0.05     # breakpoint significance gate


def mann_kendall(x):
    """Mann-Kendall trend test with tie (variance) correction.

    x: 1-D numpy array of observations (sorted chronologically), no NaN.
    Returns (tau, p_two_sided).
    """
    x = np.asarray(x, dtype=float)
    n = len(x)
    if n < 2:
        return (np.nan, np.nan)
    s = 0.0
    for i in range(n - 1):
        s += np.sign(x[i + 1:] - x[i]).sum()
    # tie groups on sorted values
    ties = [len(list(g)) for _, g in itertools.groupby(np.sort(x))]
    var_s = (n * (n - 1) * (2 * n + 5) -
             sum(t * (t - 1) * (2 * t + 5) for t in ties)) / 18.0
    if var_s <= 0:                     # all ties -> no trend
        return (0.0, 1.0)
    z = (s - np.sign(s) * 0.5) / np.sqrt(var_s)
    p = 2.0 * (1.0 - stats.norm.cdf(abs(z)))
    tau = s / (n * (n - 1) / 2.0)
    return (tau, p)


def sen_slope(x, y):
    """Sen's slope = median of all pairwise slopes (y vs x), units = y/x."""
    x = np.asarray(x, dtype=float)
    y = np.asarray(y, dtype=float)
    n = len(x)
    slopes = [(y[j] - y[i]) / (x[j] - x[i])
              for i in range(n)
              for j in range(i + 1, n)
              if x[j] != x[i]]
    if not slopes:
        return np.nan
    return float(np.median(slopes))


def piecewise_seg(x, y, k):
    """Two-piece linear fit at a fixed split index k (left x[:k], right x[k:]).

    Returns (residual_sum_squares). Each side must have >=2 points.
    """
    x = np.asarray(x, dtype=float)
    y = np.asarray(y, dtype=float)
    rss = 0.0
    for lo, hi in ((0, k), (k, len(x))):
        xs, ys = x[lo:hi], y[lo:hi]
        A = np.vstack([xs, np.ones_like(xs)]).T
        coef, _, _, _ = np.linalg.lstsq(A, ys, rcond=None)
        pred = A @ coef
        rss += float(((ys - pred) ** 2).sum())
    return rss


def breakpoint_test(x, y):
    """Segmented-regression breakpoint scan on x (years), y (metric).

    Scans split k in 2..(n-2), chooses the split with minimum RSS; runs an
    F-test against the single-line model. Returns
    (breakpoint_year, breakpoint_p): (NaN, NaN) when no significant break.
    """
    x = np.asarray(x, dtype=float)
    y = np.asarray(y, dtype=float)
    n = len(x)
    if n < 4:
        return (np.nan, np.nan)
    # single-line RSS (reduced model)
    A = np.vstack([x, np.ones_like(x)]).T
    coef, _, _, _ = np.linalg.lstsq(A, y, rcond=None)
    pred = A @ coef
    rss_single = float(((y - pred) ** 2).sum())

    best_k, best_rss = None, np.inf
    for k in range(2, n - 1):          # each side keeps >=2 points
        rss = piecewise_seg(x, y, k)
        if rss < best_rss:
            best_rss, best_k = rss, k

    # F-test: full model adds one intercept and one slope (2 df)
    df_reduced = n - 2
    df_full = n - 4
    num_df = df_reduced - df_full          # 2
    den_df = df_full
    f_stat = ((rss_single - best_rss) / num_df) / (best_rss / den_df)
    p = 1.0 - stats.f.cdf(f_stat, num_df, den_df)
    if p <= F_ALPHA and best_rss < rss_single:
        # breakpoint year = first year of the second segment (year at index k)
        return (float(x[best_k]), float(p))
    return (np.nan, np.nan)


def load_windows():
    df = pd.read_csv(IN_WINDOWS, encoding="utf-8-sig")
    # numeric coercion for metrics (NaN where undefined)
    for col in METRIC_COLS.values():
        df[col] = pd.to_numeric(df[col], errors="coerce")
    return df


def build_trends(df):
    rows = []
    for prov in ANALYZED_PROVINCES:
        sub = df[df["province"] == prov]
        for thr in THRESHOLDS:
            thr_sub = sub[sub["threshold"] == thr]
            for metric, col in METRIC_COLS.items():
                for period, y0, y1 in PERIODS:
                    in_period = thr_sub[
                        thr_sub["year"].between(y0, y1)].sort_values("year")
                    valid = in_period.dropna(subset=[col])
                    n_years = len(valid)
                    if n_years < MIN_N:
                        # too few points for a trend -> not reported
                        continue
                    yrs = valid["year"].to_numpy(dtype=float)
                    vals = valid[col].to_numpy(dtype=float)
                    tau, p = mann_kendall(vals)
                    slope = sen_slope(yrs, vals)
                    bp_year, bp_p = breakpoint_test(yrs, vals)
                    rows.append({
                        "province": prov,
                        "threshold": thr,
                        "metric": metric,
                        "mk_tau": round(float(tau), 4),
                        "mk_p": round(float(p), 5),
                        "sen_slope_yr": round(slope, 4),
                        "breakpoint_year": bp_year,
                        "breakpoint_p": bp_p,
                        "n_years": n_years,
                        "period": period,
                    })
    return pd.DataFrame(rows)


def plot_trend_length(df, window_df):
    os.makedirs(FIG, exist_ok=True)
    main_thr = "(0.05,0.95)"
    colors = {"2012-2024": "#1783FF", "2008-2024": "#F0884D"}
    nprov = len(ANALYZED_PROVINCES)
    fig, axes = plt.subplots(nprov, 1, figsize=(11, 3.4 * nprov), sharex=True)
    if nprov == 1:
        axes = [axes]
    for ax, prov in zip(axes, ANALYZED_PROVINCES):
        sub = window_df[(window_df["province"] == prov) &
                        (window_df["threshold"] == main_thr)]
        valid = sub.dropna(subset=["length_months"]).sort_values("year")
        if not valid.empty:
            ax.scatter(valid["year"], valid["length_months"],
                       color="0.35", s=45, zorder=3, label="length (5–95%)",
                       edgecolors="white")
        # 广东 has no window inside 2008-2024 / 2012-2024 -> use its full
        # 1998-2008 span so the subplot is informative
        if prov == "广东" and not valid.empty:
            years = valid["year"].to_numpy(dtype=float)
            lens = valid["length_months"].to_numpy(dtype=float)
            slope = sen_slope(years, lens)
            xs = np.array([years.min(), years.max()], dtype=float)
            ys = slope * (xs - years[0]) + lens[0]
            ax.plot(xs, ys, color="#60C42D", lw=2.0, ls="-",
                    label=f"1998–2008 Sen: {slope:+.2f} mo/yr")
            continue
        # Sen trend lines per period + breakpoints
        for period, y0, y1 in PERIODS:
            in_period = valid[valid["year"].between(y0, y1)]
            years = in_period["year"].to_numpy(dtype=float)
            lens = in_period["length_months"].to_numpy(dtype=float)
            if len(years) < MIN_N:
                continue
            slope = sen_slope(years, lens)
            xs = np.array([years.min(), years.max()], dtype=float)
            ys = slope * (xs - years[0]) + lens[0]
            label = f"{period} Sen: {slope:+.2f} mo/yr"
            lw = 2.6 if period == "2012-2024" else 1.8
            ls = "-" if period == "2012-2024" else "--"
            ax.plot(xs, ys, color=colors[period], lw=lw, ls=ls,
                    label=label if len(lens) >= MIN_N else None)
            bp_year, bp_p = breakpoint_test(years, lens)
            if not np.isnan(bp_year):
                ax.axvline(bp_year, color=colors[period], lw=1.5, ls=":",
                           alpha=0.8)
                ax.annotate(f"bp {bp_year:.0f} (p={bp_p:.2f})",
                            xy=(bp_year, ax.get_ylim()[1] * 0.95),
                            xytext=(bp_year + 0.4, ax.get_ylim()[1] * 0.8),
                            fontsize=8, color=colors[period])
        ax.set_ylabel(f"{prov}\nlength (months)", rotation=0, ha="right",
                      va="center", fontsize=9)
        ax.grid(axis="y", alpha=0.3)
        ax.legend(loc="upper left", fontsize=8, frameon=False)
    axes[0].set_title("Dengue epidemic window length vs year "
                      "(MK+Sen + segmented breakpoint)")
    axes[-1].set_xlabel("Year")
    fig.tight_layout()
    fig.savefig(OUT_FIG, dpi=200)
    plt.close(fig)
    print(f"[wrote] {OUT_FIG}")


def run_assertions(trends):
    ok = True
    if trends.empty:
        print("[FAIL] trends.csv is empty")
        ok = False
    if not np.all((trends["mk_p"] >= 0) & (trends["mk_p"] <= 1)):
        print("[FAIL] mk_p out of [0,1]")
        ok = False
    if not np.all((trends["mk_tau"] >= -1) & (trends["mk_tau"] <= 1)):
        print("[FAIL] mk_tau out of [-1,1]")
        ok = False
    # no fully-NaN result rows: every reported row has real MK+Sen
    res_cols = ["mk_tau", "mk_p", "sen_slope_yr", "breakpoint_year",
                "breakpoint_p"]
    all_nan = trends[res_cols].isna().all(axis=1)
    if all_nan.any():
        print(f"[FAIL] {int(all_nan.sum())} all-NaN result rows")
        ok = False
    if ok:
        print(f"[PASS] trends {len(trends)} rows")
    return ok


def main():
    print("=" * 60)
    print("Step 1: input assertions")
    for f in [IN_WINDOWS]:
        if not os.path.exists(f):
            print(f"[FAIL] missing {f}")
            return 1
    w = load_windows()
    EXPECTED_COLS = ["province", "year", "threshold", "onset_month",
                     "offset_month", "length_months", "peak_month",
                     "n_months", "incomplete", "note"]
    missing = [c for c in EXPECTED_COLS if c not in w.columns]
    if missing:
        print(f"[FAIL] windows.csv missing columns: {missing}")
        return 1
    n_valid = int(w.dropna(subset=["onset_month"]).shape[0])
    print(f"  windows loaded: {len(w)} rows ({n_valid} valid windows)")

    print("=" * 60)
    print("Step 2: Mann-Kendall + Sen + breakpoint per province x threshold")
    print("        x metric x period")
    trends = build_trends(w)
    os.makedirs(RES, exist_ok=True)
    trends.to_csv(OUT_TRENDS, index=False, encoding="utf-8-sig")
    print(f"[wrote] {OUT_TRENDS} ({len(trends)} rows)")
    if not trends.empty:
        print(trends[["province", "threshold", "metric", "period", "n_years",
                      "mk_tau", "mk_p", "sen_slope_yr"]].to_string(index=False))

    print("=" * 60)
    print("Step 3: figure")
    plot_trend_length(trends, w)

    print("=" * 60)
    print("Step 4: output assertions")
    ok = run_assertions(trends)
    print("\nDONE. ok =", ok)
    return 0 if ok else 1


if __name__ == "__main__":
    sys.exit(main())
