# -*- coding: utf-8 -*-
"""
Shared sensitivity-analysis scenario definitions for Tasks 7a (trend
robustness) and 7b (attribution robustness). Both branches import this module
so the scenario matrix stays consistent (project-structure.md §4.4).

Scenarios (each = a row filter applied on top of the base analysis):
  1. drop_covid      : exclude 2020 and 2021 (COVID-disrupted reporting)
  2. drop_outbreak   : exclude local outbreak years (2014 national 3SD outbreak)
  3. national_only   : national series only (no province rows) - used to check
                       that province rows don't change national conclusions
  4. swap_threshold  : use the (0.01, 0.99) threshold results instead of
                       (0.05, 0.95) as the main definition (threshold swap)
"""
import os

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
PROC = os.path.join(ROOT, "data", "processed")

WINDOWS_CSV = os.path.join(PROC, "windows.csv")
CLEAN_CSV = os.path.join(PROC, "dengue_china_clean.csv")

# years to drop in the drop_covid scenario
COVID_YEARS = [2020, 2021]

# national-level 3SD outbreak years within the 2004-2024 window (from T3)
OUTBREAK_YEARS = [2014]

# main threshold pair and the swap threshold pair
MAIN_THRESHOLD = "(0.05,0.95)"
SWAP_THRESHOLD = "(0.01,0.99)"

# analysis period for trend (main口径 2012-2024; 2008-2009 included as
# sensitivity because of low-case instability)
MAIN_PERIOD = (2012, 2024)
EARLY_PERIOD = (2008, 2024)

SCENARIOS = {
    "drop_covid": {"drop_years": COVID_YEARS},
    "drop_outbreak": {"drop_years": OUTBREAK_YEARS},
    "national_only": {"provinces": ["全国"]},
    "swap_threshold": {"threshold": SWAP_THRESHOLD},
}


def scenario_key(scene):
    return {
        "drop_covid": "剔除COVID年(2020-2021)",
        "drop_outbreak": "剔除暴发年(2014)",
        "national_only": "仅全国序列",
        "swap_threshold": "阈值互换(1-99)",
    }[scene]
