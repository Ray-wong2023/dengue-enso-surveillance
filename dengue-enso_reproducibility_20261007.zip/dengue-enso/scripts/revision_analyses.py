"""Review sensitivities; preserve the frozen inputs and primary analyses."""
from pathlib import Path
import numpy as np
import pandas as pd
from scipy import stats
import statsmodels.api as sm
from global_loo_country import unit_effects, dl_pool

ROOT = Path(__file__).resolve().parents[1]
RES = ROOT / 'results'
THR = '(0.05,0.95)'


def write(df, name):
    df.to_csv(RES / name, index=False, encoding='utf-8-sig')


def clustered_pool(effects, stratum, definition):
    base = dl_pool(effects.slope, effects.se)
    weights = 1 / (effects.se.to_numpy() ** 2 + base['tau2'])
    fit = sm.WLS(effects.slope.to_numpy(), np.ones((len(effects), 1)),
                 weights=weights).fit(cov_type='cluster',
                 cov_kwds={'groups': effects.country.to_numpy(), 'use_correction': True},
                 use_t=True)
    lo, hi = fit.conf_int()[0]
    return dict(stratum=stratum, definition=definition, n_units=len(effects),
                n_clusters=effects.country.nunique(), slope=fit.params[0],
                ci_lo=lo, ci_hi=hi, p=fit.pvalues[0],
                inference='country-cluster sandwich; t(G-1); fixed DL weights')


def main():
    w = pd.read_csv(RES / 'global_windows.csv')
    w = w[(w.threshold == THR) & (w.complete12 == 1)].dropna(subset=['length_months'])
    effects = unit_effects(w, 'length_months')
    rows = []
    for minimum in (10, 20, 25):
        e = effects[effects.n >= minimum]
        rows.append(clustered_pool(e, f'n_ge_{minimum}', 'calendar_5_95'))
    write(pd.DataFrame(rows), 'revision_country_cluster.csv')

    # Circular diagnostic: shortest consecutive arc containing >=90% of cases.
    # At most one wrap, complete observed months; no imputation of missing months.
    um = pd.read_csv(RES / 'global_unit_month.csv')
    um['month'] = pd.to_datetime(um.ym).dt.month
    circular = []
    for (unit, year), g in um.groupby(['unit', 'yr']):
        if g.month.nunique() != 12 or g.dengue_total.sum() < 30:
            continue
        a = g.set_index('month').dengue_total.reindex(range(1, 13)).to_numpy(float)
        aa = np.tile(a, 2)
        length = min(next(k for k in range(1, 13)
                          if aa[start:start+k].sum() >= .9 * a.sum() - 1e-9)
                     for start in range(12))
        circular.append(dict(unit=unit, country=g.country.iloc[0], year=year,
                             circular_length=length))
    circ = pd.DataFrame(circular)
    write(circ, 'revision_circular_windows.csv')
    ce = unit_effects(circ, 'circular_length')
    comparisons = []
    for minimum in (10, 20):
        ids = effects.loc[effects.n >= minimum, 'unit']
        e = ce[ce.unit.isin(ids)]
        pooled = dl_pool(e.slope, e.se)
        comparisons.append(dict(stratum=f'n_ge_{minimum}', definition='shortest_90pct_arc',
                                **pooled, n_countries=e.country.nunique()))
        rows.append(clustered_pool(e, f'n_ge_{minimum}', 'shortest_90pct_arc'))
        med = w.groupby('unit').length_months.median()
        below = effects[effects.unit.isin(ids) & effects.unit.map(med).lt(11)]
        pooled2 = dl_pool(below.slope, below.se)
        if pooled2:
            comparisons.append(dict(stratum=f'n_ge_{minimum}',
                                    definition='calendar_median_below_11', **pooled2,
                                    n_countries=below.country.nunique()))
    write(pd.DataFrame(rows), 'revision_country_cluster.csv')
    write(pd.DataFrame(comparisons), 'revision_window_sensitivity.csv')

    annual = pd.read_csv(RES / 'global_unit_temp_annual.csv')
    associations = []
    detail = []
    for unit, g in w.groupby('unit'):
        paired = g.merge(annual[['unit', 'year', 'months_ge21']], on=['unit', 'year'])
        if len(paired) < 10:
            continue
        l = stats.linregress(paired.year, paired.length_months)
        t = stats.linregress(paired.year, paired.months_ge21)
        detail.append(dict(unit=unit, country=g.country.iloc[0], n=len(paired),
                           length_slope=l.slope, suitable_slope=t.slope))
    detail = pd.DataFrame(detail)
    write(detail, 'revision_suitable_trend_units.csv')
    for minimum in (10, 20):
        g = detail[detail.n >= minimum]
        rho, p = stats.spearmanr(g.length_slope, g.suitable_slope)
        associations.append(dict(stratum=f'n_ge_{minimum}', n_units=len(g),
                                 n_countries=g.country.nunique(), rho=rho, p=p,
                                 inference='descriptive Spearman; nominal p; nested units'))
    write(pd.DataFrame(associations), 'revision_suitable_trend_association.csv')
    for r in rows:
        print(r)
    print(pd.DataFrame(comparisons).to_string(index=False))
    print(pd.DataFrame(associations).to_string(index=False))


if __name__ == '__main__':
    main()
