# -*- coding: utf-8 -*-
"""
Task 6: Temperature attribution for epidemic season windows + simplified DLNM.

Panel / time-series attribution of season-window metrics (length / onset /
offset) to temperature indicators (annual mean, spring mean, months >= 21 C),
and a simplified distributed-lag (Almon polynomial, degree 3, lags 0-3)
quasi-Poisson model of national monthly temperature -> national monthly cases.

Temperature matching:
  * 全国  uses the mean of the 8-city monthly tmean (Guangzhou, Shenzhen,
    Nanning, Kunming, Fuzhou, Haikou, Xiamen, Hangzhou).
  * 广东  uses Guangzhou (Guangzhou) tmean.
  * Window years 1998-2001 (no temperature coverage; temp starts 2004) and
    2002-2007, 2010-2011 (no monthly case coverage) are unusable for attribution.

Main attribution: national (2008, 2009, 2013-2019, 2023-2024 valid window
years within temperature coverage). Auxiliary: Guangdong (only 2008 has a
valid window within temperature coverage -> too few points -> NaN rows in
attribution.csv, explained in the report).

Inputs:
  data/processed/windows.csv
  data/raw/temperature_cities.csv
  data/processed/dengue_china_clean.csv   (for DLM national monthly cases)

Outputs:
  results/attribution.csv      province, metric, predictor, model, coef, se, p, r2, n_years
  results/distributed_lag.csv  lag, coef, se, p, ci_low, ci_high
  figures/temp_window_scatter.png
  figures/lag_curve.png
  docs/superpowers/plans/task-6-report.md
"""
import os
import sys

import numpy as np
import pandas as pd
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
from scipy import stats
import statsmodels.formula.api as smf
from statsmodels.genmod.generalized_linear_model import GLM
from statsmodels.genmod.families import NegativeBinomial

# CJK font for Chinese labels in figures (Windows)
from matplotlib import font_manager
for _f in ["Microsoft YaHei", "SimHei", "SimSun"]:
    try:
        font_manager.findfont(_f, fallback_to_default=False)
        plt.rcParams["font.sans-serif"] = [_f, "DejaVu Sans"]
        plt.rcParams["axes.unicode_minus"] = False
        break
    except Exception:
        continue

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
PROC = os.path.join(ROOT, "data", "processed")
RAW = os.path.join(ROOT, "data", "raw")
RES = os.path.join(ROOT, "results")
FIG = os.path.join(ROOT, "figures")
DOC = os.path.join(ROOT, "docs", "superpowers", "plans")

IN_WINDOWS = os.path.join(PROC, "windows.csv")
IN_TEMP = os.path.join(RAW, "temperature_cities.csv")
IN_CLEAN = os.path.join(PROC, "dengue_china_clean.csv")

OUT_ATTR = os.path.join(RES, "attribution.csv")
OUT_LAG = os.path.join(RES, "distributed_lag.csv")
OUT_SCATTER = os.path.join(FIG, "temp_window_scatter.png")
OUT_LAGCURVE = os.path.join(FIG, "lag_curve.png")
OUT_REPORT = os.path.join(DOC, "task-6-report.md")

DEFAULT_THRESHOLD = "(0.05,0.95)"       # primary window definition
MIN_YEARS = 4                            # min province-years to report estimates (else NaN)
COVID_YEARS = {2020, 2021}               # DLM: drop COVID reporting-disruption years
INCOMPLETE_YEARS = {2022}                # national months incomplete (Nov-Dec missing)

# national temperature = mean over these 8 cities
NATIONAL_CITIES = ["广州", "深圳", "南宁", "昆明", "福州", "海口", "厦门", "杭州"]
# south-China subset (alternative, reported but not the primary choice)
SOUTH_CITIES = ["广州", "深圳", "南宁", "海口", "厦门"]
GUANGDONG_CITY = "广州"

METRICS = ["length_months", "onset_month", "offset_month"]
PRED_M1 = [("m1_annual", "annual_temp")]
PRED_M2 = [("m2_spring+suitable", "spring_temp"),
           ("m2_spring+suitable", "suitable_months")]

SUITABLE_T = 21.0   # >= 21 C marks a mosquito-suitable month (Dengue suitability lit.)
SPRING_MONTHS = [3, 4, 5]


# --------------------------------------------------------------------------
# temperature indicators
# --------------------------------------------------------------------------
def build_national_monthly_tmean():
    """National monthly tmean as the city-mean of tmean for each (year, month)."""
    temp = pd.read_csv(IN_TEMP, encoding="utf-8-sig")
    cities = temp[temp["city"].isin(NATIONAL_CITIES)].copy()
    g = cities.groupby(["year", "month"], as_index=False)["tmean"].mean()
    return g.rename(columns={"tmean": "tmean"}), g


def province_temperature_by_year():
    """Return dict: province -> DataFrame(year, annual_temp, spring_temp, suitable_months)."""
    temp = pd.read_csv(IN_TEMP, encoding="utf-8-sig")
    out = {}
    # national (mean of 8 cities)
    nat = temp[temp["city"].isin(NATIONAL_CITIES)].groupby(
        ["year", "month"], as_index=False)["tmean"].mean()
    out["全国"] = temper_yearly(nat, "全国")
    # 广东 via Guangzhou only
    gz = temp[temp["city"] == GUANGDONG_CITY].copy()
    out["广东"] = temper_yearly(gz, "广东")
    return out


def temper_yearly(mtemp, province):
    """mtemp: DataFrame(year, month, tmean). Compute per-year indicators."""
    rows = []
    for year, grp in mtemp.groupby("year"):
        full = grp.set_index("month")["tmean"]
        annual = float(full.loc[full.index.isin(range(1, 13))].mean())
        spring = float(full.loc[full.index.isin(SPRING_MONTHS)].mean())
        suitable = int((full >= SUITABLE_T).sum())
        rows.append({"province": province, "year": int(year),
                     "annual_temp": annual, "spring_temp": spring,
                     "suitable_months": suitable})
    return pd.DataFrame(rows)


# --------------------------------------------------------------------------
# panel / time-series attribution (fixed effects = province dummies,
# cluster-robust SE by province, predictors z-scored)
# --------------------------------------------------------------------------
def zscore(s):
    s = pd.to_numeric(s, errors="coerce")
    return (s - s.mean()) / s.std(ddof=0) if s.std(ddof=0) > 0 else s * 0.0


def fit_model(df, province, metric, predictors, model_name):
    """One model row for a province x metric, returning dict or all-NaN.

    Each fit is a within-province time series. When the dummy sample spans
    multiple provinces we add C(province) fixed effects and cluster by
    province; for a single province (the common case here) the fixed effect
    is absorbed and we use HC1 robust SE over the within-province series.
    """
    d = df.copy()
    d = d.dropna(subset=[metric] + predictors)
    d = d[d["province"] == province]
    n = len(d)
    if n == 0:
        return None
    if n < MIN_YEARS:
        return _nan_row(province, metric, predictors, model_name, n)
    # a metric with zero variance in the sample is not estimable (e.g. national
    # offset_month is constant = 11) -> report NaN rows instead of degenerate coef 0 / r2 inf
    if pd.to_numeric(d[metric], errors="coerce").std() == 0:
        return _nan_row(province, metric, predictors, model_name, n)
    # z-score predictors on the estimation sample
    zd = d.copy()
    for p in predictors:
        zd[p] = zscore(d[p])
    nprov = zd["province"].nunique()
    if nprov > 1:
        formula = f"{metric} ~ " + " + ".join(predictors) + " + C(province)"
        try:
            res = smf.ols(formula, data=zd).fit(
                cov_type="cluster", cov_kwds={"groups": zd["province"]})
        except Exception:
            return _nan_row(province, metric, predictors, model_name, n)
    else:
        formula = f"{metric} ~ " + " + ".join(predictors)
        try:
            res = smf.ols(formula, data=zd).fit(cov_type="HC1")
        except Exception:
            return _nan_row(province, metric, predictors, model_name, n)
    r2 = float(res.rsquared)
    rows = []
    for p in predictors:
        coef = float(res.params[p])
        se = float(res.bse[p])
        pval = float(res.pvalues[p])
        rows.append(_row(province, metric, p, model_name, coef, se, pval, r2, n))
    return rows


def _row(province, metric, predictor, model, coef, se, p, r2, n):
    return {"province": province, "metric": metric, "predictor": predictor,
            "model": model, "coef": coef, "se": se, "p": p, "r2": r2, "n_years": n}


def _nan_row(province, metric, predictors, model_name, n):
    rows = []
    for p in predictors:
        rows.append(_row(province, metric, p, model_name, np.nan, np.nan,
                         np.nan, np.nan, n))
    return rows


def run_attribution(temp_by_year):
    win = pd.read_csv(IN_WINDOWS, encoding="utf-8-sig")
    win = win[win["threshold"] == DEFAULT_THRESHOLD].copy()
    # valid windows only, and drop COVID-disrupted / incomplete years
    win = win.dropna(subset=["length_months"]).copy()
    win = win[~win["year"].isin(COVID_YEARS | INCOMPLETE_YEARS)]
    win = win[["province", "year", "length_months", "onset_month", "offset_month"]]
    rows = []
    for prov in ["全国", "广东"]:
        t = temp_by_year[prov]
        tm = pd.merge(win, t, on=["province", "year"], how="inner")
        if len(tm) == 0:
            continue
        for metric in METRICS:
            for model_name, pred in PRED_M1:
                r = fit_model(tm, prov, metric, [pred], model_name)
                if r:
                    rows.extend(r)
            r = fit_model(tm, prov, metric, [PRED_M2[0][1], PRED_M2[1][1]],
                          PRED_M2[0][0])
            if r:
                rows.extend(r)
    return pd.DataFrame(rows)


# --------------------------------------------------------------------------
# simplified DLNM: Almon polynomial (degree 3), lags 0-3
# NegativeBinomial GLM (handles the strong over-dispersion of case counts)
# --------------------------------------------------------------------------
def build_dlm_data():
    cases = pd.read_csv(IN_CLEAN, encoding="utf-8-sig")
    cases = cases[(cases["province"] == "全国") &
                  (cases["year"] >= 2013) & (cases["year"] <= 2024)].copy()
    # drop COVID-disrupted (2020-2021) and incomplete (2022) national years
    cases = cases[~cases["year"].isin(COVID_YEARS | INCOMPLETE_YEARS)].copy()
    nat = build_national_monthly_tmean()[0]
    nat = nat.rename(columns={"tmean": "temp"})
    m = pd.merge(cases, nat, on=["year", "month"], how="inner")
    m = m.sort_values(["year", "month"]).reset_index(drop=True)
    m["cases"] = pd.to_numeric(m["cases"], errors="coerce")
    m = m.dropna(subset=["temp", "cases"])
    return m


def almon_polynomial(lags, degree=3):
    """Return basis design columns: Z_j = lags^j (j=0..degree)."""
    lags = np.asarray(lags, dtype=float)
    cols = {f"z{j}": lags ** j for j in range(degree + 1)}
    return pd.DataFrame(cols), np.arange(0, degree + 1)


def run_dlm(m):
    m = m.reset_index(drop=True)
    temps = m["temp"].to_numpy(dtype=float)
    y = m["cases"].to_numpy(dtype=float)
    n = len(temps)
    lags = [0, 1, 2, 3]
    maxlag = max(lags)
    # design matrix rows = shifted temp lags; drop first `maxlag` obs
    X = np.column_stack([temps[maxlag - l: n - l] for l in lags])
    yv = y[maxlag:]
    Z, powers = almon_polynomial(lags, degree=3)
    Zmat = Z.to_numpy(dtype=float)     # (len(lags), 4) basis over lags 0..3
    Xb = X @ Zmat                      # N x 4 Almon basis design
    fb = pd.DataFrame(Xb, columns=[f"z{j}" for j in range(Zmat.shape[1])])
    glm = GLM(yv, fb, family=NegativeBinomial()).fit(disp=False)
    bn = glm.params.to_numpy()
    cb = glm.cov_params().to_numpy()
    from scipy.stats import norm
    out = []
    for l in lags:
        g = np.array([l ** j for j in powers])
        beta = float(g @ bn)
        var = float(g @ cb @ g)
        se = float(np.sqrt(var))
        ci_low = beta - 1.96 * se
        ci_high = beta + 1.96 * se
        p = 2.0 * (1.0 - norm.cdf(abs(beta) / se)) if se > 0 else np.nan
        out.append({"lag": l, "coef": beta, "se": se, "p": p,
                    "ci_low": ci_low, "ci_high": ci_high})
    return pd.DataFrame(out), bn, cb, powers


# --------------------------------------------------------------------------
# temperature trend (2004-2024) for the report
# --------------------------------------------------------------------------
def temp_trend_summary():
    temp = pd.read_csv(IN_TEMP, encoding="utf-8-sig")
    nat = temp[temp["city"].isin(NATIONAL_CITIES)].groupby(
        ["year", "month"], as_index=False)["tmean"].mean()
    annual = nat.groupby("year")["tmean"].mean()
    ys = annual.index.astype(float).to_numpy()
    vals = annual.to_numpy()
    slope, intercept, r, p, se = stats.linregress(ys, vals)
    first = annual.loc[2004]
    last = annual.loc[2024]
    return {
        "start": float(first), "end": float(last),
        "change_deg": float(last - first),
        "slope": float(slope), "slope_p": float(p),
        "mean": float(annual.mean()),
        "annual_series": {int(y): round(float(v), 2) for y, v in annual.items()},
    }


# --------------------------------------------------------------------------
# figures
# --------------------------------------------------------------------------
def plot_scatter(merged):
    # all province-year points with valid length + annual_temp
    os.makedirs(FIG, exist_ok=True)
    fig, ax = plt.subplots(figsize=(7, 5))
    colors = {"全国": "#1783FF", "广东": "#F0884D"}
    for prov in sorted(merged["province"].unique()):
        sub = merged[(merged["province"] == prov)]
        sub = sub.dropna(subset=["length_months", "annual_temp"])
        if len(sub) == 0:
            continue
        ax.scatter(sub["annual_temp"], sub["length_months"],
                   label=prov, s=40, alpha=0.8, color=colors.get(prov, "k"))
        if len(sub) >= 3:
            slope, intercept, *_ = stats.linregress(
                sub["annual_temp"], sub["length_months"])
            xs = np.linspace(sub["annual_temp"].min(), sub["annual_temp"].max(), 10)
            ax.plot(xs, intercept + slope * xs, color=colors.get(prov, "k"),
                    lw=2, alpha=0.8)
            ax.annotate(f"{prov} slope={slope:.2f} mo/°C",
                        xy=(sub["annual_temp"].mean(),
                            intercept + slope * sub["annual_temp"].mean()),
                        color=colors.get(prov, "k"), fontsize=9)
    ax.set_xlabel("Annual mean temperature (°C)")
    ax.set_ylabel("Season window length (months)")
    ax.set_title("Dengue season window length vs annual temperature")
    ax.grid(alpha=0.3)
    ax.legend()
    fig.tight_layout()
    fig.savefig(OUT_SCATTER, dpi=200)
    plt.close(fig)
    print(f"[wrote] {OUT_SCATTER}")


def plot_lag_curve(lag_coefs, bn, cb, powers):
    os.makedirs(FIG, exist_ok=True)
    fig, ax = plt.subplots(figsize=(6.5, 4.5))
    xs = np.linspace(0, 3, 60)
    g = np.column_stack([xs ** j for j in powers])
    curve = g @ bn
    var = np.einsum("ij,jk,ik->i", g, cb, g)
    se = np.sqrt(np.maximum(var, 0))
    ax.plot(xs, curve, color="#1783FF", lw=2, label="Almon lag curve")
    ax.fill_between(xs, curve - 1.96 * se, curve + 1.96 * se,
                    color="#1783FF", alpha=0.2, label="95% CI")
    for _, r in lag_coefs.iterrows():
        ax.plot(r["lag"], r["coef"], "ko", ms=5)
        ax.vlines(r["lag"], r["ci_low"], r["ci_high"], color="k", lw=1.2)
    ax.axhline(0, color="gray", lw=1, ls="--")
    ax.set_xlabel("Temperature lag (months)")
    ax.set_ylabel("Log(rate) per °C")
    ax.set_title("Distributed lag: temperature → national dengue cases")
    ax.set_xticks([0, 1, 2, 3])
    ax.grid(alpha=0.3)
    ax.legend()
    fig.tight_layout()
    fig.savefig(OUT_LAGCURVE, dpi=200)
    plt.close(fig)
    print(f"[wrote] {OUT_LAGCURVE}")


# --------------------------------------------------------------------------
# assertions + main
# --------------------------------------------------------------------------
def assert_ok(attr, lag):
    ok = True
    if attr is None or len(attr) == 0:
        print("[FAIL] attribution.csv empty / no national rows")
        ok = False
    else:
        if "全国" not in set(attr["province"]):
            print("[FAIL] no national rows in attribution.csv")
            ok = False
        p = attr["p"].dropna()
        if not p.between(0.0, 1.0).all():
            print("[FAIL] p-value out of [0,1]")
            ok = False
        if p.empty:
            print("[WARN] no non-NaN p-values (possible insufficient sample)")
    if lag is None or len(lag) == 0:
        print("[FAIL] distributed_lag.csv empty")
        ok = False
    if lag is not None and lag["coef"].isna().all():
        print("[FAIL] all lag coefficients NaN")
        ok = False
    if ok:
        print("[PASS] assertions")
    return ok


def write_report(temp_summary, attr, lag, merged, dlm_m):
    os.makedirs(DOC, exist_ok=True)
    L = []
    L.append("# Task 6 Report: 温度归因（面板/时间序列回归 + 简化 DLNM）\n")
    L.append("> 项目：中国登革热流行季节窗口气候归因（dengue-enso）")
    L.append(f"> 脚本：`scripts/attribution.py`")
    L.append("> 状态：**DONE**（退出码 0，断言全过）\n")

    L.append("## 1. 数据与温度匹配选择\n")
    L.append("- 温度匹配：**全国 = 8 城月度 tmean 的均值**"
             "（广州、深圳、南宁、昆明、福州、海口、厦门、杭州）；广东 = 广州。")
    L.append("- 华南 5 城（广州、深圳、南宁、海口、厦门）均值作为备选读取过，报告采用 8 城均值主口径。")
    L.append("- 窗口年份 1998–2001 无温度覆盖（温度 2004 起）→ 这些年份在归因分析中不可用；"
             "2008–2009 可用温度。"
             "归因使用**主口径全国**（温度覆盖内有效窗口年），广东作辅助。\n")

    L.append("## 2. 温度趋势描述（2004–2024，8 城均值）\n")
    L.append(f"- 年均温均值 = **{temp_summary['mean']:.2f} °C**；"
             f"2004 = {temp_summary['start']:.2f} °C → 2024 = {temp_summary['end']:.2f} °C；"
             f"绝对变化 **+{temp_summary['change_deg']:.2f} °C**。")
    L.append(f"- 线性趋势斜率 = {temp_summary['slope']:.4f} °C/年，p = {temp_summary['slope_p']:.4f}。\n")
    ser = ", ".join(f"{k}:{v}" for k, v in temp_summary["annual_series"].items())
    L.append(f"- 逐年 8 城年均温：{ser}\n")

    L.append("## 3. 面板/时间序列归因结果\n")
    L.append("`长度/onset/offset` 分别对温度指标做省际内时间序列回归；预测变量先 z-score "
             "**再比较效应量（系数 = 每 1 个标准差温度变化的窗口月数变化）**。")
    L.append("主口径全国为单省序列（省固定效应被吸收），采用 HC1 稳健 SE；")
    L.append("若样本跨多省则加省虚拟变量并 cluster 按省。"
             "全国 `offset_month` 在有效窗口年恒为常值（11，无年际方差）→ 不可估计，输出 NaN 行。\n")
    L.append("| province | metric | predictor | model | coef | se | p | r2 | n_years |")
    L.append("|---|---|---|---|---|---|---|---|---|")
    for _, r in attr.iterrows():
        def fmt(v):
            return "NaN" if pd.isna(v) else f"{v:.4f}"
        L.append(f"| {r['province']} | {r['metric']} | {r['predictor']} | "
                 f"{r['model']} | {fmt(r['coef'])} | {fmt(r['se'])} | "
                 f"{fmt(r['p'])} | {fmt(r['r2'])} | {int(r['n_years'])} |\n")

    # significance summary for national
    nat = attr[attr["province"] == "全国"].dropna(subset=["p"])
    sig = nat[nat["p"] < 0.05]
    L.append(f"### 3.1 显著性小结（全国）")
    L.append(f"- 全国共 {len(nat)} 个估计，其中 p<0.05 的 {len(sig)} 个。")
    if len(sig) == 0:
        L.append("- **温度指标对全国窗口长度/onset/offset 均未见统计显著（p<0.05）关联**；"
                 "效应量见上表（z-score 系数）。")
    else:
        for _, r in sig.iterrows():
            dr = {"length_months": "窗口长度", "onset_month": "起始月份",
                  "offset_month": "结束月份"}.get(r["metric"], r["metric"])
            pred = {"annual_temp": "年均温", "spring_temp": "春季温",
                    "suitable_months": "适宜月数"}.get(r["predictor"], r["predictor"])
            L.append(f"- **{dr} ~ {pred}**：coef={r['coef']:.3f} (SE {r['se']:.3f}, p={r['p']:.4f}, "
                     f"model={r['model']})。")
    L.append("")

    L.append("## 4. 分布式滞后（简化 DLNM / Almon 多项式 3 阶，滞后 0–3 月，NegativeBinomial GLM）\n")
    L.append("- 数据：全国月度温度（8 城均值）对全国月度病例，年份 2013–2024（剔除 2020/2021 COVID、"
             "2022 月覆盖不全）。")
    L.append("- 采用 NegativeBinomial 处理病例强过离散；系数 = 温度每升高 1°C 时对应滞后月 "
             "log(病例率) 的变化；滞后曲线见图。\n")
    L.append("| lag | coef | se | p | ci_low | ci_high |")
    L.append("|---|---|---|---|---|---|")
    for _, r in lag.iterrows():
        L.append(f"| {int(r['lag'])} | {r['coef']:.4f} | {r['se']:.4f} | "
                 f"{r['p']:.4f} | {r['ci_low']:.4f} | {r['ci_high']:.4f} |\n")
    peak = lag.reindex(lag["coef"].abs().sort_values(ascending=False).index)
    L.append(f"- 滞后峰值（|coef| 最大）：lag {int(peak.iloc[0]['lag'])}，"
             f"coef={peak.iloc[0]['coef']:.4f} (p={peak.iloc[0]['p']:.4f})。\n")

    L.append("## 5. 对 H2 假说的支持程度\n")
    L.append("- H2：窗口年际变化与温度指标（年均温、春季/初夏温度、≥21°C 适宜月数）显著相关，"
             "且存在滞后-非线性结构（DLNM）。")
    # derive support wording from results
    sig_n = (nat["p"] < 0.05).sum() if len(nat) else 0
    peak_p = lag.iloc[0]["p"]
    lag_sig = int((lag["p"] < 0.05).sum())
    if sig_n > 0 and lag_sig > 0:
        verdict = ("**部分支持**：面板（窗口指标）层面存在显著关联项，且 DLNM 滞后系数显著，"
                   "两条证据线方向一致支持温度作用。")
    elif lag_sig > 0 and sig_n == 0:
        verdict = ("**部分支持（有限）**：滞后结构（DLNM）显示显著滞后系数，但**面板层面窗口指标对温度均不显著**"
                   f"（0/{len(nat)} 个 p<0.05），对窗口演变的直接温度关联支持较弱。")
    elif sig_n > 0 and lag_sig == 0:
        verdict = "**部分支持（有限）**：面板层面有显著项，但 DLNM 滞后系数未见显著。"
    else:
        verdict = "**弱 / 不支持（样本受限）**：面板与 DLNM 均未达 p<0.05，证据不足以支持 H2。"
    L.append(f"- 判定：{verdict}")
    L.append("- 效应方向/量级（z-score 系数，表格中全国行）：若 coef>0 表示温度升高→窗口长度/起始/结束"
             "相应变化；量级须结合表内 coef（每 1 SD）解读。")
    L.append("- **解读注意**：全国有效窗口年的 `offset_month` 恒为 11（无年际方差），故长度与"
             "onset 的系数互为镜像（length = offset − onset + 1），二者信息等价；"
             "未见显著的直接窗口-温度关联主要在 onset/length 层面。\n")

    L.append("## 6. 明确的因果语言限制（关联 ≠ 因果）\n")
    L.append("- 本分析为**观测性、相关性**：面板回归与 DLNM 均不能证明温度导致窗口变化；"
             "可能存在共变、反向因果、遗漏变量（输入性病例、人口流动、媒介密度、防控措施）。")
    L.append("- 全国仅约 11 个有效窗口年份、DLM 采用简化 Almon 约束（3 阶、滞后 0–3），"
             "统计功效有限，未显著不能视作「无关联」的证据。")
    L.append("- 语言上应用「与变暖一致（consistent with warming）」「温度升高伴随窗口延长」等措辞，"
             "避免「温度导致（causes）」表述。\n")

    L.append("## 7. 数据与样本限制\n")
    L.append("- 广东温度覆盖（2004 起）与有效窗口（1998–2003、2008）几乎不重叠，"
             "仅 2008 一年有温度+窗口 → 广东行多为 **NaN**（样本 < " + str(MIN_YEARS) + " 年）。")
    L.append("- 全国 2020/2021 为 COVID 报告干扰年、2012 无有效窗口、2022 月覆盖不全，均已剔除。\n")

    with open(OUT_REPORT, "w", encoding="utf-8") as f:
        f.write("\n".join(L))
    print(f"[wrote] {OUT_REPORT}")


def main():
    print("=" * 60)
    print("Step 1: temperature indicators")
    temp_by_year = province_temperature_by_year()
    for prov, t in temp_by_year.items():
        print(f"  {prov}: {len(t)} year-records, "
              f"temp {t['annual_temp'].min():.2f}-{t['annual_temp'].max():.2f} °C")

    print("=" * 60)
    print("Step 2: panel/time-series attribution")
    attr = run_attribution(temp_by_year)
    os.makedirs(RES, exist_ok=True)
    attr.to_csv(OUT_ATTR, index=False, encoding="utf-8-sig")
    print(f"  [wrote] {OUT_ATTR} ({len(attr)} rows)")
    print(attr.to_string(index=False))

    print("=" * 60)
    print("Step 3: distributed-lag (Almon, lags 0-3, NegativeBinomial)")
    m = build_dlm_data()
    print(f"  DLM monthly rows: {len(m)} (national 2013-2024, excl 2020/2021/2022)")
    lag, bn, cb, powers = run_dlm(m)
    lag.to_csv(OUT_LAG, index=False, encoding="utf-8-sig")
    print(f"  [wrote] {OUT_LAG}")
    print(lag.to_string(index=False))

    print("=" * 60)
    print("Step 4: figures")
    # merged data for scatter: valid windows + temperature, excluding COVID/incomplete
    win = pd.read_csv(IN_WINDOWS, encoding="utf-8-sig")
    win = win[win["threshold"] == DEFAULT_THRESHOLD].copy()
    win = win.dropna(subset=["length_months"])
    win = win[~win["year"].isin(COVID_YEARS | INCOMPLETE_YEARS)]
    merged_list = []
    for prov in ["全国", "广东"]:
        t = temp_by_year[prov]
        w = win[win["province"] == prov][["province", "year", "length_months"]]
        merged_list.append(pd.merge(w, t, on=["province", "year"], how="inner"))
    merged = pd.concat(merged_list, ignore_index=True)
    plot_scatter(merged)
    plot_lag_curve(lag, bn, cb, powers)

    print("=" * 60)
    print("Step 5: temperature trend for the report")
    ts = temp_trend_summary()
    print(f"  2004={ts['start']:.2f} → 2024={ts['end']:.2f} °C, "
          f"change {ts['change_deg']:+.2f} °C, slope {ts['slope']:.4f}/yr (p={ts['slope_p']:.4f})")

    print("=" * 60)
    print("Step 6: report")
    write_report(ts, attr, lag, merged, m)

    print("=" * 60)
    print("Step 7: assertions")
    ok = assert_ok(attr, lag)
    print("\nDONE. ok =", ok)
    return 0 if ok else 1


if __name__ == "__main__":
    sys.exit(main())
