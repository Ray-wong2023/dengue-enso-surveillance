# -*- coding: utf-8 -*-
"""
Task 8a: publication figures for the dengue epidemic-window analysis.

Figure 1 (fig1_window_trend):  season windows over time for China (全国) and
    Guangdong (广东).  Each year column draws the epidemic window as a band
    from onset month to offset month (months on the y-axis); the main 5-95%
    threshold band is drawn solid and the two sensitivity thresholds
    (1-99%, 10-90%) are overlaid semi-transparently.  Peak month is marked.
    An MK tau / p / Sen-slope annotation is read from results/trends.csv for
    China and computed as an EXPLORATORY span (1998-2008) for Guangdong (the
    trends.csv series does not cover a usable Guangdong period).

Figure 4 (fig4_map, SIMPLIFIED):  the implementation plan allows a simple
    schematic when geopandas / a China province shapefile is unavailable.
    geopandas is not installed here, so fig four is a schematic rectangular
    grid of the six southern endemic provinces (广东 广西 云南 福建 海南 浙江)
    placed approximately where they sit on a map of China, with each cell
    coloured by the direction / magnitude of epidemic-window LENGTH change
    (Sen slope of length_months).  The data limitation is stated honestly in
    the figure: only 全国 & 广东 carry a usable multi-year length series;
    云南/浙江/福建 have a single valid window year (insufficient for a
    trend) and 广西/海南 have no window at all.

Shared style comes from scripts/style_common.py (set_style / COLORS /
FIG_DPI / save_fig) so both T8 branches look consistent.

Inputs  (read-only):
    data/processed/windows.csv        season windows (Task 4)
    results/trends.csv                Mann-Kendall/Sen/breakpoint (Task 5)
    data/processed/dengue_china_clean.csv  used only as a cross-check assert

Outputs:
    figures/fig1_window_trend.png / .pdf
    figures/fig4_map.png / .pdf
"""
import os
import sys

# ensure scripts/ is importable so "import style_common" resolves
_HERE = os.path.dirname(os.path.abspath(__file__))
_ROOT = os.path.dirname(_HERE)
for _p in (_HERE, _ROOT):
    if _p not in sys.path:
        sys.path.insert(0, _p)

import numpy as np
import pandas as pd
from scipy import stats

# matplotlib must be forced to Agg BEFORE importing style_common (which uses it)
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
from matplotlib.patches import Rectangle, Polygon as MplPolygon
from matplotlib.lines import Line2D
from matplotlib.colors import TwoSlopeNorm

plt.rcParams["hatch.linewidth"] = 1.3
from style_common import (
    set_style, COLORS, OUTBREAK_COLOR, COVID_COLOR, FIG_DPI, save_fig,
)

# ---------------------------------------------------------------------------
# constants
# ---------------------------------------------------------------------------
PROC = os.path.join(_ROOT, "data", "processed")
RES = os.path.join(_ROOT, "results")
FIG = os.path.join(_ROOT, "figures")

IN_WINDOWS = os.path.join(PROC, "windows.csv")
IN_TRENDS = os.path.join(RES, "trends.csv")
IN_DENGUE = os.path.join(PROC, "dengue_china_clean.csv")

OUT_FIG1 = os.path.join(FIG, "fig1_window_trend")
OUT_FIG4 = os.path.join(FIG, "fig4_map")

# threshold -> (rank for stacking, alpha for overlay).  Main 5-95% is solid;
# the two sensitivity thresholds are stacked semi-transparently around it.
THRESHOLDS = ["(0.05,0.95)", "(0.01,0.99)", "(0.10,0.90)"]
THRESH_ALPHA = {
    "(0.05,0.95)": 1.0,
    "(0.01,0.99)": 0.35,
    "(0.10,0.90)": 0.35,
}
MAIN_THR = "(0.05,0.95)"

# fig1 panels: (province, type) where type='china' reads trends.csv and
# 'guangdong' uses an exploratory full-span trend computed from windows.csv
# because trends.csv has no usable Guangdong period.
FIG1_PANELS = [
    ("全国", "china"),
    ("广东", "guangdong"),
]

# fig4: the six southern endemic provinces from the plan, with (x, y) grid
# positions approximately matching their location on a China map
# (origin bottom-left; y larger = more north, x larger = more east).
MAP_CELLS = [
    # name, x, y,  (y is the *southern* edge baseline; cells are 0.22 wide)
    ("云南", 0.10, 5.1),
    ("广西", 0.70, 4.6),
    ("广东", 1.45, 4.0),
    ("海南", 2.30, 3.0),
    ("福建", 1.55, 6.2),
    ("浙江", 1.90, 8.0),
]
CELL_W, CELL_H = 0.98, 1.30
FIG4_MAIN_PERIOD = "2012-2024"       # China's main calibration period
FIG4_GD_EXPLORATORY = "1998-2008"    # Guangdong exploratory span

MIN_N_TREND = 3

# ---------------------------------------------------------------------------
# statistics helpers (mirror trend_analysis.py so numbers are consistent)
# ---------------------------------------------------------------------------
def mann_kendall(x):
    """Mann-Kendall trend test with tie correction -> (tau, p_two_sided)."""
    x = np.asarray(x, dtype=float)
    n = len(x)
    if n < 2:
        return (np.nan, np.nan)
    s = 0.0
    for i in range(n - 1):
        s += np.sign(x[i + 1:] - x[i]).sum()
    ties = [len(list(g)) for _, g in
            __import__("itertools").groupby(np.sort(x))]
    var_s = (n * (n - 1) * (2 * n + 5) -
             sum(t * (t - 1) * (2 * t + 5) for t in ties)) / 18.0
    if var_s <= 0:
        return (0.0, 1.0)
    z = (s - np.sign(s) * 0.5) / np.sqrt(var_s)
    p = 2.0 * (1.0 - stats.norm.cdf(abs(z)))
    tau = s / (n * (n - 1) / 2.0)
    return (tau, p)


def sen_slope(x, y):
    """Median of all pairwise slopes (y per unit x)."""
    x = np.asarray(x, dtype=float)
    y = np.asarray(y, dtype=float)
    n = len(x)
    slopes = [(y[j] - y[i]) / (x[j] - x[i])
              for i in range(n)
              for j in range(i + 1, n)
              if x[j] != x[i]]
    if not slopes:
        return np.nan
    return float(np.median(slopes))


def load_windows():
    w = pd.read_csv(IN_WINDOWS, encoding="utf-8-sig")
    for col in ["onset_month", "offset_month", "length_months", "peak_month"]:
        w[col] = pd.to_numeric(w[col], errors="coerce")
    return w


# ---------------------------------------------------------------------------
# input assertions
# ---------------------------------------------------------------------------
def run_input_assertions():
    needed = [IN_WINDOWS, IN_TRENDS, IN_DENGUE]
    for f in needed:
        if not os.path.exists(f):
            print(f"[FAIL] missing input {f}")
            return False
    w = load_windows()
    exp = ["province", "year", "threshold", "onset_month", "offset_month",
           "length_months", "peak_month", "n_months", "incomplete", "note"]
    missing = [c for c in exp if c not in w.columns]
    if missing:
        print(f"[FAIL] windows.csv missing columns: {missing}")
        return False
    if "全国" not in set(w["province"]) or "广东" not in set(w["province"]):
        print("[FAIL] windows.csv missing 全国/广东")
        return False
    tr = pd.read_csv(IN_TRENDS, encoding="utf-8-sig")
    if tr.empty:
        print("[FAIL] trends.csv empty")
        return False
    # only the 5-95 length metric for China is required for fig1/fig4
    ref = tr[(tr["province"] == "全国") & (tr["threshold"] == MAIN_THR) &
             (tr["metric"] == "length")]
    if ref.empty:
        print("[FAIL] trends.csv missing 全国 main length series")
        return False
    print(f"[PASS] inputs OK: windows={len(w)} "
          f"trends={len(tr)} columns ok")
    return True


# ---------------------------------------------------------------------------
# figure 1  (window bands over years)
# ---------------------------------------------------------------------------
def _panel_window_bands(ax, w, prov, trends_df):
    """Draw window bands (month onset->offset) for one province across years.

    x = year, y = month (1..12).  The main 5-95% band is solid; sensitivity
    thresholds overlaid transparently.  Peak month marked.  Returns the list
    of years actually plotted.
    """
    sub = w[w["province"] == prov]
    valid = sub.dropna(subset=["onset_month", "offset_month"]).sort_values("year")
    years = sorted(valid["year"].unique())
    if not years:
        return years

    # y span plus a little headroom for the peak marker and band outlines
    ax.set_ylim(0, 13.2)

    for y in years:
        is_incomplete = bool(
            (sub[(sub["year"] == y) & (sub["threshold"] == MAIN_THR)]["incomplete"] == 1).any()
            if not sub[(sub["year"] == y) & (sub["threshold"] == MAIN_THR)].empty
            else False)
        for thr in THRESHOLDS:
            row = sub[(sub["year"] == y) & (sub["threshold"] == thr)]
            if row.empty:
                continue
            r = row.iloc[0]
            if np.isnan(r["onset_month"]) or np.isnan(r["offset_month"]):
                continue
            o, off = r["onset_month"], r["offset_month"]
            main = (thr == MAIN_THR)
            ax.plot([y, y], [o, off],
                    color=(COLORS[0] if main else "0.55"),
                    lw=3.8, alpha=(THRESH_ALPHA[thr] if not main else 0.95),
                    solid_capstyle="butt", zorder=(5 if main else 3))
            if main and not np.isnan(r["peak_month"]):
                ax.scatter(y, r["peak_month"], marker="o", s=26,
                           color=OUTBREAK_COLOR, edgecolors="white",
                           linewidths=0.6, zorder=6)
        if is_incomplete:
            ax.scatter(y, 12.55, marker="v", s=30, color=OUTBREAK_COLOR,
                       zorder=6)
    ax.set_ylim(0, 13.3)
    return years


def _fig1_trend_text(prov, kind, trends_df, w):
    """Return a short annotation under/over the band: MK tau, p, Sen slope."""
    mthr = MAIN_THR
    if kind == "china":
        # use the clean main-period length row from trends.csv (2012-2024)
        ref = trends_df[
            (trends_df["province"] == prov) &
            (trends_df["threshold"] == mthr) &
            (trends_df["metric"] == "length")]
        # prefer the primary 2012-2024 period if present, else best available
        row_ref = None
        for period in [FIG4_MAIN_PERIOD, "2008-2024"]:
            cand = ref[ref["period"] == period]
            if not cand.empty:
                row_ref = cand.iloc[0]
                break
        if row_ref is None and not ref.empty:
            row_ref = ref.iloc[0]
        if row_ref is None:
            return "trend: n/a (no series)"
        period = row_ref["period"]
        tau = float(row_ref["mk_tau"])
        p = float(row_ref["mk_p"])
        sen = float(row_ref["sen_slope_yr"])
        n = int(row_ref["n_years"])
        label = (f"length {period}: MK \u03c4="
                 f"{tau:+.2f}, p={p:.2f}, Sen={sen:+.2f} mo/yr (n={n})")
        return label
    # guangdong: exploratory full-span (1998-2008) trend from windows.csv
    gd = w[(w["province"] == prov) & (w["threshold"] == mthr)]
    gd = gd.dropna(subset=["length_months"]).sort_values("year")
    if len(gd) < MIN_N_TREND:
        return "Guangdong: data limited (<3 valid window years)"
    yrs = gd["year"].to_numpy(float)
    lens = gd["length_months"].to_numpy(float)
    tau, p = mann_kendall(lens)
    sen = sen_slope(yrs, lens)
    span = f"{yrs.min():.0f}-{yrs.max():.0f}"
    label = (f"length {span} (exploratory): MK \u03c4={tau:+.2f}, "
             f"p={p:.2f}, Sen={sen:+.2f} mo/yr (n={len(gd)})")
    return label


def _fig1_no_data_spans(ax, plotted_years):
    """Shade calendar gaps between valid window years as 'no monthly data'.

    The source has no monthly records for these years (e.g. 2002-2007,
    2010-2012 nationally); an unexplained blank reads as an error, so the
    gaps are made explicit.
    """
    if len(plotted_years) < 2:
        return
    ys = sorted(plotted_years)
    spans = []
    for a, b in zip(ys[:-1], ys[1:]):
        if b - a > 1.5:
            spans.append((a + 0.5, b - 0.5))
    for x0, x1 in spans:
        ax.axvspan(x0, x1, color="0.88", zorder=0.5)
        ax.text((x0 + x1) / 2.0, 6.9, "no monthly\nsurveillance data",
                ha="center", va="center", fontsize=7.2, color="0.45",
                rotation=90, linespacing=1.1)


def plot_fig1(w, trends_df):
    os.makedirs(FIG, exist_ok=True)
    set_style()
    n = len(FIG1_PANELS)
    fig, axes = plt.subplots(n, 1, figsize=(11, 4.6 * n), sharex=False)
    if n == 1:
        axes = [axes]

    for ax, (prov, kind) in zip(axes, FIG1_PANELS):
        # sub-header with the panel name (bilingual, journal-safe)
        label = "China" if prov == "全国" else "Guangdong"
        ax.set_title(f"{label}  ({prov}) - epidemic-season window",
                     fontsize=FIG1_FONT + 1, pad=10)
        plotted_years = _panel_window_bands(ax, w, prov, trends_df)
        ax.set_ylabel("Month", fontsize=FIG1_FONT)
        ax.set_xlabel("Year", fontsize=FIG1_FONT)
        ax.set_yticks(np.arange(1, 13))
        ax.set_ylim(0, 13.4)
        if plotted_years:
            ax.set_xticks(plotted_years)
            ax.tick_params(axis="x", labelsize=7.5, rotation=45)
        # make data gaps explicit instead of an unexplained blank
        _fig1_no_data_spans(ax, plotted_years)
        # trend annotation inside the panel (top-left, clear of the header)
        txt = _fig1_trend_text(prov, kind, trends_df, w)
        ax.text(0.015, 0.972, txt, transform=ax.transAxes, ha="left",
                va="top", fontsize=7.5, color="0.2")

        # mark COVID-disrupted years light behind bands
        covid = w[(w["province"] == prov) &
                  (w["threshold"] == MAIN_THR) &
                  w["note"].str.contains("COVID", na=False)]
        for _y in covid["year"].unique():
            ax.axvspan(_y - 0.35, _y + 0.35, color=COVID_COLOR, alpha=0.35,
                       zorder=1)

    # shared legend built from proxy artists (figure level, right-aligned so
    # it cannot collide with the explainer line or the panel titles)
    proxy = [
        Line2D([0], [0], color=COLORS[0], lw=4,
               label="window (onset–offset), 5–95%"),
        Line2D([0], [0], color="0.55", lw=4, alpha=0.35,
               label="sensitivity (1–99%, 10–90%)"),
        Line2D([0], [0], marker="o", color="none", mec="white", mfc=OUTBREAK_COLOR,
               ms=7, label="peak month"),
        Line2D([0], [0], marker="v", color="none", mfc=OUTBREAK_COLOR,
               mec=OUTBREAK_COLOR, ms=8, label="incomplete year"),
        Rectangle((0, 0), 1, 1, facecolor=COVID_COLOR, alpha=0.45,
                  label="COVID-disrupted reporting"),
        Rectangle((0, 0), 1, 1, facecolor="0.88",
                  label="no monthly surveillance data"),
    ]
    fig.legend(handles=proxy, loc="upper right", ncol=3, frameon=False,
               fontsize=7.5, bbox_to_anchor=(0.995, 0.99))
    fig.text(0.01, 0.995,
             "Y-axis months 1–12 (Jan–Dec); bars span onset→offset. "
             "Grey bands: years without monthly surveillance data "
             "(no records exist; not missing at random).",
             va="top", ha="left", fontsize=7, color="0.3")
    fig.tight_layout(rect=[0, 0, 1, 0.93])
    save_fig(fig, OUT_FIG1)
    print(f"[wrote] {OUT_FIG1}.png/.pdf")


FIG1_FONT = 9


# ---------------------------------------------------------------------------
# figure 4  (simplified schematic map of endemic provinces)
# ---------------------------------------------------------------------------
def _length_change_signal(w, trends_df):
    """Return dict keyed by province of {slope, tau, p, text, status, extra}.

    status: 'trend' (usable multi-year series) | 'insufficient' (<=1 valid
    window year) | 'no_data' (no window at all).
    """
    out = {}
    # national: use trends.csv main-period length
    nat = trends_df[(trends_df["province"] == "全国") &
                    (trends_df["threshold"] == MAIN_THR) &
                    (trends_df["metric"] == "length")]
    row_ref = None
    for period in [FIG4_MAIN_PERIOD, "2008-2024"]:
        cand = nat[nat["period"] == period]
        if not cand.empty:
            row_ref = cand.iloc[0]
            break
    if row_ref is None and not nat.empty:
        row_ref = nat.iloc[0]
    if row_ref is not None:
        out["全国"] = {
            "status": "trend",
            "slope": float(row_ref["sen_slope_yr"]),
            "tau": float(row_ref["mk_tau"]),
            "p": float(row_ref["mk_p"]),
            "period": row_ref["period"],
            "n": int(row_ref["n_years"]),
            "single": bool(np.isnan(row_ref["sen_slope_yr"])),
        }
    else:
        out["全国"] = {"status": "no_data", "single": False}

    for prov in ["广东", "云南", "浙江", "福建", "广西", "海南"]:
        sub = w[(w["province"] == prov) & (w["threshold"] == MAIN_THR)]
        valid = sub.dropna(subset=["length_months"]).sort_values("year")
        if len(valid) == 0:
            out[prov] = {"status": "no_data", "single": False}
            continue
        if len(valid) < MIN_N_TREND:
            out[prov] = {
                "status": "insufficient",
                "single": True,
                "n": len(valid),
                "length": float(valid["length_months"].iloc[0]),
                "year": int(valid["year"].iloc[0]),
            }
            continue
        yrs = valid["year"].to_numpy(float)
        lens = valid["length_months"].to_numpy(float)
        tau, p = mann_kendall(lens)
        slope = sen_slope(yrs, lens)
        out[prov] = {
            "status": "trend",
            "slope": slope,
            "tau": tau,
            "p": float(p),
            "period": f"{yrs.min():.0f}-{yrs.max():.0f}",
            "n": len(valid),
            "single": False,
        }
    return out


def _load_china_geojson():
    """Return (features) from the DataV China province GeoJSON."""
    import json
    gj = os.path.join(_ROOT, "data", "raw", "global", "china_provinces.json")
    with open(gj, encoding="utf-8") as f:
        return json.load(f)["features"]


def _rings_of(feature):
    """Exterior rings of a GeoJSON Polygon/MultiPolygon as (N,2) arrays."""
    geom = feature.get("geometry") or {}
    polys = []
    if geom.get("type") == "Polygon":
        polys = [geom["coordinates"]]
    elif geom.get("type") == "MultiPolygon":
        polys = geom["coordinates"]
    out = []
    for poly in polys:
        if poly:
            out.append(np.asarray(poly[0], dtype=float))   # exterior ring
    return out


def plot_fig4(w, trends_df):
    """Real-boundary map of southern endemic provinces (Lancet style).

    Replaces the earlier schematic rectangles: provinces are drawn from the
    DataV China province GeoJSON (full territory incl. Taiwan, Hong Kong,
    Macao and a South China Sea inset with the island-dash line).
    """
    import json
    set_style()
    sig = _length_change_signal(w, trends_df)
    features = _load_china_geojson()

    fig, ax = plt.subplots(figsize=(7.4, 7.0))
    ax.set_xlim(73, 136)
    ax.set_ylim(2.5, 55)
    ax.axis("off")
    ax.set_aspect(1.0)

    CONTEXT_FC, CONTEXT_EC = "#F2F2F0", "#ADADAD"
    INSUF_FC, NODATA_FC = "#D4D4D4", "#F2F2F2"
    TREND_FC = "#D7301F"

    focal = {"广东": "trend", "云南": "insufficient", "浙江": "insufficient",
             "福建": "insufficient", "广西": "no_data", "海南": "no_data"}
    jd_feature = None
    for feat in features:
        name = feat.get("properties", {}).get("name", "")
        adcode = feat.get("properties", {}).get("adcode", "")
        if adcode == "100000_JD":
            jd_feature = feat
            continue
        cat = focal.get(name[:2], "context")
        for ring in _rings_of(feat):
            poly = MplPolygon(ring, closed=True, zorder=2)
            if cat == "trend":
                poly.set_facecolor(TREND_FC); poly.set_edgecolor("0.25")
                poly.set_linewidth(0.4); poly.set_alpha(0.92)
            elif cat == "insufficient":
                poly.set_facecolor(INSUF_FC); poly.set_hatch("////")
                poly.set_edgecolor("0.10"); poly.set_linewidth(0.45)
            elif cat == "no_data":
                poly.set_facecolor(NODATA_FC); poly.set_hatch(".....")
                poly.set_edgecolor("0.30"); poly.set_linewidth(0.45)
            else:
                poly.set_facecolor(CONTEXT_FC); poly.set_edgecolor(CONTEXT_EC)
                poly.set_linewidth(0.3)
            ax.add_patch(poly)

    # focal province name labels (fixed, well-known anchor points)
    label_pos = {"广东": (112.6, 23.4), "广西": (108.4, 23.9),
                 "海南": (109.6, 19.1), "云南": (101.2, 24.6),
                 "福建": (117.6, 27.6), "浙江": (119.6, 29.6)}
    gd = sig.get("广东", {})
    label_names = {"广东": "Guangdong", "广西": "Guangxi", "海南": "Hainan",
                   "云南": "Yunnan", "福建": "Fujian", "浙江": "Zhejiang"}
    for name, (lx, ly) in label_pos.items():
        cat = focal.get(name)
        col = TREND_FC if cat == "trend" else "0.15"
        ax.text(lx, ly, label_names[name], ha="center", va="center", fontsize=7,
                fontweight="bold", color="0.15", zorder=6,
                bbox=dict(facecolor="white", alpha=0.8, edgecolor="none", pad=0.5))
    if gd.get("status") == "trend":
        ax.text(104.5, 12.8,
                f"Guangdong (exploratory):\n"
                f"Sen {gd['slope']:+.2f} mo/yr, \u03c4={gd['tau']:+.2f},\n"
                f"p={gd['p']:.3f}, {gd['period']}, n={gd['n']}",
                ha="left", va="top", fontsize=7, color=TREND_FC, zorder=7,
                bbox=dict(facecolor="white", alpha=0.92, edgecolor="0.75",
                          linewidth=0.4, pad=1.8))

    legend_handles = [
        Rectangle((0, 0), 1, 1, facecolor=TREND_FC, edgecolor="0.25",
                  label="window lengthening (Guangdong, exploratory)"),
        Rectangle((0, 0), 1, 1, facecolor=INSUF_FC, hatch="////",
                  edgecolor="0.10",
                  label="insufficient data (\u2264 1 valid window year)"),
        Rectangle((0, 0), 1, 1, facecolor=NODATA_FC, hatch=".....",
                  edgecolor="0.30", label="no window data"),
        Rectangle((0, 0), 1, 1, facecolor=CONTEXT_FC, edgecolor=CONTEXT_EC,
                  label="other provinces (not analysed)"),
    ]
    ax.legend(handles=legend_handles, loc="lower left", fontsize=7,
              frameon=True, framealpha=0.95, edgecolor="0.8",
              bbox_to_anchor=(0.015, 0.02))

    ax.text(73.5, 54.2,
            "Provincial dengue records are available only for 1998\u20132009; "
            "only China (national)\nand Guangdong carry a usable multi-year "
            "window-length series. Others are marked\ninsufficient / no data "
            "rather than estimated.",
            ha="left", va="top", fontsize=6.8, color="0.35")

    # Preserve the full-territory source including its maritime feature.
    inset = ax.inset_axes([0.78, 0.025, 0.20, 0.25])
    for feat in features:
        for ring in _rings_of(feat):
            inset.add_patch(MplPolygon(ring, closed=True, facecolor=CONTEXT_FC,
                                      edgecolor=CONTEXT_EC, linewidth=0.35))
    inset.set_xlim(105, 125)
    inset.set_ylim(3, 25)
    inset.set_aspect(1)
    inset.set_xticks([])
    inset.set_yticks([])
    inset.text(0.5, 1.02, "South China Sea", transform=inset.transAxes,
               ha="center", fontsize=7)
    fig.tight_layout()
    save_fig(fig, OUT_FIG4)
    print(f"[wrote] {OUT_FIG4}.png/.pdf")


# ---------------------------------------------------------------------------
# output assertions
# ---------------------------------------------------------------------------
def run_output_assertions():
    files = [OUT_FIG1 + ".png", OUT_FIG1 + ".pdf",
             OUT_FIG4 + ".png", OUT_FIG4 + ".pdf"]
    ok = True
    for f in files:
        if not os.path.exists(f):
            print(f"[FAIL] missing output {f}")
            ok = False
            continue
        size = os.path.getsize(f)
        if size <= 10_000:   # >10 kB required
            print(f"[FAIL] output too small ({size} B): {f}")
            ok = False
        else:
            print(f"[PASS] {os.path.basename(f)} ({size} B)")
    return ok


# ---------------------------------------------------------------------------
# main
# ---------------------------------------------------------------------------
def main():
    print("=" * 62)
    print("make_figures_8a — publication figures 1 & 4")
    print("=" * 62)

    print("[1/4] input assertions")
    if not run_input_assertions():
        return 1

    print("[2/4] loading data")
    w = load_windows()
    trends_df = pd.read_csv(IN_TRENDS, encoding="utf-8-sig")

    print("[3/4] plotting")
    plot_fig1(w, trends_df)
    plot_fig4(w, trends_df)

    print("[4/4] output assertions")
    ok = run_output_assertions()
    print("\nDONE. ok =", ok)
    return 0 if ok else 1


if __name__ == "__main__":
    sys.exit(main())
