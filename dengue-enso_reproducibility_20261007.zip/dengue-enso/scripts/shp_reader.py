# -*- coding: utf-8 -*-
"""Minimal ESRI shapefile (.shp) polygon/polyline reader (no geopandas).

Returns a list of rings, each an (N, 2) float array of (x, y) coordinates.
Supports shape types 3 (PolyLine) and 5 (Polygon); other types are skipped.
"""
import struct
from pathlib import Path

import numpy as np


def read_shp(path) -> list:
    buf = Path(path).read_bytes()
    file_len = struct.unpack(">i", buf[24:28])[0] * 2
    pos = 100
    rings = []
    while pos + 8 <= min(file_len, len(buf)):
        _rec_no, content_len = struct.unpack(">ii", buf[pos:pos + 8])
        pos += 8
        content = buf[pos:pos + content_len * 2]
        pos += content_len * 2
        if len(content) < 4:
            continue
        shape_type = struct.unpack("<i", content[:4])[0]
        if shape_type == 0:
            continue
        if shape_type in (3, 5):
            n_parts, n_points = struct.unpack("<ii", content[36:44])
            parts = struct.unpack(f"<{n_parts}i", content[44:44 + 4 * n_parts])
            pts_off = 44 + 4 * n_parts
            pts = np.frombuffer(content[pts_off:pts_off + 16 * n_points],
                                dtype="<f8").reshape(-1, 2)
            bounds = list(parts) + [n_points]
            for a, b in zip(bounds[:-1], bounds[1:]):
                if b - a >= 3:
                    rings.append(pts[a:b].copy())
    return rings


def sinusoidal(rings, lat0_scale=True):
    """Apply a sinusoidal equal-area projection: x' = lon*cos(lat), y' = lat."""
    out = []
    for r in rings:
        lon = r[:, 0]
        lat = r[:, 1]
        if lat0_scale:
            out.append(np.column_stack([lon * np.cos(np.deg2rad(lat)), lat]))
        else:
            out.append(r.copy())
    return out


def project_points(lon, lat, lat0_scale=True):
    lon = np.asarray(lon, float)
    lat = np.asarray(lat, float)
    if lat0_scale:
        return lon * np.cos(np.deg2rad(lat)), lat
    return lon, lat
