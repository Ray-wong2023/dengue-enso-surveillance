# -*- coding: utf-8 -*-
"""
S2: global season-window extraction (Plan B).

Generalises the frozen China pipeline (scripts/season_window.py) to any
admin unit in the OpenDengue temporal extract:

  * input : results/global_unit_month.csv (unit, ym, dengue_total, adm labels;
            written by scripts/global_coverage_audit.py)
  * method: cumulative case-fraction thresholds (5-95%, 1-99%, 10-90%);
            year must have >= MIN_MONTHS observed months and >= MIN_CASES
            annual cases, otherwise no window is defined;
  * missing months are filled with 0 (same convention as China) but each
    year carries `n_months` and `complete12` flags, and the primary global
    analysis will require 12-month years while 10-11-month years serve as a
    sensitivity stratum.

Validation anchor: `python scripts/global_window_extraction.py --validate`
recomputes the China national series from data/raw/china_monthly_cases.csv
with this code path and asserts it reproduces data/processed/windows.csv
(national, all three thresholds) exactly. Only if that passes may the global
table be generated.

Outputs:
  results/global_windows.csv        unit, year, threshold, onset/offset/
                                    length/peak, n_months, complete12,
                                    annual_cases, low_case_year
  data/processed/global_windows_meta.json  run metadata (counts, params)
"""
import json
import os
import sys
from pathlib import Path

import numpy as np
import pandas as pd

ROOT = Path(os.getcwd()).resolve()
assert (ROOT / "results").is_dir(), "run from the dengue-enso project root"
RES = ROOT / "results"
RAW = ROOT / "data" / "raw"
PROC = ROOT / "data" / "processed"

IN_UNIT_MONTH = RES / "global_unit_month.csv"
IN_CHINA = RAW / "china_monthly_cases.csv"
FROZEN_CHINA_WINDOWS = PROC / "windows.csv"
OUT_WINDOWS = RES / "global_windows.csv"
OUT_META = PROC / "global_windows_meta.json"

THRESHOLDS = [(0.05, 0.95), (0.01, 0.99), (0.10, 0.90)]
MIN_MONTHS = 10
MIN_CASES = 30


def _safe(p: Path) -> Path:
    rp = p.resolve()
    if not str(rp).startswith(str(ROOT)):
        raise ValueError(f"path escapes project root: {rp}")
    return rp


def extract_window(annual_series: pd.Series, p_low=0.05, p_high=0.95):
    """Identical logic to season_window.extract_window (12-month series)."""
    total = annual_series.sum()
    if total < MIN_CASES:
        return (None, None, None, None)
    cum = annual_series.cumsum() / total
    if not (cum >= p_high).any():
        return (None, None, None, None)
    onset = int((cum >= p_low).argmax()) + 1
    offset = int((cum >= p_high).argmax()) + 1
    length = offset - onset + 1
    peak = int(annual_series.idxmax())
    return (onset, offset, length, peak)


def windows_from_month_table(df: pd.DataFrame, unit_col: str):
    """df: columns [unit_col, year, month, cases] -> window rows."""
    rows = []
    for (unit, year), g in df.groupby([unit_col, "year"], sort=False):
        n_months = int(g["month"].nunique())
        ser = pd.Series(0.0, index=range(1, 13))
        for m, c in zip(g["month"].astype(int), g["cases"].astype(float)):
            ser.loc[m] = c
        annual = float(ser.sum())
        if n_months < MIN_MONTHS:
            rows.append({"unit": unit, "year": int(year), "threshold": "all",
                         "onset_month": np.nan, "offset_month": np.nan,
                         "length_months": np.nan, "peak_month": np.nan,
                         "n_months": n_months, "complete12": 0,
                         "annual_cases": annual, "low_case_year": int(annual < MIN_CASES)})
            continue
        for (pl, ph) in THRESHOLDS:
            on, off, ln, pk = extract_window(ser, pl, ph)
            rows.append({"unit": unit, "year": int(year),
                         "threshold": f"({pl:.2f},{ph:.2f})",
                         "onset_month": on, "offset_month": off,
                         "length_months": ln, "peak_month": pk,
                         "n_months": n_months,
                         "complete12": int(n_months == 12),
                         "annual_cases": annual,
                         "low_case_year": int(annual < MIN_CASES)})
    return pd.DataFrame(rows)


def validate_china():
    """Reproduce the frozen China national windows with this code path."""
    cm = pd.read_csv(_safe(IN_CHINA), encoding="utf-8-sig")
    cm = cm[cm["province"] == "全国"].copy()
    cm = cm.rename(columns={"province": "unit", "cases": "cases"})
    cm["year"] = cm["year"].astype(int)
    cm["month"] = cm["month"].astype(int)
    new = windows_from_month_table(cm[["unit", "year", "month", "cases"]], "unit")
    new = new[new["threshold"] != "all"]
    frozen = pd.read_csv(_safe(FROZEN_CHINA_WINDOWS), encoding="utf-8-sig")
    frozen = frozen[(frozen["province"] == "全国") &
                    (frozen["year"].between(1998, 2024))].copy()
    frozen["unit"] = "全国"
    m = new.merge(frozen, on=["unit", "year", "threshold"],
                  suffixes=("_new", "_frozen"), how="inner")
    if len(m) == 0:
        print("[FAIL] validation merge empty")
        return False
    # compare only rows where the frozen file defines a window (its low-case
    # rule differs for years < 30 cases, handled by our low_case_year flag)
    for col in ("onset_month", "offset_month", "length_months", "peak_month"):
        a = m[f"{col}_new"]
        b = m[f"{col}_frozen"]
        both = a.notna() & b.notna()
        diff = (a[both].astype(float) != b[both].astype(float))
        n_diff = int(diff.sum())
        print(f"  {col}: compared {int(both.sum())} rows, mismatches {n_diff}")
        if n_diff:
            bad = m.loc[both & (a.astype(float) != b.astype(float)),
                        ["unit", "year", "threshold", f"{col}_new", f"{col}_frozen"]]
            print(bad.head(10).to_string(index=False))
            return False
    print(f"  [PASS] global extractor reproduces frozen China windows "
          f"({len(m)} unit-year-threshold rows)")
    return True


def main():
    validate = "--validate" in sys.argv
    print("=" * 66)
    print("Step 1: validation anchor against frozen China windows")
    if not validate_china():
        print("[FAIL] validation failed — not generating the global table")
        return 1
    if validate:
        print("  (--validate only; input and result tables unchanged)")
        return 0

    print("=" * 66)
    print("Step 2: load global unit-month table")
    if not IN_UNIT_MONTH.exists():
        print(f"[FAIL] missing {IN_UNIT_MONTH} — run global_coverage_audit.py first")
        return 1
    um = pd.read_csv(_safe(IN_UNIT_MONTH), encoding="utf-8-sig")
    um = um.rename(columns={"dengue_total": "cases"})
    um = um[["unit", "yr", "ym", "cases", "country"]].rename(columns={"yr": "year"})
    um["year"] = um["year"].astype(int)
    um["month"] = pd.PeriodIndex(um["ym"], freq="M").month
    print(f"  unit-months: {len(um):,} | units: {um['unit'].nunique():,}")

    print("=" * 66)
    print("Step 3: extract windows (3 threshold pairs, >=10 months, >=30 cases)")
    w = windows_from_month_table(um[["unit", "year", "month", "cases"]], "unit")
    w = w.merge(um.groupby("unit", as_index=False)["country"].first(), on="unit",
                how="left")
    w.to_csv(OUT_WINDOWS, index=False, encoding="utf-8-sig")
    print(f"[wrote] {OUT_WINDOWS} ({len(w):,} rows)")
    valid = w[(w["threshold"] != "all")].dropna(subset=["onset_month"])
    print(f"  valid windows: {len(valid):,} | units with >=1 window: "
          f"{valid['unit'].nunique():,}")
    meta = {
        "thresholds": [f"({a:.2f},{b:.2f})" for a, b in THRESHOLDS],
        "min_months": MIN_MONTHS, "min_cases": MIN_CASES,
        "units_total": int(w["unit"].nunique()),
        "units_with_window": int(valid["unit"].nunique()),
        "valid_windows": int(len(valid)),
        "rows": int(len(w)),
        "source": "OpenDengue Temporal_extract_V1_3 (Week->Month summed)",
    }
    OUT_META.write_text(json.dumps(meta, indent=2, ensure_ascii=False),
                        encoding="utf-8")
    print(f"[wrote] {OUT_META}")

    print("=" * 66)
    print("Assertions")
    ok = True
    if len(w) == 0:
        print("[FAIL] empty window table")
        ok = False
    v = w.dropna(subset=["onset_month", "offset_month"])
    if len(v) and not (v["onset_month"] <= v["offset_month"]).all():
        print("[FAIL] onset > offset")
        ok = False
    if len(v) and not v["length_months"].between(1, 12).all():
        print("[FAIL] length out of range")
        ok = False
    print(f"DONE. ok = {ok}")
    return 0 if ok else 1


if __name__ == "__main__":
    sys.exit(main())
