# -*- coding: utf-8 -*-
"""
S4 (part 1): global meta-analysis of season-window trends.

Pools the per-unit trend in each window metric (random-effects,
DerSimonian-Laird) to test formally whether season windows have moved
globally, overall and in the long-series stratum where power is real.

For each unit x metric the effect size is the OLS slope of the metric on year
(months/yr) with its standard error, computed on the same complete-12-month
years used by the trend engine. Pooling is repeated for:
  * all units with >= MIN_N years
  * the long-series stratum (n >= 20 years, where the China module showed
    power is adequate)
  * high-quality temperature/site matches only

Outputs:
  results/global_meta_analysis.csv
  results/global_meta_report.md
"""
import os
import sys
from pathlib import Path

import numpy as np
import pandas as pd
from scipy import stats

ROOT = Path(os.getcwd()).resolve()
assert (ROOT / "results").is_dir(), "run from the dengue-enso project root"
RES = ROOT / "results"
WINDOWS = RES / "global_windows.csv"
TRENDS = RES / "global_trends.csv"
WARM = RES / "global_warming_rates.csv"
DET = RES / "global_detectability.csv"
OUT = RES / "global_meta_analysis.csv"
OUT_REPORT = RES / "global_meta_report.md"

PRIMARY_THR = "(0.05,0.95)"
METRIC_COL = {"onset": "onset_month", "offset": "offset_month",
              "length": "length_months", "peak": "peak_month"}
Z = 1.959964


def _safe(p: Path) -> Path:
    rp = p.resolve()
    if not str(rp).startswith(str(ROOT)):
        raise ValueError(f"path escapes project root: {rp}")
    return rp


def unit_effects(w: pd.DataFrame):
    """OLS slope + SE per unit x metric on complete-12-month years."""
    rows = []
    for (unit, metric), g in w.groupby(["unit", "_metric"]):
        g = g.dropna(subset=["_value"]).sort_values("year")
        if len(g) < 6:
            continue
        x = g["year"].to_numpy(float)
        y = g["_value"].to_numpy(float)
        if np.std(x) == 0 or np.std(y) == 0:
            continue
        slope, inter, r, p, se = stats.linregress(x, y)
        rows.append({"unit": unit, "metric": metric, "n": len(g),
                     "slope": float(slope), "se": float(se), "p": float(p),
                     "first_year": int(x[0]), "last_year": int(x[-1]),
                     "last_year_f": float(x[-1])})
    return pd.DataFrame(rows)


def dl_pool(slopes, ses):
    """DerSimonian-Laird random-effects pooling."""
    slopes = np.asarray(slopes, float)
    ses = np.asarray(ses, float)
    ok = np.isfinite(slopes) & np.isfinite(ses) & (ses > 0)
    slopes, ses = slopes[ok], ses[ok]
    k = len(slopes)
    if k < 3:
        return None
    w = 1.0 / ses ** 2
    fixed = float(np.sum(w * slopes) / np.sum(w))
    Q = float(np.sum(w * (slopes - fixed) ** 2))
    df = k - 1
    C = float(np.sum(w) - np.sum(w ** 2) / np.sum(w))
    tau2 = max(0.0, (Q - df) / C) if C > 0 else 0.0
    wr = 1.0 / (ses ** 2 + tau2)
    pooled = float(np.sum(wr * slopes) / np.sum(wr))
    se_pool = float(np.sqrt(1.0 / np.sum(wr)))
    z = pooled / se_pool if se_pool > 0 else np.nan
    p = 2 * (1 - stats.norm.cdf(abs(z))) if np.isfinite(z) else np.nan
    i2 = max(0.0, (Q - df) / Q) * 100 if Q > 0 else 0.0
    return {"k": k, "pooled_slope": pooled, "se": se_pool,
            "ci_lo": pooled - Z * se_pool, "ci_hi": pooled + Z * se_pool,
            "z": z, "p": p, "Q": Q, "I2_pct": i2, "tau2": tau2,
            "fixed_slope": fixed}


def main():
    print("=" * 66)
    print("Step 1: per-unit effect sizes (OLS slope, months/yr)")
    w = pd.read_csv(_safe(WINDOWS), encoding="utf-8-sig")
    w = w[(w["threshold"] == PRIMARY_THR) & (w["complete12"] == 1)]
    eff = []
    for metric, col in METRIC_COL.items():
        sub = w[["unit", "country", "year", col]].rename(columns={col: "_value"})
        sub["_metric"] = metric
        eff.append(sub.dropna(subset=["_value"]))
    weff = pd.concat(eff, ignore_index=True)
    eff_df = unit_effects(weff)
    print(f"  unit x metric effects: {len(eff_df):,} "
          f"({eff_df['unit'].nunique():,} units)")
    det = pd.read_csv(_safe(DET), encoding="utf-8-sig") if DET.is_file() else None
    hi_units = set()
    if det is not None and "site_quality" in det.columns:
        hi_units = set(det[det["site_quality"] == "high"]["unit"].unique())

    print("=" * 66)
    print("Step 2: pooling per metric x stratum")
    rows = []
    for metric in METRIC_COL:
        sub = eff_df[eff_df["metric"] == metric]
        strata = [("all", sub),
                  ("n_ge_10", sub[sub["n"] >= 10]),
                  ("n_ge_20", sub[sub["n"] >= 20]),
                  ("n_ge_25", sub[sub["n"] >= 25]),
                  ("high_quality_site", sub[sub["unit"].isin(hi_units)])]
        for name, s in strata:
            pool = dl_pool(s["slope"], s["se"])
            if pool is None:
                continue
            rows.append({"metric": metric, "stratum": name, **pool})
            print(f"  {metric:7s} {name:18s} k={pool['k']:4d} "
                  f"pooled={pool['pooled_slope']:+.4f} mo/yr "
                  f"[{pool['ci_lo']:+.4f},{pool['ci_hi']:+.4f}] p={pool['p']:.4f} "
                  f"I2={pool['I2_pct']:.0f}%")
    meta = pd.DataFrame(rows)
    meta.to_csv(_safe(OUT), index=False, encoding="utf-8-sig")
    print(f"[wrote] {OUT}")

    print("=" * 66)
    print("Step 3: expected trend for comparison")
    exp_mean = np.nan
    if det is not None and "beta_exp_moyr" in det.columns:
        exp_mean = float(det["beta_exp_moyr"].median())
        print(f"  median expected trend (psi x warming) = {exp_mean:+.4f} mo/yr "
              f"across {det['unit'].nunique()} units")

    lines = ["# S4 global meta-analysis of season-window trends", "",
             "Random-effects (DerSimonian-Laird) pooling of per-unit OLS",
             "slopes (months/yr) of each window metric on year.", "",
             f"Unit x metric effects: {len(eff_df):,} "
             f"({eff_df['unit'].nunique():,} units).", "",
             "| metric | stratum | k units | pooled slope (mo/yr) | 95% CI | p | I2 |",
             "|---|---|---|---|---|---|---|"]
    for _, r in meta.iterrows():
        lines.append(f"| {r['metric']} | {r['stratum']} | {int(r['k'])} | "
                     f"{r['pooled_slope']:+.4f} | "
                     f"[{r['ci_lo']:+.4f}, {r['ci_hi']:+.4f}] | "
                     f"{r['p']:.4f} | {r['I2_pct']:.0f}% |")
    if np.isfinite(exp_mean):
        lines += ["", f"Median model-expected trend across units: "
                      f"{exp_mean:+.4f} mo/yr (psi x local warming)."]
    OUT_REPORT.write_text("\n".join(lines), encoding="utf-8")
    print(f"[wrote] {OUT_REPORT}")

    print("=" * 66)
    print("Assertions")
    ok = True
    if len(meta) == 0:
        print("[FAIL] empty meta table")
        ok = False
    if not meta["ci_lo"].le(meta["ci_hi"]).all():
        print("[FAIL] CI ordering")
        ok = False
    print(f"DONE. ok = {ok}")
    return 0 if ok else 1


if __name__ == "__main__":
    sys.exit(main())
