"""Rebuild review artwork using verified Zemin panel references for layout.

No reference-paper statistics are transferred to surveillance data.
Primary analysis values are read from result tables; revisions are explicit.
"""
import argparse
import hashlib
import io
import json
from pathlib import Path
import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
from matplotlib.colors import TwoSlopeNorm
from matplotlib.ticker import LogFormatterSciNotation
from matplotlib.patches import Rectangle, Polygon
from PIL import Image
import make_global_figures as G
import style_journal as S

ROOT = Path(__file__).resolve().parents[1]
OUT = ROOT / 'figures'
OUT.mkdir(exist_ok=True)
SOURCE = OUT / 'source_data'
SOURCE.mkdir(exist_ok=True)
C = S.SERIES_COLORS
METRICS = G.METRICS
records = []
DATA = None


def panel(ax, letter):
    S.panel_letter(ax, letter, dx=0, dy=1.035)


def clean(ax, letter):
    ax.clear()
    panel(ax, letter)


def heatmap(ax, table, cmap='Blues', vmin=0, vmax=None, fmt='.1f'):
    values = table.to_numpy(float)
    im = ax.imshow(values, aspect='auto', cmap=cmap, vmin=vmin, vmax=vmax)
    ax.set_xticks(range(len(table.columns)), table.columns)
    ax.set_yticks(range(len(table)), table.index)
    ax.tick_params(length=0)
    for i in range(len(table)):
        for j in range(len(table.columns)):
            v = values[i, j]
            ax.text(j, i, format(v, fmt), ha='center', va='center', fontsize=8,
                    color='white' if im.norm(v) > .57 else '#17395C')
    for spine in ax.spines.values():
        spine.set_visible(False)
    return im


def rebuild(fig, stem):
    axes = [a for a in fig.axes if any(t.get_text() in list('ABCDEF') for t in a.texts)]
    if stem == 'global_fig1_coverage':
        # Keep map scale; reduce marker occlusion and give counts a shared axis.
        for coll in axes[0].collections:
            if len(coll.get_offsets()) > 10:
                coll.set_sizes(np.full(len(coll.get_offsets()), 12))
        axes[2].set_xlabel('screening-tier units')
        for bar in axes[2].patches:
            if hasattr(bar, 'get_width'):
                axes[2].text(bar.get_width()+2, bar.get_y()+bar.get_height()/2,
                             str(int(bar.get_width())), va='center', fontsize=7.5)
    if stem in ('global_fig2_structure', 'global_fig3_warming'):
        for index in ([0] if 'fig2' in stem else [1]):
            ax = axes[index]
            coll = next(c for c in ax.collections if len(c.get_offsets()) > 20)
            xy = np.asarray(coll.get_offsets())
            coll.remove()
            ax.hexbin(xy[:, 0], xy[:, 1], gridsize=(24, 12), mincnt=1,
                      cmap='Blues', linewidths=0, zorder=1)
            ax.text(.97, .96, 'shade: unit count', transform=ax.transAxes,
                    ha='right', va='top', fontsize=7)
        ax = axes[2]
        for patch in ax.patches:
            patch.set_alpha(.7)
    if stem == 'global_fig4_trends':
        ax = axes[1]
        clean(ax, 'B')
        tr = DATA['trends']
        tr = tr[(tr.threshold == G.PRIMARY_THR) & (tr.stratum == 'complete12') &
                (tr.metric == 'length')]
        edges = np.linspace(-.4, .4, 17)
        grid, xe, ye = np.histogram2d(tr.n_years, tr.sen_slope_yr,
                                    bins=[np.arange(5.5, 31.6, 1), edges])
        ax.pcolormesh(xe, ye, grid.T, cmap='Blues', shading='flat')
        sig = tr[tr.mk_p < .05]
        ax.scatter(sig.n_years, sig.sen_slope_yr, s=12, facecolors='none',
                   edgecolors=C['vermillion'], linewidths=.7)
        ax.axhline(0, color='.4', lw=.6, ls='--')
        ax.set_ylim(-.4, .4)
        ax.set_xlabel('complete window years')
        ax.set_ylabel('Sen slope (months/year)')
        ax.text(.98, .04, 'shade: count; orange: nominal p<0.05',
                transform=ax.transAxes, ha='right', fontsize=7)
        ax.text(.02, .96, f'{(tr.sen_slope_yr.abs() > .4).sum()} outside ±0.4',
                transform=ax.transAxes, va='top', fontsize=7)
        pd.DataFrame(grid.T).to_csv(SOURCE/f'{stem}_B_counts.csv',index=False)
        ax=axes[3]
        clean(ax,'D')
        thr,med,_=G._threshold_medians(DATA)
        bins=np.arange(.5,13.5,1)
        counts=np.array([np.histogram(med[t],bins=bins)[0] for t,_,_ in thr])
        ax.imshow(counts,aspect='auto',cmap='Blues',vmin=0,vmax=counts.max())
        ax.set_xticks([0,3,7,11],[1,4,8,12])
        ax.set_yticks(range(3),[label.replace(' (primary)','') for _,label,_ in thr],fontsize=7.5)
        ax.set_xlabel('median window length (months)')
        ax.text(.98,.04,'shade: unit count',transform=ax.transAxes,ha='right',fontsize=7)
        pd.DataFrame(counts,index=[label for _,label,_ in thr],columns=range(1,13)).to_csv(
            SOURCE/f'{stem}_D_counts.csv')
    if stem == 'global_fig5_detect':
        axes[0].yaxis.set_major_locator(plt.LogLocator(base=10))
        axes[0].yaxis.set_major_formatter(LogFormatterSciNotation())
        for text in axes[5].texts:
            if 'never' in text.get_text():
                text.set_text(text.get_text().replace('never','not within +60 yr'))
                text.set_fontsize(7)
        axes[2].text(.02,.85,'conditional: reached within +60 yr',
                     transform=axes[2].transAxes,va='top',fontsize=7)
        ax = axes[4]
        clean(ax, 'E')
        det = DATA['det'][DATA['det'].n_years >= 10]
        table = pd.DataFrame({G.TARGET_LABELS[t]:
            [100*(det.loc[det.metric == m, f'R_target_{t:g}'] >= 1).mean()
             for m in METRICS] for t in G.TARGETS}, index=[G.NICE[m] for m in METRICS])
        heatmap(ax, table, vmax=100)
        ax.set_xlabel('reference rate (months/decade)')
        ax.text(.5, -.40, 'cells: % with 80% power', transform=ax.transAxes,
                ha='center', fontsize=7.5)
        table.to_csv(SOURCE / f'{stem}_E.csv', encoding='utf-8-sig')
    if stem == 'global_fig6_china':
        ax = axes[0]
        clean(ax, 'A')
        w = DATA['cn_windows']
        w = w[(w.province == '全国') & (w.threshold == G.PRIMARY_THR) &
              w.year.between(2012, 2024)]
        for y in range(2012, 2025):
            g = w[w.year == y]
            if g.empty or pd.isna(g.onset_month.iloc[0]):
                ax.axvspan(y-.4, y+.4, color='.88')
                ax.text(y, 5, 'no window', rotation=90, ha='center', fontsize=7)
                continue
            r = g.iloc[0]
            ax.add_patch(Rectangle((y-.28, r.onset_month-.5), .56,
                                  r.offset_month-r.onset_month+1,
                                  facecolor=C['blue'], hatch='///' if y == 2022 else None,
                                  edgecolor=C['navy'], linewidth=.4))
            ax.scatter(y, r.peak_month, s=16, color=C['vermillion'],
                       edgecolor='white', lw=.5, zorder=3)
        ax.axvspan(2019.6, 2021.4, color='.7', alpha=.18, zorder=0)
        ax.set_xlim(2011.4, 2024.6)
        ax.set_ylim(.5, 12.5)
        ax.set_xticks(range(2012, 2025, 2))
        ax.tick_params(axis='x', rotation=45)
        ax.set_yticks([1, 4, 7, 10, 12])
        ax.set_ylabel('month')
        ax.text(.02, .98, '11 defined windows; 2022 incomplete',
                transform=ax.transAxes, va='top', fontsize=7)
        ax=axes[2]
        clean(ax,'C')
        loo=DATA['cn_loo']
        im=ax.imshow(loo[['spring_coef']].to_numpy(),aspect='auto',cmap='RdBu_r',
                     norm=TwoSlopeNorm(vmin=-1.5,vcenter=0,vmax=1.5))
        ax.set_yticks(range(len(loo)),loo.omitted_year,fontsize=7)
        ax.set_xticks([0,1.6],['coefficient','nominal p'])
        ax.set_xlim(-.6,2.5)
        ax.tick_params(length=0)
        for i,r in enumerate(loo.itertuples()):
            ax.text(0,i,f'{r.spring_coef:+.2f}',ha='center',va='center',fontsize=7,
                    color='white' if im.norm(r.spring_coef)<.22 else C['navy'])
            ax.text(1.6,i,f'{r.spring_p:.3f}',ha='center',va='center',fontsize=7,
                    color=C['vermillion'] if r.omitted_year==2014 else '.3')
        ax.set_xlabel('year omitted; effect in months/SD')
        for spine in ax.spines.values():spine.set_visible(False)
        fig.colorbar(im,ax=ax,fraction=.045,pad=.04,ticks=[-1.5,0,1.5]).set_label('months/SD',fontsize=7)
    if stem == 'global_fig7_intensity':
        ax = axes[1]
        clean(ax, 'B')
        g = DATA['inten'].dropna(subset=['r2_intensity', 'r2_temp'])
        ax.hexbin(g.r2_temp, g.r2_intensity, gridsize=28, cmap='Blues', mincnt=1)
        ax.plot([0, 1], [0, 1], color='.4', lw=.7, ls='--')
        ax.set(xlim=(0, 1), ylim=(0, 1), xlabel='R² temperature', ylabel='R² intensity')
        ax.text(.98, .03, 'shade: unit–metric fit count', transform=ax.transAxes,
                ha='right', fontsize=7)
    if stem == 'global_fig8_psi':
        ax = axes[2]
        clean(ax, 'C')
        g = DATA['psi']
        g = g[(g.level == 'unit') & (g.temp_metric == 'annual_mean')]
        count = g.groupby('metric').p.agg(total='size', significant=lambda x: (x < .05).sum())
        count = count.reindex(METRICS)
        perc = count.significant/count.total*100
        ax.barh(range(4), perc, color=C['blue'], height=.55)
        ax.set_yticks(range(4), [G.NICE[m] for m in METRICS])
        ax.set_xlim(0, 15)
        ax.invert_yaxis()
        ax.set_xlabel('nominal p<0.05 (%)')
        for i, (m, r) in enumerate(count.iterrows()):
            ax.text(perc[m]+.25, i, f'{int(r.significant)}/{int(r.total)}',
                    va='center', fontsize=7.5)
        count.to_csv(SOURCE / f'{stem}_C.csv', encoding='utf-8-sig')


def save(fig, path):
    stem = Path(path).name
    if stem == 'fig4_map':
        labels={'广东':'Guangdong','广西':'Guangxi','海南':'Hainan',
                '云南':'Yunnan','福建':'Fujian','浙江':'Zhejiang'}
        for ax in fig.axes:
            for text in ax.texts:
                if text.get_text() in labels:
                    text.set_text(labels[text.get_text()])
                    text.set_fontsize(7)
    if stem.startswith('global_fig'):
        rebuild(fig, stem)
    from matplotlib.text import Text
    for item in fig.findobj(Text):
        if item.get_fontsize() < 7:
            item.set_fontsize(7)
    fig.canvas.draw()
    # Exact rendered primitives supplement the input tables for each panel.
    for i, ax in enumerate(fig.axes):
        letter = next((t.get_text() for t in ax.texts if t.get_text() in list('ABCDEF')), str(i))
        primitives = []
        for k, line in enumerate(ax.lines):
            for x, y in zip(line.get_xdata(), line.get_ydata()):
                primitives.append(dict(kind='line', artist=k, x=x, y=y))
        for k, collection in enumerate(ax.collections):
            for xy in collection.get_offsets():
                primitives.append(dict(kind='collection_offset', artist=k, x=xy[0], y=xy[1]))
        for k, patch in enumerate(ax.patches):
            if isinstance(patch, Rectangle):
                primitives.append(dict(kind='rectangle', artist=k, x=patch.get_x(),
                    y=patch.get_y(), width=patch.get_width(), height=patch.get_height()))
        pd.DataFrame(primitives).to_csv(SOURCE / f'{stem}_{letter}_primitives.csv', index=False)
        records.append(dict(figure=stem, panel=letter,
            reference='Zemin Zhang coauthor; Shi et al. Nature 2025; Fig.2c / Fig.4f',
            doi='10.1038/s41586-025-09053-4', evidence='skill library: source tables, code and prior figure review',
            transfer='layout only: aligned matrices and genuine distributions; CI retained where required',
            estimand=ax.get_ylabel(), display_summary=ax.get_xlabel(),
            ci_definition='95% model intervals when drawn; no new significance generated',
            independent_unit='country; administrative units nested; annual repeated observations',
            denominator='panel-specific filtered rows; see figure legends and input index',
            exclusion='complete12 primary globally; China frozen 11-year series includes incomplete 2022',
            transform='see axis labels and script; no source-paper statistics transferred',
            ordering='fixed metric dictionary; original ID ordering retained',
            tests='original result tables; nominal unit p, no multiplicity correction',
            role='definition / effect / heterogeneity / validation; see layout_plan.md',
            source_files='source_data/input_index.tsv', input_columns='source_data/input_index.tsv',
            source_sha256='source_data/input_index.tsv',
            output=f'figures/{stem}.pdf; figures/{stem}.svg'))
    kw = dict(bbox_inches='tight', pad_inches=.035)
    fig.savefig(path+'.pdf', **kw)
    fig.savefig(path+'.svg', **kw)
    fig.savefig(path+'.png', dpi=300, **kw)
    buf = io.BytesIO()
    fig.savefig(buf, format='png', dpi=600, **kw)
    buf.seek(0)
    with Image.open(buf) as image:
        image.convert('RGB').save(path+'.tif', compression='tiff_lzw', dpi=(600, 600))
    plt.close(fig)
    print('[wrote]', stem, flush=True)


def supplements():
    import make_figures_8a as M
    M.set_style = S.set_style
    M.save_fig = save
    M.plot_fig4(M.load_windows(), pd.read_csv(ROOT/'results/trends.csv'))
    # Attribution: estimates with intervals; avoid manufacturing distributions.
    attr = pd.read_csv(ROOT/'results/attribution.csv')
    attr = attr[(attr.province == '全国') & attr.metric.isin(['length_months','onset_month'])].dropna(subset=['coef'])
    fig, ax = plt.subplots(figsize=(7.48, 3.8))
    y = np.arange(len(attr))
    ax.errorbar(attr.coef, y, xerr=1.96*attr.se, fmt='o', color=C['blue'], capsize=2, ms=4)
    ax.axvline(0, color='.5', ls='--', lw=.7)
    ax.set_yticks(y, [f'{r.metric.replace("_months", "")} · {r.predictor}' for r in attr.itertuples()])
    ax.invert_yaxis()
    ax.set_xlabel('effect (months per 1 SD of predictor), 95% CI')
    fig.subplots_adjust(left=.36, bottom=.20)
    panel(ax, 'A')
    save(fig, str(OUT/'fig2_attribution'))
    lag = DATA['cn_lag']
    fig, ax = plt.subplots(figsize=(5.51, 3.3))
    ax.errorbar(lag.lag, lag.coef, yerr=[lag.coef-lag.ci_low, lag.ci_high-lag.coef],
                fmt='o-', color=C['blue'], ms=5, capsize=3)
    ax.axhline(0, color='.5', ls='--', lw=.7)
    ax.set(xlabel='temperature lag (months)', ylabel='log case-rate coefficient per °C')
    ax.set_xticks(range(4))
    for r in lag.itertuples():
        ax.annotate(G._pfmt(r.p), (r.lag, r.ci_high), xytext=(0, 8),
                    textcoords='offset points', ha='center', fontsize=8)
    ax.margins(y=.23)
    panel(ax, 'A')
    save(fig, str(OUT/'fig3_lag_curve'))
    from power_analysis import power_curve, SLOPE_GRID, RNG_SEED
    rng = np.random.default_rng(RNG_SEED)
    years = np.array([2013,2014,2015,2016,2017,2018,2019,2020,2022,2023,2024])
    fig, axes = plt.subplots(2, 2, figsize=(7.48, 5.7))
    fig.subplots_adjust(hspace=.5, wspace=.32)
    for ax, r, letter in zip(axes.flat, DATA['cn_power'].itertuples(), 'ABCD'):
        power = power_curve(years, r.sd_obs_months, SLOPE_GRID, rng)
        pd.DataFrame({'slope':SLOPE_GRID, 'power':power}).to_csv(SOURCE/f'Figure_S4_{letter}.csv', index=False)
        ax.plot(SLOPE_GRID, power, color=C['blue'])
        ax.axhline(.8, color='.5', ls='--', lw=.7)
        ax.axvline(r.mds80_moyr, color=C['vermillion'], ls=':', lw=1)
        ax.text(.97, .05, f'{r.metric}; n=11\nMDS80={r.mds80_moyr:.3f}',
                transform=ax.transAxes, ha='right', fontsize=8)
        ax.set(xlim=(0,.6), ylim=(0,1), xlabel='true trend (months/year)', ylabel='power')
        panel(ax, letter)
    save(fig, str(OUT/'fig5_power_curves'))
    fig, axes = plt.subplots(1, 2, figsize=(7.48, 4.4), gridspec_kw={'width_ratios':[1.25,1]})
    fig.subplots_adjust(wspace=.70, left=.20, bottom=.30)
    loo = pd.read_csv(ROOT/'results/global_loo_country.csv')
    loo = loo[(loo.stratum == 'n_ge_20') & (loo.dropped != '(none)')]
    ax = axes[0]
    ax.errorbar(loo.pooled, range(len(loo)), xerr=[loo.pooled-loo.ci_lo, loo.ci_hi-loo.pooled],
                fmt='o', color=C['blue'], capsize=2)
    ax.set_yticks(range(len(loo)), ['omit '+c.title() for c in loo.dropped])
    ax.invert_yaxis()
    ax.axvline(0, color='.5', ls='--', lw=.7)
    ax.set_xlabel('length trend (months/year)\n95% unit-level DL CI')
    panel(ax,'A')
    cl = pd.read_csv(ROOT/'results/revision_country_cluster.csv')
    cl = cl[cl.stratum == 'n_ge_20']
    ax = axes[1]
    ax.errorbar(cl.slope, [0,1], xerr=[cl.slope-cl.ci_lo, cl.ci_hi-cl.slope],
                fmt='s', color=C['vermillion'], capsize=2)
    ax.set_yticks([0,1], ['5–95%','circular 90%'])
    ax.set_ylim(1.6,-.6)
    ax.axvline(0, color='.5', ls='--', lw=.7)
    ax.set_xlabel('length trend (months/year)\ncountry-cluster t CI; G=5')
    panel(ax,'B')
    save(fig,str(OUT/'Figure_S5'))


def main():
    global DATA
    parser=argparse.ArgumentParser()
    parser.add_argument('--sample', action='store_true')
    parser.add_argument('--figure', type=int, choices=range(1,9))
    args=parser.parse_args()
    S.set_style()
    plt.rcParams['svg.fonttype']='none'
    S.save=save
    DATA=G.load()
    inputs=[]
    for key, df in DATA.items():
        path=SOURCE/f'input_{key}.csv'
        df.to_csv(path,index=False,encoding='utf-8-sig')
        inputs.append(dict(key=key,file=str(path.relative_to(ROOT)),rows=len(df),
                           columns=';'.join(df.columns),sha256=hashlib.sha256(path.read_bytes()).hexdigest()))
    pd.DataFrame(inputs).to_csv(SOURCE/'input_index.tsv',sep='\t',index=False)
    if args.sample:
        G.fig5(DATA)
        return
    if args.figure:
        getattr(G,f'fig{args.figure}')(DATA)
        manifest=OUT/'panel_manifest.tsv'
        if manifest.exists():
            old=pd.read_csv(manifest,sep='\t')
            old=old[~old.figure.isin([r['figure'] for r in records])]
            pd.concat([old,pd.DataFrame(records)],ignore_index=True).to_csv(
                manifest,sep='\t',index=False,encoding='utf-8-sig')
        return
    for fn in [G.fig1,G.fig2,G.fig3,G.fig4,G.fig5,G.fig6,G.fig7,G.fig8]:
        fn(DATA)
    supplements()
    pd.DataFrame(records).to_csv(OUT/'panel_manifest.tsv',sep='\t',index=False,encoding='utf-8-sig')
    pd.DataFrame([dict(variable='visual role',category=k,hex=v,role='project-defined palette',
        source='Okabe–Ito; project choice, not author HEX') for k,v in C.items()]).to_csv(
        OUT/'color_key.tsv',sep='\t',index=False)


if __name__=='__main__':
    main()
