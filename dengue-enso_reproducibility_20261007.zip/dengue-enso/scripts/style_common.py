# -*- coding: utf-8 -*-
"""
Shared publication-style constants for Task 8 figure branches (8a and 8b).
Both branches import this module so figures look consistent
(project-structure.md §4.3).

Usage:
    from style_common import set_style, COLORS, FIG_DPI
    set_style()
"""
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
from matplotlib import font_manager

# colorblind-safe palette (tab10 first 4 + grey)
COLORS = ["#1783FF", "#F0884D", "#60C42D", "#D580FF", "#999999"]
OUTBREAK_COLOR = "#FF4D4F"
COVID_COLOR = "#B0B0B0"

FIG_DPI = 300
FONT_SIZE = 9
LEGEND_SIZE = 7.5


def set_style():
    """Apply journal-grade matplotlib style (seaborn-whitegrid equivalent)."""
    for _f in ["Microsoft YaHei", "SimHei", "SimSun"]:
        try:
            font_manager.findfont(_f, fallback_to_default=False)
            plt.rcParams["font.sans-serif"] = [_f, "DejaVu Sans"]
            break
        except Exception:
            continue
    plt.rcParams["axes.unicode_minus"] = False
    plt.rcParams["font.size"] = FONT_SIZE
    plt.rcParams["axes.titlesize"] = FONT_SIZE + 1
    plt.rcParams["axes.labelsize"] = FONT_SIZE
    plt.rcParams["legend.fontsize"] = LEGEND_SIZE
    plt.rcParams["xtick.labelsize"] = FONT_SIZE - 1
    plt.rcParams["ytick.labelsize"] = FONT_SIZE - 1
    plt.rcParams["axes.grid"] = True
    plt.rcParams["grid.alpha"] = 0.3
    plt.rcParams["axes.facecolor"] = "white"
    plt.rcParams["figure.facecolor"] = "white"
    plt.rcParams["savefig.facecolor"] = "white"
    plt.rcParams["axes.spines.top"] = False
    plt.rcParams["axes.spines.right"] = False


def save_fig(fig, path):
    """Save a figure at publication DPI in both PNG and PDF."""
    fig.savefig(path + ".png", dpi=FIG_DPI, bbox_inches="tight")
    fig.savefig(path + ".pdf", bbox_inches="tight")
    plt.close(fig)
