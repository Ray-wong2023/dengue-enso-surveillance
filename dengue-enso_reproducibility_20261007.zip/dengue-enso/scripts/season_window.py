# -*- coding: utf-8 -*-
"""
Task 4: Epidemic season-window extraction for China dengue.

Defines, for each province x year with enough cases, the epidemic season
window (onset month, offset month, length, peak month) using the cumulative
case-fraction threshold method. Multiple threshold pairs are computed for
robustness. Years without a definable window are kept as NaN rows.

Inputs:
  data/processed/dengue_china_clean.csv  (Task 3 output)

Outputs:
  data/processed/windows.csv   province, year, threshold, onset_month,
                               offset_month, length_months, peak_month,
                               n_months, incomplete, note
  figures/window_ts.png        per-province window strip chart

This file is FROZEN after generation: downstream parallel branches (T5/T6)
share windows.csv as read-only input.
"""
import os
import sys

import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
import numpy as np
import pandas as pd

# CJK font for Chinese labels in figures (Windows)
from matplotlib import font_manager
for _f in ["Microsoft YaHei", "SimHei", "SimSun"]:
    try:
        font_manager.findfont(_f, fallback_to_default=False)
        plt.rcParams["font.sans-serif"] = [_f, "DejaVu Sans"]
        plt.rcParams["axes.unicode_minus"] = False
        break
    except Exception:
        continue

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
PROC = os.path.join(ROOT, "data", "processed")
FIG = os.path.join(ROOT, "figures")

IN_CLEAN = os.path.join(PROC, "dengue_china_clean.csv")
OUT_WINDOWS = os.path.join(PROC, "windows.csv")
OUT_FIG = os.path.join(FIG, "window_ts.png")

# provinces requested by the implementation plan (national + southern focus)
PROVINCES = ["全国", "广东", "广西", "云南", "福建", "海南", "浙江"]
THRESHOLDS = [(0.05, 0.95), (0.01, 0.99), (0.10, 0.90)]

# years with COVID reporting disruption (T7 sensitivity removes them)
COVID_YEARS = {2020, 2021}
# years with incomplete monthly coverage in the national series
INCOMPLETE_NATIONAL = {2022: "missing Nov-Dec", 2025: "only Jan-Apr"}


def extract_window(annual_series, p_low=0.05, p_high=0.95):
    """annual_series: 12-month Series indexed 1..12 (missing months = 0).

    Returns (onset, offset, length, peak) with month numbers 1..12, or
    (None, None, None, None) when the year has < 30 cases or the high
    threshold is never reached.
    """
    total = annual_series.sum()
    if total < 30:
        return (None, None, None, None)
    cum = annual_series.cumsum() / total
    onset = int((cum >= p_low).argmax()) + 1          # first month >= p_low
    hit_high = (cum >= p_high).any()
    if not hit_high:
        return (None, None, None, None)
    offset = int((cum >= p_high).argmax()) + 1        # first month >= p_high
    length = offset - onset + 1
    peak = int(annual_series.idxmax())
    return (onset, offset, length, peak)


def build_windows():
    df = pd.read_csv(IN_CLEAN, encoding="utf-8-sig")
    df = df[df["province"].isin(PROVINCES)].copy()

    rows = []
    for prov in PROVINCES:
        sub = df[df["province"] == prov]
        for year in sorted(sub["year"].unique()):
            if year < 1990 or year > 2024:
                continue
            ysub = sub[sub["year"] == year]
            n_months = int(ysub["month"].nunique())
            # 12-month series with 0 for missing months
            ser = pd.Series(0.0, index=range(1, 13))
            for _, r in ysub.iterrows():
                ser.loc[int(r["month"])] = float(r["cases"])
            note = ""
            if prov == "全国" and year in INCOMPLETE_NATIONAL:
                note = INCOMPLETE_NATIONAL[year]
            if prov == "全国" and year in COVID_YEARS:
                note = (note + "; " if note else "") + "COVID-disrupted reporting"
            for (pl, ph) in THRESHOLDS:
                onset, offset, length, peak = extract_window(ser, pl, ph)
                rows.append({
                    "province": prov,
                    "year": year,
                    "threshold": f"({pl:.2f},{ph:.2f})",
                    "onset_month": onset,
                    "offset_month": offset,
                    "length_months": length,
                    "peak_month": peak,
                    "n_months": n_months,
                    "incomplete": 1 if n_months < 12 else 0,
                    "note": note,
                })
    out = pd.DataFrame(rows)
    out = out.sort_values(["province", "year", "threshold"]).reset_index(drop=True)
    out.to_csv(OUT_WINDOWS, index=False, encoding="utf-8-sig")
    return out


def plot_windows(w):
    os.makedirs(FIG, exist_ok=True)
    fig, axes = plt.subplots(len(PROVINCES), 1, figsize=(11, 2.4 * len(PROVINCES)),
                             sharex=True)
    colors = {"(0.05,0.95)": "#1783FF", "(0.01,0.99)": "#F0884D",
              "(0.10,0.90)": "#60C42D"}
    for ax, prov in zip(axes, PROVINCES):
        sub = w[w["province"] == prov]
        for (pl, ph) in THRESHOLDS:
            tkey = f"({pl:.2f},{ph:.2f})"
            ts = sub[sub["threshold"] == tkey]
            ok = ts.dropna(subset=["onset_month"])
            for _, r in ok.iterrows():
                y = r["year"]
                ax.plot([y, y], [r["onset_month"], r["offset_month"]],
                        color=colors[tkey], lw=3, alpha=0.55, solid_capstyle="round")
                if tkey == "(0.05,0.95)":
                    ax.plot(y, r["peak_month"], "k.", ms=5)
        ax.set_ylabel(prov, rotation=0, ha="right", va="center", fontsize=9)
        ax.set_ylim(13.2, 0.2)
        ax.yaxis.set_major_locator(plt.MultipleLocator(2))
        ax.grid(axis="y", alpha=0.3)
    axes[0].set_title("Dengue epidemic season windows (colored bars = onset-to-offset; "
                      "dot = peak month)")
    axes[-1].set_xlabel("Year")
    fig.tight_layout()
    fig.savefig(OUT_FIG, dpi=200)
    plt.close(fig)
    print(f"[wrote] {OUT_FIG}")


def run_assertions(w):
    ok = True
    valid = w.dropna(subset=["onset_month", "offset_month"])
    if not (valid["onset_month"] <= valid["offset_month"]).all():
        print("[FAIL] onset > offset somewhere")
        ok = False
    if not (valid["length_months"] >= 1).all():
        print("[FAIL] length < 1")
        ok = False
    if not valid["peak_month"].between(1, 12).all():
        print("[FAIL] peak out of range")
        ok = False
    # expected rows: provinces x years(1990-2024 with data) x 3 thresholds
    n_na = int(w["onset_month"].isna().sum())
    if ok:
        print(f"[PASS] windows {len(w)} rows ({len(valid)} valid, {n_na} NaN/no-window)")
    return ok


def main():
    print("=" * 60)
    print("Step 1: extract windows")
    w = build_windows()
    n_valid = int(w.dropna(subset=["onset_month"]).shape[0])
    n_na = int(w["onset_month"].isna().sum())
    print(f"  rows {len(w)} (valid {n_valid}, no-window {n_na})")

    print("=" * 60)
    print("Step 2: summary of valid windows by province x threshold")
    summ = w.dropna(subset=["onset_month"]).groupby(["province", "threshold"]).size()
    print(summ.to_string())

    print("=" * 60)
    print("Step 3: figure")
    plot_windows(w)

    print("=" * 60)
    print("Step 4: assertions")
    ok = run_assertions(w)
    print("\nDONE. ok =", ok)
    return 0 if ok else 1


if __name__ == "__main__":
    sys.exit(main())
