# -*- coding: utf-8 -*-
"""
Revision pass 4: breakpoint / panel / DLNM model diagnostics.

Addresses simulated-reviewer P1-4 ("complete model diagnostics").

Contents:
  A. Breakpoint calibration by permutation. The segmented-regression F-test
     is asymptotic and the scan maximises over candidate break years, which
     inflates false positives in tiny samples (n=11/13). We therefore
     permute each metric's series 5,000 times (exchangeable null) and
     report (i) the empirical null rejection rate of the nominal-p<0.05 F
     gate, and (ii) the permutation-calibrated p of any detected breakpoint
     (main 2012-2024 series for all four metrics, plus the 2008-2024
     length series whose nominal 2016 breakpoint is discussed in the paper).
  B. Panel-regression diagnostics on the primary national Model 1 /
     Model 2 (window length ~ temperature): Shapiro-Wilk on residuals,
     Durbin-Watson and lag-1 autocorrelation, Breusch-Pagan heteroscedasticity,
     Ramsey RESET, and VIF for the Model-2 predictors.
  C. DLNM diagnostics: NegativeBinomial GLM of monthly cases on the Almon
     lag basis — Pearson chi-square/df and deviance/df (over-dispersion),
     residual lag-1 autocorrelation, and a lag-structure sensitivity check
     (Almon degree 2/3 vs unconstrained lags 0-3) confirming the lag1/lag2
     positive coefficients are not an artefact of the basis choice.

Inputs (read-only):  data/processed/windows.csv, data/raw/temperature_cities.csv,
                     data/processed/dengue_china_clean.csv
Outputs:
  results/breakpoint_permutation.csv
  results/model_diagnostics.csv
No new figures (diagnostics are tabular).
"""
import os
import sys

import numpy as np
import pandas as pd
from scipy import stats
import statsmodels.formula.api as smf
from statsmodels.stats.diagnostic import het_breuschpagan, linear_reset
from statsmodels.stats.stattools import durbin_watson
from statsmodels.stats.outliers_influence import variance_inflation_factor
from statsmodels.genmod.generalized_linear_model import GLM
from statsmodels.genmod.families import NegativeBinomial

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
PROC = os.path.join(ROOT, "data", "processed")
RAW = os.path.join(ROOT, "data", "raw")
RES = os.path.join(ROOT, "results")
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from trend_analysis import mann_kendall, breakpoint_test, METRIC_COLS  # noqa: E402
from leverage_diagnostics import build_estimation_sample, zscore  # noqa: E402

IN_WINDOWS = os.path.join(PROC, "windows.csv")
IN_CLEAN = os.path.join(PROC, "dengue_china_clean.csv")
OUT_BP = os.path.join(RES, "breakpoint_permutation.csv")
OUT_DIAG = os.path.join(RES, "model_diagnostics.csv")

DEFAULT_THRESHOLD = "(0.05,0.95)"
METRICS = ["onset", "offset", "length", "peak"]
N_PERM = 5000
SEED = 20260905
COVID_YEARS = {2020, 2021}
INCOMPLETE_YEARS = {2022}


def breakpoint_f(x, y):
    """Return (best_k, F_stat) of the segmented-vs-linear scan (no p-value)."""
    x = np.asarray(x, float)
    y = np.asarray(y, float)
    n = len(x)
    A = np.vstack([x, np.ones_like(x)]).T
    coef, _, _, _ = np.linalg.lstsq(A, y, rcond=None)
    rss_single = float(((y - A @ coef) ** 2).sum())
    best_k, best_rss = None, np.inf
    for k in range(2, n - 1):
        rss = 0.0
        for lo, hi in ((0, k), (k, n)):
            xs, ys = x[lo:hi], y[lo:hi]
            B = np.vstack([xs, np.ones_like(xs)]).T
            c, _, _, _ = np.linalg.lstsq(B, ys, rcond=None)
            rss += float(((ys - B @ c) ** 2).sum())
        if rss < best_rss:
            best_rss, best_k = rss, k
    df_num, df_den = 2, n - 4
    if best_rss <= 0:
        return best_k, np.inf
    f_stat = ((rss_single - best_rss) / df_num) / (best_rss / df_den)
    return best_k, float(f_stat)


def perm_breakpoint(years, vals, label, rng):
    """Permutation calibration of the breakpoint test for one series."""
    x = np.asarray(years, float)
    y = np.asarray(vals, float)
    n = len(y)
    obs_k, obs_f = breakpoint_f(x, y)
    perm_f = np.empty(N_PERM)
    for i in range(N_PERM):
        perm_f[i] = breakpoint_f(x, rng.permutation(y))[1]
    emp_p = (1.0 + np.sum(perm_f >= obs_f)) / (1.0 + N_PERM)
    nom_null_p = 1.0 - stats.f.cdf(perm_f, 2, n - 4)
    null_reject = float((nom_null_p < 0.05).mean())
    obs_byr, obs_p = breakpoint_test(x, y)
    row = {
        "series": label, "n_years": n,
        "nominal_breakpoint_year": obs_byr, "nominal_p": obs_p,
        "observed_F": round(obs_f, 3),
        "permutation_p": round(emp_p, 4),
        "null_rejection_rate_at_0.05": round(null_reject, 3),
    }
    print(f"  {label}: nominal bp={obs_byr} p={obs_p:.4f} -> "
          f"perm p={emp_p:.4f} (null reject rate {null_reject:.1%})")
    return row


def panel_diagnostics():
    """Diagnostics for the primary national panel regressions."""
    d = build_estimation_sample()
    rows = []
    for name, formula in [("Model1_length~annual", "length_months ~ annual_temp"),
                          ("Model2_length~spring+suitable",
                           "length_months ~ spring_temp + suitable_months")]:
        zd = d.copy()
        for p in ("annual_temp", "spring_temp", "suitable_months"):
            zd[p] = zscore(d[p])
        res = smf.ols(formula, data=zd).fit(cov_type="HC1")
        res0 = smf.ols(formula, data=zd).fit()          # classical, for tests
        sw_stat, sw_p = stats.shapiro(res.resid)
        dw = durbin_watson(res.resid)
        ac1 = float(np.corrcoef(res.resid[:-1], res.resid[1:])[0, 1])
        bp_lm, bp_lm_p, bp_f, bp_f_p = het_breuschpagan(res.resid,
                                                        res0.model.exog)
        try:
            reset = linear_reset(res0, power=2, use_f=True)
            reset_stat, reset_p = float(reset.statistic), float(reset.pvalue)
        except Exception:
            reset_stat, reset_p = np.nan, np.nan
        # VIF on the predictor block (only meaningful with >=2 predictors)
        pred_names = [c for c in ("spring_temp", "suitable_months",
                                  "annual_temp") if c in formula]
        if len(pred_names) >= 2:
            Xp = zd[pred_names].to_numpy()
            vifs = {c: float(variance_inflation_factor(Xp, i))
                    for i, c in enumerate(pred_names)}
        else:
            vifs = {}
        for c, v in vifs.items():
            rows.append({"model": name, "diagnostic": f"VIF_{c}",
                         "value": round(v, 3), "p_value": np.nan,
                         "interpretation": ""})
        rows += [
            {"model": name, "diagnostic": "ShapiroWilk_residuals",
             "value": round(float(sw_stat), 4), "p_value": round(float(sw_p), 4),
             "interpretation": "normality plausible" if sw_p > 0.05
             else "residual non-normality (small-n caution)"},
            {"model": name, "diagnostic": "DurbinWatson",
             "value": round(float(dw), 3), "p_value": np.nan,
             "interpretation": "no strong residual autocorrelation"
             if 1.5 < dw < 2.5 else "check autocorrelation"},
            {"model": name, "diagnostic": "resid_lag1_autocorr",
             "value": round(ac1, 3), "p_value": np.nan,
             "interpretation": ""},
            {"model": name, "diagnostic": "BreuschPagan_LM",
             "value": round(float(bp_lm), 3), "p_value": round(float(bp_lm_p), 4),
             "interpretation": "no heteroscedasticity detected"
             if bp_lm_p > 0.05 else "heteroscedasticity (HC1 SEs used)"},
            {"model": name, "diagnostic": "Ramsey_RESET(power2)",
             "value": round(reset_stat, 3), "p_value": round(reset_p, 4),
             "interpretation": "no evident misspecification" if
             (np.isnan(reset_p) or reset_p > 0.05) else "possible misspecification"},
        ]
        print(f"  {name}: SW p={sw_p:.3f} DW={dw:.2f} BP p={bp_lm_p:.3f} "
              f"RESET p={reset_p:.3f} VIF={ {k: round(v,2) for k,v in vifs.items()} }")
    return rows


def dlnm_diagnostics():
    """NB GLM residual + lag-structure sensitivity diagnostics."""
    import attribution as att
    m = att.build_dlm_data()
    temps = m["temp"].to_numpy(float)
    y = m["cases"].to_numpy(float)
    n = len(temps)
    lags = [0, 1, 2, 3]
    X = np.column_stack([temps[3 - l: n - l] for l in lags])
    yv = y[3:]
    rows = []
    variants = {}
    for deg in (2, 3):
        Z = np.column_stack([np.asarray(lags, float) ** j
                             for j in range(deg + 1)])
        variants[f"almon_deg{deg}"] = X @ Z
    variants["unconstrained_lags0-3"] = X
    for name, Xd in variants.items():
        g = GLM(yv, Xd, family=NegativeBinomial()).fit(disp=False)
        pred = g.fittedvalues
        resid_p = (yv - pred) / np.sqrt(pred + 1e-9)
        ac1 = float(np.corrcoef(resid_p[:-1], resid_p[1:])[0, 1])
        chi2df = float(g.pearson_chi2 / g.df_resid)
        devdf = float(g.deviance / g.df_resid)
        print(f"  {name}: Pearson chi2/df={chi2df:.2f} deviance/df={devdf:.2f} "
              f"resid lag-1 ac={ac1:+.3f}")
        # per-lag coefficients on the natural lag scale
        coefs = {}
        if name.startswith("almon"):
            bn = np.asarray(g.params)
            cb = np.asarray(g.cov_params())
            for l in lags:
                gv = np.array([float(l) ** j for j in range(len(bn))])
                coefs[l] = (float(gv @ bn),
                            float(np.sqrt(gv @ cb @ gv)))
        else:
            for i, l in enumerate(lags):
                coefs[l] = (float(g.params[i]), float(g.bse[i]))
        for l, (b, se) in coefs.items():
            p = 2.0 * (1.0 - stats.norm.cdf(abs(b) / se)) if se > 0 else np.nan
            rows.append({"model": f"DLNM_{name}", "diagnostic": f"lag{l}_coef",
                         "value": round(b, 4), "p_value": round(p, 5),
                         "interpretation": ""})
        rows.append({"model": f"DLNM_{name}", "diagnostic": "pearson_chi2_df",
                     "value": round(chi2df, 3), "p_value": np.nan,
                     "interpretation": ""})
        rows.append({"model": f"DLNM_{name}", "diagnostic": "deviance_df",
                     "value": round(devdf, 3), "p_value": np.nan,
                     "interpretation": ""})
        rows.append({"model": f"DLNM_{name}", "diagnostic": "resid_lag1_ac",
                     "value": round(ac1, 3), "p_value": np.nan,
                     "interpretation": ""})
    return rows


def main():
    rng = np.random.default_rng(SEED)
    print("=" * 64)
    print("A. Breakpoint permutation calibration")
    w = pd.read_csv(IN_WINDOWS, encoding="utf-8-sig")
    sub = w[(w["province"] == "全国") & (w["threshold"] == DEFAULT_THRESHOLD)]
    rows = []
    for metric, col in METRIC_COLS.items():
        s = sub[sub["year"].between(2012, 2024)].dropna(subset=[col])
        rows.append(perm_breakpoint(s["year"].to_numpy(float),
                                    s[col].to_numpy(float),
                                    f"main 2012-2024 {metric}", rng))
    s = sub[sub["year"].between(2008, 2024)].dropna(subset=["length_months"])
    rows.append(perm_breakpoint(s["year"].to_numpy(float),
                                s["length_months"].to_numpy(float),
                                "supplementary 2008-2024 length", rng))
    bp = pd.DataFrame(rows)
    os.makedirs(RES, exist_ok=True)
    bp.to_csv(OUT_BP, index=False, encoding="utf-8-sig")
    print(f"[wrote] {OUT_BP}")

    print("=" * 64)
    print("B. Panel-regression diagnostics")
    diag_rows = panel_diagnostics()

    print("=" * 64)
    print("C. DLNM diagnostics + lag-structure sensitivity")
    diag_rows += dlnm_diagnostics()

    diag = pd.DataFrame(diag_rows)
    diag.to_csv(OUT_DIAG, index=False, encoding="utf-8-sig")
    print(f"[wrote] {OUT_DIAG} ({len(diag)} rows)")

    print("=" * 64)
    print("Assertions")
    ok = True
    if len(bp) != 5:
        print("[FAIL] breakpoint table incomplete")
        ok = False
    if diag.isna().groupby(diag["diagnostic"]).size().max() > 6:
        print("[FAIL] too many NaN diagnostics")
        ok = False
    # lag1/lag2 must stay positive across basis choices
    for basis in ("almon_deg2", "almon_deg3", "unconstrained_lags0-3"):
        for lag in ("lag1_coef", "lag2_coef"):
            v = diag[(diag["model"] == f"DLNM_{basis}") &
                     (diag["diagnostic"] == lag)]["value"].iloc[0]
            if v <= 0:
                print(f"[FAIL] lag1/lag2 not positive under {basis}")
                ok = False
    # null rejection rate of the F gate must be reported
    if bp["null_rejection_rate_at_0.05"].isna().any():
        print("[FAIL] missing null rejection rates")
        ok = False
    print(f"\nDONE. ok = {ok}")
    return 0 if ok else 1


if __name__ == "__main__":
    sys.exit(main())
