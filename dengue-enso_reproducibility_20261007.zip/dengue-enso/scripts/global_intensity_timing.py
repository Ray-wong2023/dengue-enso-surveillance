# -*- coding: utf-8 -*-
"""
S4b: intensity vs timing decomposition (mechanism).

Tests the hypothesis that the epidemic season *window* is dominated by
outbreak intensity (the size of the season) rather than by gradual climate
forcing — the mechanism that would explain why window trends are small even
where warming is strong.

For every unit x metric (primary threshold, complete-12-month years):
  1. within-unit regression of the window metric on log10(annual cases)
     -> elasticity (months per 10-fold case increase) + p + R2
  2. the same on annual mean temperature -> p + R2
  3. a joint standardized model -> which predictor dominates (|std beta|)
Pooled (random-effects) elasticities are then reported per metric.

Additional summaries:
  * share of units where intensity is significant vs temperature
  * variance decomposition: within-unit vs between-unit SD of each metric
  * sensitivity: refit after dropping each unit's top-5% case years

Outputs:
  results/global_intensity_timing.csv
  results/global_intensity_timing_report.md
"""
import os
import sys
from pathlib import Path

import numpy as np
import pandas as pd
from scipy import stats

ROOT = Path(os.getcwd()).resolve()
assert (ROOT / "results").is_dir(), "run from the dengue-enso project root"
RES = ROOT / "results"
WINDOWS = RES / "global_windows.csv"
ANNUAL = RES / "global_unit_temp_annual.csv"
OUT = RES / "global_intensity_timing.csv"
OUT_REPORT = RES / "global_intensity_timing_report.md"

PRIMARY_THR = "(0.05,0.95)"
METRIC_COL = {"onset": "onset_month", "offset": "offset_month",
              "length": "length_months", "peak": "peak_month"}
MIN_N = 10
Z = 1.959964


def _safe(p: Path) -> Path:
    rp = p.resolve()
    if not str(rp).startswith(str(ROOT)):
        raise ValueError(f"path escapes project root: {rp}")
    return rp


def _dl(slopes, ses):
    s = np.asarray(slopes, float)
    e = np.asarray(ses, float)
    ok = np.isfinite(s) & np.isfinite(e) & (e > 0)
    s, e = s[ok], e[ok]
    if len(s) < 3:
        return None
    w = 1 / e ** 2
    fixed = float((w * s).sum() / w.sum())
    Q = float((w * (s - fixed) ** 2).sum())
    df = len(s) - 1
    C = float(w.sum() - (w ** 2).sum() / w.sum())
    tau2 = max(0.0, (Q - df) / C) if C > 0 else 0.0
    wr = 1 / (e ** 2 + tau2)
    pooled = float((wr * s).sum() / wr.sum())
    se = float(np.sqrt(1 / wr.sum()))
    p = 2 * (1 - stats.norm.cdf(abs(pooled / se))) if se > 0 else np.nan
    i2 = max(0.0, (Q - df) / Q) * 100 if Q > 0 else 0.0
    return {"k": len(s), "pooled": pooled, "se": se, "p": p, "I2": i2}


def fit_unit(g, col):
    """Within-unit fits for one unit (metric col) -> dict or None."""
    d = g.dropna(subset=[col, "annual_cases", "annual_mean"])
    if len(d) < MIN_N:
        return None
    x = np.log10(d["annual_cases"].to_numpy(float))
    t = d["annual_mean"].to_numpy(float)
    y = d[col].to_numpy(float)
    if np.std(x) == 0 or np.std(y) == 0:
        return None
    s_x, i_x, r_x, p_x, se_x = stats.linregress(x, y)
    r2_x = r_x ** 2
    if np.std(t) > 0:
        s_t, i_t, r_t, p_t, se_t = stats.linregress(t, y)
        r2_t = r_t ** 2
    else:
        s_t, p_t, r2_t, se_t = np.nan, np.nan, np.nan, np.nan
    # joint standardized model
    dom, beta_x_std, beta_t_std = np.nan, np.nan, np.nan
    try:
        A = np.column_stack([x, t, np.ones_like(x)])
        if np.linalg.matrix_rank(A) == 3:
            coef, _, _, _ = np.linalg.lstsq(A, y, rcond=None)
            se_ = np.std(y, ddof=1)
            beta_x_std = coef[0] * np.std(x, ddof=1) / se_
            beta_t_std = coef[1] * np.std(t, ddof=1) / se_
            dom = "intensity" if abs(beta_x_std) > abs(beta_t_std) else "temperature"
    except Exception:  # noqa: BLE001
        pass
    return {"n": len(d), "slope_logcases": float(s_x), "se_logcases": float(se_x),
            "p_intensity": float(p_x), "r2_intensity": float(r2_x),
            "slope_temp": float(s_t), "p_temp": float(p_t), "r2_temp": float(r2_t),
            "beta_std_intensity": beta_x_std, "beta_std_temp": beta_t_std,
            "dominant": dom}


def main():
    print("=" * 66)
    print("Step 1: inputs")
    w = pd.read_csv(_safe(WINDOWS), encoding="utf-8-sig")
    w = w[(w["threshold"] == PRIMARY_THR) & (w["complete12"] == 1)].copy()
    ann = pd.read_csv(_safe(ANNUAL), encoding="utf-8-sig")
    m = w.merge(ann[["unit", "year", "annual_mean"]], on=["unit", "year"],
                how="inner")
    print(f"  unit-years: {len(m):,} | units: {m['unit'].nunique():,}")

    print("=" * 66)
    print("Step 2: within-unit fits (intensity vs temperature)")
    rows = []
    for metric, col in METRIC_COL.items():
        for unit, g in m.groupby("unit"):
            fit = fit_unit(g, col)
            if fit is None:
                continue
            rows.append({"unit": unit, "country": g["country"].iloc[0],
                         "metric": metric, **fit})
    it = pd.DataFrame(rows)
    it.to_csv(_safe(OUT), index=False, encoding="utf-8-sig")
    print(f"[wrote] {OUT} ({len(it):,} rows)")

    print("=" * 66)
    print("Step 3: pooled elasticities and dominance")
    pooled_rows = []
    for metric in METRIC_COL:
        g = it[it["metric"] == metric]
        pl = _dl(g["slope_logcases"], g["se_logcases"])
        if pl:
            pooled_rows.append({"metric": metric, **pl})
        share_i = float((g["p_intensity"] < 0.05).mean())
        share_t = float((g["p_temp"] < 0.05).mean())
        dom_i = float((g["dominant"] == "intensity").mean())
        print(f"  {metric:7s} k={len(g):4d} | median R2 intensity "
              f"{g['r2_intensity'].median():.3f} vs temp {g['r2_temp'].median():.3f} "
              f"| significant: intensity {share_i:.0%}, temp {share_t:.0%} "
              f"| intensity dominates {dom_i:.0%}")
    pt = pd.DataFrame(pooled_rows)
    print("\n  pooled elasticity (months per 10x cases):")
    print(pt.to_string(index=False))

    print("=" * 66)
    print("Step 4: variance decomposition + outbreak-year sensitivity")
    var_rows = []
    for metric, col in METRIC_COL.items():
        sub = m.dropna(subset=[col])
        within = sub.groupby("unit")[col].std(ddof=1).median()
        overall = sub[col].std(ddof=1)
        between = sub.groupby("unit")[col].mean().std(ddof=1)
        # drop each unit's top-5% case years
        keep = []
        for unit, g in sub.groupby("unit"):
            thr = g["annual_cases"].quantile(0.95)
            keep.append(g[g["annual_cases"] < thr])
        sub2 = pd.concat(keep, ignore_index=True) if keep else sub
        med2 = sub2.groupby("unit")[col].std(ddof=1).median()
        var_rows.append({"metric": metric, "sd_overall": round(float(overall), 3),
                         "median_within_unit_sd": round(float(within), 3),
                         "between_unit_sd": round(float(between), 3),
                         "median_within_sd_excl_top5pct": round(float(med2), 3)})
        print(f"  {metric:7s} overall SD {overall:.2f} | median within-unit SD "
              f"{within:.2f} | between-unit SD {between:.2f} | "
              f"within SD excl. top-5% case years {med2:.2f}")
    vd = pd.DataFrame(var_rows)

    lines = ["# S4b intensity vs timing decomposition", "",
             "Within-unit regressions of each window metric on log10(annual",
             "cases) and on annual mean temperature, plus a joint standardized",
             "model to compare their explanatory weight.", "",
             f"Rows: {len(it):,} unit-metric fits (units with >= {MIN_N} years).",
             "",
             "## Pooled elasticity: months per 10-fold increase in annual cases",
             "",
             "| metric | k units | elasticity (mo per 10x cases) | 95% CI | p | I2 |",
             "|---|---|---|---|---|---|"]
    for _, r in pt.iterrows():
        lines.append(f"| {r['metric']} | {int(r['k'])} | {r['pooled']:+.4f} | "
                     f"[{r['pooled']-Z*r['se']:+.4f}, {r['pooled']+Z*r['se']:+.4f}] | "
                     f"{r['p']:.4f} | {r['I2']:.0f}% |")
    lines += ["", "## Explanatory power by metric", "",
              "| metric | median R2 intensity | median R2 temperature | "
              "share significant: intensity / temperature | intensity dominates |",
              "|---|---|---|---|---|"]
    for metric in METRIC_COL:
        g = it[it["metric"] == metric]
        lines.append(f"| {metric} | {g['r2_intensity'].median():.3f} | "
                     f"{g['r2_temp'].median():.3f} | "
                     f"{float((g['p_intensity']<0.05).mean()):.0%} / "
                     f"{float((g['p_temp']<0.05).mean()):.0%} | "
                     f"{float((g['dominant']=='intensity').mean()):.0%} |")
    lines += ["", "## Variance decomposition", "",
              "| metric | overall SD | median within-unit SD | between-unit SD | within SD excl. top-5% case years |",
              "|---|---|---|---|---|"]
    for _, r in vd.iterrows():
        lines.append(f"| {r['metric']} | {r['sd_overall']} | "
                     f"{r['median_within_unit_sd']} | {r['between_unit_sd']} | "
                     f"{r['median_within_sd_excl_top5pct']} |")
    OUT_REPORT.write_text("\n".join(lines), encoding="utf-8")
    print(f"[wrote] {OUT_REPORT}")

    print("=" * 66)
    print("Assertions")
    ok = True
    if len(it) == 0:
        print("[FAIL] empty intensity table")
        ok = False
    if it["r2_intensity"].dropna().lt(0).any() or it["r2_intensity"].dropna().gt(1).any():
        print("[FAIL] R2 out of range")
        ok = False
    print(f"DONE. ok = {ok}")
    return 0 if ok else 1


if __name__ == "__main__":
    sys.exit(main())
