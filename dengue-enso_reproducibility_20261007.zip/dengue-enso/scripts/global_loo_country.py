# -*- coding: utf-8 -*-
"""Leave-one-country-out sensitivity and country-clustered two-stage pooling
for the global season-window length trend (reviewer response, Part 4 item 1).

For the headline metric (window length) this script:
  1) reports the country composition of the >=10 / >=20 / >=25-year strata;
  2) drops one country at a time from each stratum and re-pools
     (DerSimonian-Laird) to show whether any single country drives the result;
  3) runs a country-clustered two-stage analysis: inverse-variance pooling
     within each country, then DL across countries (units within a country
     are not independent; Thai provinces dominate the long-series stratum).

Inputs : results/global_windows.csv
Outputs: results/global_loo_country.csv
         results/global_country_composition.csv
         results/global_country_twostage.csv
Run from the project root.
"""
import os
from pathlib import Path

import numpy as np
import pandas as pd
from scipy import stats

ROOT = Path(os.getcwd()).resolve()
assert (ROOT / "results").is_dir(), "run from the dengue-enso project root"
RES = ROOT / "results"
WINDOWS = RES / "global_windows.csv"
Z = 1.959964
PRIMARY_THR = "(0.05,0.95)"


def _safe(p: Path) -> Path:
    rp = p.resolve()
    if not str(rp).startswith(str(ROOT)):
        raise ValueError(f"path escapes project root: {rp}")
    return rp


def unit_effects(w: pd.DataFrame, metric_col: str) -> pd.DataFrame:
    """OLS slope + SE per unit on complete-12-month primary-threshold years."""
    rows = []
    for (unit, country), g in w.groupby(["unit", "country"]):
        g = g.dropna(subset=[metric_col]).sort_values("year")
        if len(g) < 6:
            continue
        x = g["year"].to_numpy(float)
        y = g[metric_col].to_numpy(float)
        if np.std(x) == 0 or np.std(y) == 0:
            continue
        slope, inter, r, p, se = stats.linregress(x, y)
        rows.append({"unit": unit, "country": country, "n": len(g),
                     "slope": float(slope), "se": float(se), "p": float(p)})
    return pd.DataFrame(rows)


def dl_pool(slopes, ses):
    slopes = np.asarray(slopes, float)
    ses = np.asarray(ses, float)
    ok = np.isfinite(slopes) & np.isfinite(ses) & (ses > 0)
    slopes, ses = slopes[ok], ses[ok]
    k = len(slopes)
    if k < 3:
        return None
    w = 1.0 / ses ** 2
    fixed = float(np.sum(w * slopes) / np.sum(w))
    Q = float(np.sum(w * (slopes - fixed) ** 2))
    df = k - 1
    C = float(np.sum(w) - np.sum(w ** 2) / np.sum(w))
    tau2 = max(0.0, (Q - df) / C) if C > 0 else 0.0
    wr = 1.0 / (ses ** 2 + tau2)
    pooled = float(np.sum(wr * slopes) / np.sum(wr))
    se_pool = float(np.sqrt(1.0 / np.sum(wr)))
    p = 2 * (1 - stats.norm.cdf(abs(pooled / se_pool)))
    i2 = max(0.0, (Q - df) / Q) * 100 if Q > 0 else 0.0
    return {"k": k, "pooled_slope": pooled, "ci_lo": pooled - Z * se_pool,
            "ci_hi": pooled + Z * se_pool, "p": p, "I2_pct": i2, "tau2": tau2}


def main():
    w = pd.read_csv(_safe(WINDOWS), encoding="utf-8-sig")
    w = w[(w["threshold"] == PRIMARY_THR) & (w["complete12"] == 1)]
    eff = unit_effects(w, "length_months")
    print(f"units with estimable length slope: {len(eff)}")

    loo_rows, comp_rows, ts_rows = [], [], []
    for lab, minn in [("n_ge_10", 10), ("n_ge_20", 20), ("n_ge_25", 25)]:
        s = eff[eff["n"] >= minn]
        base = dl_pool(s["slope"], s["se"])
        comp = s.groupby("country").size().sort_values(ascending=False)
        print("=" * 62)
        print(f"{lab}: k={base['k']} baseline {base['pooled_slope']:+.4f} "
              f"[{base['ci_lo']:+.4f},{base['ci_hi']:+.4f}] p={base['p']:.4g} "
              f"I2={base['I2_pct']:.0f}%")
        print(f"  countries ({comp.size}): "
              + ", ".join(f"{c} {n}" for c, n in comp.items()))
        comp_rows.append({"stratum": lab, "k": base["k"],
                          "n_countries": int(comp.size),
                          "pooled": base["pooled_slope"], "ci_lo": base["ci_lo"],
                          "ci_hi": base["ci_hi"], "p": base["p"],
                          "composition": "; ".join(f"{c}:{n}"
                                                   for c, n in comp.items())})
        loo_rows.append({"stratum": lab, "dropped": "(none)", "k": base["k"],
                         "pooled": base["pooled_slope"], "ci_lo": base["ci_lo"],
                         "ci_hi": base["ci_hi"], "p": base["p"],
                         "I2_pct": base["I2_pct"]})
        for c in comp.index:
            s2 = s[s["country"] != c]
            pl = dl_pool(s2["slope"], s2["se"])
            if pl is None:
                continue
            loo_rows.append({"stratum": lab, "dropped": c,
                             "n_units_dropped": int(comp[c]), "k": pl["k"],
                             "pooled": pl["pooled_slope"], "ci_lo": pl["ci_lo"],
                             "ci_hi": pl["ci_hi"], "p": pl["p"],
                             "I2_pct": pl["I2_pct"]})
            print(f"  drop {c:24s} (units={comp[c]:3d}) -> k={pl['k']:3d} "
                  f"{pl['pooled_slope']:+.4f} [{pl['ci_lo']:+.4f},{pl['ci_hi']:+.4f}] "
                  f"p={pl['p']:.4g}")
        csl, cse = [], []
        for c, g in s.groupby("country"):
            wgt = 1.0 / g["se"] ** 2
            csl.append(float(np.sum(wgt * g["slope"]) / np.sum(wgt)))
            cse.append(float(np.sqrt(1.0 / np.sum(wgt))))
        pl2 = dl_pool(csl, cse)
        if pl2 is not None:
            ts_rows.append({"stratum": lab, "n_countries": pl2["k"], **pl2})
            print(f"  two-stage across countries ({pl2['k']}): "
                  f"{pl2['pooled_slope']:+.4f} "
                  f"[{pl2['ci_lo']:+.4f},{pl2['ci_hi']:+.4f}] "
                  f"p={pl2['p']:.4g} I2={pl2['I2_pct']:.0f}%")

    pd.DataFrame(loo_rows).to_csv(_safe(RES / "global_loo_country.csv"),
                                  index=False, encoding="utf-8-sig")
    pd.DataFrame(comp_rows).to_csv(_safe(RES / "global_country_composition.csv"),
                                   index=False, encoding="utf-8-sig")
    pd.DataFrame(ts_rows).to_csv(_safe(RES / "global_country_twostage.csv"),
                                 index=False, encoding="utf-8-sig")
    print("[wrote] results/global_loo_country.csv, "
          "global_country_composition.csv, global_country_twostage.csv")


if __name__ == "__main__":
    main()
