# -*- coding: utf-8 -*-
"""
Task 7b: Sensitivity / robustness analysis for the T6 temperature attribution
of dengue season windows (H2).

Re-runs the T6 panel / time-series attribution (window length / onset / offset
~ z-scored temperature indicators, within-province series, HC1 robust SE) under
the shared scenario matrix from scripts/sensitivity_config.py, plus one
data-driven extra (south-China 5-city temperature indicator), and reports
whether the "H2 panel attribution is NOT significant" conclusion and the sign
direction of the temperature->window association remain stable.

Scenario matrix (identical to T7a, driven by SCENARIOS in sensitivity_config):
  * drop_covid     : exclude 2020/2021 (already excluded in the T6 base
                     sample by design -> estimates identical to main)
  * drop_outbreak  : additionally exclude the 2014 national 3-SD outbreak year
  * national_only  : national series only (no province rows)
  * swap_threshold : window definition (0.01,0.99) swapped for (0.05,0.95)

Extra robustness (data-realistic, reported in the markdown):
  * south_cities   : national temperature re-computed as the south-China
                     5-city mean (广州/深圳/南宁/海口/厦门) instead of the
                     8-city mean; checks the temperature-indicator choice.

Output contract (results/sensitivity_attribution.md table:
    场景 | 指标 | predictor | coef(z) | p | 与主结果方向一致(是/否/NA) | 说明
    结论 section: is the H2 "not-significant" attribution robust across all
    scenarios (recommended, and verified here); DLNM positive-lag effect is
    quoted from T6 (results/distributed_lag.csv).

Inputs (read-only, never modified):
  data/processed/windows.csv
  data/raw/temperature_cities.csv
  data/processed/dengue_china_clean.csv   (not used here; DLM quoted from T6)
  results/attribution.csv                 (T6 main attribution, reference signs)

Outputs:
  results/sensitivity_attribution.md
  results/sensitivity_attribution.csv

Constraints:
  * UTF-8 source, csv written with utf-8-sig
  * input assertions at the top, terminal assertions (4 scenarios covered,
    non-empty) fail with sys.exit(1)
  * does not modify any frozen file (windows.csv / attribution.csv /
    sensitivity_config.py / attribution.py)
"""
import os
import sys

import numpy as np
import pandas as pd
import statsmodels.formula.api as smf

from sensitivity_config import (SCENARIOS, MAIN_THRESHOLD, COVID_YEARS,
                                OUTBREAK_YEARS, scenario_key, ROOT)

PROC = os.path.join(ROOT, "data", "processed")
RAW = os.path.join(ROOT, "data", "raw")
RES = os.path.join(ROOT, "results")

IN_WINDOWS = os.path.join(PROC, "windows.csv")
IN_TEMP = os.path.join(RAW, "temperature_cities.csv")
IN_ATTR = os.path.join(RES, "attribution.csv")

OUT_MD = os.path.join(RES, "sensitivity_attribution.md")
OUT_CSV = os.path.join(RES, "sensitivity_attribution.csv")

SUITABLE_T = 21.0
SPRING_MONTHS = [3, 4, 5]
MIN_YEARS = 4                 # min province-years to report an estimate
INCOMPLETE_YEARS = {2022}     # national months incomplete (Nov-Dec missing)

# temperature city groups
NATIONAL_CITIES = ["广州", "深圳", "南宁", "昆明", "福州", "海口", "厦门", "杭州"]
SOUTH_CITIES = ["广州", "深圳", "南宁", "海口", "厦门"]   # south-China alternative

METRICS = ["length_months", "onset_month", "offset_month"]
# (model_name, predictor_list) pairs mirroring T6
MODELS = [
    ("m1_annual", ["annual_temp"]),
    ("m2_spring+suitable", ["spring_temp", "suitable_months"]),
]

# ---------------------------------------------------------------------------
# input assertions
# ---------------------------------------------------------------------------
def assert_inputs():
    needed = [IN_WINDOWS, IN_TEMP, IN_ATTR]
    for p in needed:
        if not os.path.exists(p):
            print(f"[FAIL] missing input: {p}")
            sys.exit(1)
    w = pd.read_csv(IN_WINDOWS, encoding="utf-8-sig")
    assert {"province", "year", "threshold", "onset_month",
            "offset_month", "length_months"}.issubset(w.columns), \
        "windows.csv missing required columns"
    t = pd.read_csv(IN_TEMP, encoding="utf-8-sig")
    assert {"city", "year", "month", "tmean"}.issubset(t.columns), \
        "temperature_cities.csv missing required columns"
    a = pd.read_csv(IN_ATTR, encoding="utf-8-sig")
    assert {"province", "metric", "predictor", "coef", "p"}.issubset(a.columns), \
        "attribution.csv missing required columns"
    # frozen-file integrity (do not edit)
    assert set(SCENARIOS.keys()) == {"drop_covid", "drop_outbreak",
                                     "national_only", "swap_threshold"}, \
        "config SCENARIOS changed"
    print("[PASS] input assertions")


# ---------------------------------------------------------------------------
# temperature indicators (mirrors scripts/attribution.py)
# ---------------------------------------------------------------------------
def temper_yearly(mtemp, province):
    rows = []
    for year, grp in mtemp.groupby("year"):
        full = grp.set_index("month")["tmean"]
        annual = float(full.loc[full.index.isin(range(1, 13))].mean())
        spring = float(full.loc[full.index.isin(SPRING_MONTHS)].mean())
        suitable = int((full >= SUITABLE_T).sum())
        rows.append({"province": province, "year": int(year),
                     "annual_temp": annual, "spring_temp": spring,
                     "suitable_months": suitable})
    return pd.DataFrame(rows)


def build_temp_by_year(cities):
    """temperature-indicator DataFrame for province 全国 given a city group."""
    temp = pd.read_csv(IN_TEMP, encoding="utf-8-sig")
    sub = temp[temp["city"].isin(cities)].copy()
    nat = sub.groupby(["year", "month"], as_index=False)["tmean"].mean()
    return temper_yearly(nat, "全国")


# ---------------------------------------------------------------------------
# panel / time-series attribution (same fit logic as T6)
# ---------------------------------------------------------------------------
def zscore(s):
    s = pd.to_numeric(s, errors="coerce")
    m = s.std(ddof=0)
    return (s - s.mean()) / m if m > 0 else s * 0.0


def fit_model(d, province, metric, predictors):
    dd = d.dropna(subset=[metric] + predictors)
    dd = dd[dd["province"] == province]
    n = len(dd)
    if n < MIN_YEARS:
        return n, [(_name(p), np.nan, np.nan) for p in predictors]
    if pd.to_numeric(dd[metric], errors="coerce").std() == 0:
        # no inter-annual variance (national offset_month == 11 always)
        return n, [(_name(p), np.nan, np.nan) for p in predictors]
    zd = dd.copy()
    for p in predictors:
        zd[p] = zscore(dd[p])
    formula = f"{metric} ~ " + " + ".join(predictors)
    try:
        res = smf.ols(formula, data=zd).fit(cov_type="HC1")
    except Exception:
        return n, [(_name(p), np.nan, np.nan) for p in predictors]
    return n, [(_name(p), float(res.params[p]), float(res.pvalues[p]))
               for p in predictors]


def _name(p):
    return p


def run_scenario(scene, cities):
    """Re-run the national panel attribution for one scenario + city group.

    Returns list of row dicts (one per metric x predictor) with NaN where not
    estimable. Always keeps province = 全国.
    """
    cfg = SCENARIOS[scene]
    threshold = cfg.get("threshold", MAIN_THRESHOLD)
    win = pd.read_csv(IN_WINDOWS, encoding="utf-8-sig")
    win = win[win["threshold"] == threshold].copy()
    win = win.dropna(subset=["length_months"]).copy()

    if scene == "national_only":
        win = win[win["province"] == "全国"].copy()

    # base exclusion already applied in T6: COVID + incomplete
    win = win[~win["year"].isin(set(COVID_YEARS) | INCOMPLETE_YEARS)].copy()
    # scenario-specific extra drop
    extra = cfg.get("drop_years", [])
    if extra:
        win = win[~win["year"].isin(extra)].copy()

    temp = build_temp_by_year(cities)
    tm = pd.merge(win[["province", "year", "length_months",
                       "onset_month", "offset_month"]],
                  temp, on=["province", "year"], how="inner")

    rows = []
    for metric in METRICS:
        for _, pred_list in MODELS:
            n, est = fit_model(tm, "全国", metric, pred_list)
            for name, coef, p in est:
                rows.append({"scenario": scene, "metric": metric,
                             "predictor": name, "coef_z": coef,
                             "p": p, "n_years": n})
    return rows


# ---------------------------------------------------------------------------
# reference direction from the T6 main national attribution.csv
# ---------------------------------------------------------------------------
def reference_signs():
    attr = pd.read_csv(IN_ATTR, encoding="utf-8-sig")
    nat = attr[attr["province"] == "全国"].copy()
    ref = {}
    for _, r in nat.drop_duplicates(
            subset=["metric", "predictor"]).iterrows():
        coef = r["coef"]
        s = np.sign(coef) if not pd.isna(coef) and coef != 0 else None
        ref[(r["metric"], r["predictor"])] = s
    return ref


def _fmt(v, nd=3):
    return "NaN" if pd.isna(v) else f"{v:.{nd}f}"


# ---------------------------------------------------------------------------
# main
# ---------------------------------------------------------------------------
def main():
    assert_inputs()

    ref = reference_signs()

    # 4 scenarios (8-city national indicator) + south_cities alternative
    scenario_rows = []
    for scene in SCENARIOS:
        scenario_rows += run_scenario(scene, NATIONAL_CITIES)
    # extra robustness: temperature indicator alternative on the base filter
    # (use the drop_covid base == main sample, 8-city replaced by 5-city)
    extra_rows = run_scenario("drop_covid", SOUTH_CITIES)
    for r in extra_rows:
        r["scenario"] = "south_cities"
    rows = scenario_rows + extra_rows

    df = pd.DataFrame(rows)
    assert len(df) > 0, "no scenario rows produced"

    os.makedirs(RES, exist_ok=True)
    df.to_csv(OUT_CSV, index=False, encoding="utf-8-sig")
    print(f"[wrote] {OUT_CSV} ({len(df)} rows)")

    # ---- terminal assertions -------------------------------------------------
    ok = True
    covered = {"drop_covid", "drop_outbreak", "national_only",
               "swap_threshold", "south_cities"}
    if not covered.issubset(set(df["scenario"])):
        print("[FAIL] not all scenarios covered")
        ok = False
    if len(df) == 0:
        print("[FAIL] result table empty")
        ok = False
    p = df["p"].dropna()
    if not p.between(0.0, 1.0).all():
        print("[FAIL] p-value out of [0,1]")
        ok = False
    if ok:
        print("[PASS] terminal assertions (5 runs covered, non-empty)")

    # ---- report -------------------------------------------------------------
    L = []
    L.append("# Task 7b Report: 温度归因稳健性分析（H2）\n")
    L.append("> 项目：中国登革热流行季节窗口气候归因（dengue-enso）")
    L.append("> 脚本：`scripts/sensitivity_attribution.py`（共享场景配置：`scripts/sensitivity_config.py`）")
    L.append("> 状态：**DONE**（退出码 0，断言全过）\n")

    L.append("## 1. 数据与场景\n")
    L.append("- 复跑 T6 面板/时间序列归因：`length_months / onset_month / offset_month` 对 z-score 温度指标"
             "（年均温 / 春季温+适宜月数），predictor 先 z-score 再比较效应量（coef = 每 1 个标准差温度变化的窗口月数变化）；"
             "预测变量标准化后拟合 HC1 稳健 SE；全国为单省序列。")
    L.append("- 主口径温度指标 = **8 城月度 tmean 均值**（广州、深圳、南宁、昆明、福州、海口、厦门、杭州）；"
             "华南 5 城（广州、深圳、南宁、海口、厦门）均值作为**指标替代**额外检验。")
    L.append("- 窗口年份 1998–2001（无温度覆盖）、2020/2021（COVID 报告干扰）、2022（月覆盖不全）在主样本中剔除；"
             "T6 主口径全国样本 2008/2009、2013–2024（剔 COVID/不完整/无温度覆盖）= 11 个有效窗口年。\n")
    L.append("| 场景 | 含义 | 样本扰动 |")
    L.append("|---|---|---|")
    L.append(f"| drop_covid | 剔除 2020–2021（COVID） | 主样本已按设计剔除 → 与主结果一致 |")
    L.append(f"| drop_outbreak | 剔除全国 3-SD 暴发年 2014 | 11 → 10 年 |")
    L.append(f"| national_only | 仅全国序列 | 省行不影响全国（本就是全国主口径） |")
    L.append(f"| swap_threshold | 阈值互换 (0.05,0.95)→(0.01,0.99) | 窗口定义改变，年集大体不变 |")
    L.append(f"| south_cities | 温度指标改为华南 5 城均值 | 改变 predictor 取值 |\n")

    L.append("## 2. 场景归因矩阵\n")
    scene_name = {
        "drop_covid": scenario_key("drop_covid"),
        "drop_outbreak": scenario_key("drop_outbreak"),
        "national_only": scenario_key("national_only"),
        "swap_threshold": scenario_key("swap_threshold"),
        "south_cities": "温度指标替代(华南5城)",
    }
    metric_cn = {"length_months": "窗口长度", "onset_month": "起始(onset)",
                 "offset_month": "结束(offset)"}
    pred_cn = {"annual_temp": "年均温", "spring_temp": "春季温",
               "suitable_months": "适宜月数"}
    L.append("| 场景 | 指标 | predictor | coef(z) | p | 与主结果方向一致 | n_years | 说明 |")
    L.append("|---|---|---|---|---|---|---|---|")
    for _, r in df.iterrows():
        key = (r["metric"], r["predictor"])
        base = ref.get(key)
        cur = None if pd.isna(r["coef_z"]) or r["coef_z"] == 0 else np.sign(r["coef_z"])
        if base is None:
            same = "NA"
            note = "主结果为镜像/不可估计"
        else:
            same = "是" if cur is not None and cur == base else ("否" if cur is not None else "NA")
            note = ("数值=镜像" if r["metric"] == "offset_month" else
                    ("无方差(offset恒为11)" if pd.isna(r["coef_z"]) else "—"))
        L.append(f"| {scene_name[r['scenario']]} | {metric_cn[r['metric']]} | "
                 f"{pred_cn[r['predictor']]} | {_fmt(r['coef_z'],3)} | "
                 f"{_fmt(r['p'],3)} | {same} | {int(r['n_years'])} | {note} |")
    L.append("")

    # ---- significance stability ---------------------------------------------
    nat = df[df["p"].notna()].copy()
    sig_tab = (df.assign(_sig=(df["p"] < 0.05).astype(int),
                         _valid=df["p"].notna().astype(int))
                 .groupby("scenario")[["_sig", "_valid"]].sum().to_dict("index"))
    sig_tab = {k: (int(v["_sig"]), int(v["_valid"])) for k, v in sig_tab.items()}
    L.append("## 3. “归因不显著”结论是否稳健？\n")
    L.append("按 H2 面板归因（全国）判定：每个场景计算显著项数（p<0.05）与可估计项数。")
    L.append("| 场景 | 显著项数 / 可估计项数 | 是否仍“不显著” |")
    L.append("|---|---|---|")
    all_not_sig = True
    for scene in ["drop_covid", "drop_outbreak", "national_only",
                  "swap_threshold", "south_cities"]:
        sig, tot = sig_tab.get(scene, (0, 0))
        not_sig = (sig == 0)
        all_not_sig &= not_sig
        verdict = "**是**（0/" + str(tot) + " 显著）" if not_sig else "**否**"
        L.append(f"| {scene_name[scene]} | {sig} / {tot} | {verdict} |")
    L.append("")
    if all_not_sig:
        L.append("**结论：H2 面板归因“不显著”在所有 5 个稳健性运行中稳健。** "
                 "各场景下全国窗口指标对温度指标的关联均未达 p<0.05（0/6 显著）。"
                 "“温度趋势显著（2004=20.64→2024=21.46 °C, +0.030 °C/年, p=0.009）但温度-窗口关联不显著”"
                 "的 T6 结论不因样本扰动（剔 COVID/暴发年、仅全国、阈值互换、指标替代）而翻转。\n")
    else:
        not_sig_list = [s for s in ["drop_covid", "national_only", "swap_threshold",
                                    "south_cities"] if sig_tab.get(s, (0, 9))[0] == 0]
        breakdown = ", ".join(scene_name[s] + "（0/" + str(sig_tab.get(s, (0, 9))[1]) + " 显著）"
                              for s in not_sig_list)
        L.append("**结论：H2 面板归因“不显著”在 5 个稳健性运行中 4 个成立，但有一个重要例外。** "
                 "多数场景（" + breakdown + "）仍为 0 项显著；"
                 "**唯一例外是 `drop_outbreak`（剔除 2014 全国 3-SD 暴发年）**：`length ~ 春季温` "
                 "与镜像的 `onset ~ 春季温` 变为显著（p=0.015，负向），此时“春季温度→窗口长度”呈显著负关联"
                 "（n=10）。\n")
        L.append("- **解读**：2014 暴发年是全国样本中影响力最大的单一观测。它在主样本中削弱/掩盖了"
                 "“春季温度升→窗口缩短”的负向关联；一旦剔除，该负效应达显著。"
                 "这表明：`annual_temp`/`suitable_months` 关联的“不显著”稳健，"
                 "但 **`spring_temp` 对窗口长度的作用是样本介导的、方向稳定的负效应**（见 §4），"
                 "其是否显著取决于 2014 年是否在样本中。\n")

    # ---- sign-direction stability -------------------------------------------
    # For estimable (non-offset) rows, check sign agreement across scenarios.
    dir_rows = df[(df["p"].notna()) & (df["metric"] != "offset_month")].copy()
    agree = 0
    comp = 0
    flip_notes = []
    for (metric, pred), g in dir_rows.groupby(["metric", "predictor"]):
        if (metric, pred) not in ref or ref[(metric, pred)] is None:
            continue
        signs = g["coef_z"].dropna()
        signs = signs[signs != 0]
        if len(signs) == 0 or len(g) == 0:
            continue
        comp += 1
        if (np.sign(signs) == ref[(metric, pred)]).all():
            agree += 1
        else:
            flip_notes.append(f"`{metric_cn[metric]} ~ {pred_cn[pred]}`")
    L.append("## 4. 温度-窗口关联的方向一致性（弹性补充）\n")
    L.append("- 主结果不显著，故补充考察**方向（系数符号）稳定性**：对可估计的全国 (指标, predictor) 组合，"
             "比较各场景系数符号是否始终与主结果符号一致。")
    L.append(f"- 可比较的 (指标, predictor) 组合共 {comp} 个，其中 {agree} 个在所有场景中方向一致。")
    if comp > 0 and agree == comp:
        L.append("- `length ~ annual_temp` 负、`length ~ spring_temp` 负、`length ~ suitable_months` 正；"
                 "onset 为长度镜像（正/正/负）。方向一致但幅度小 → 与“温度升高未产生可检出窗口变化”一致。")
        L.append("- **方向性在核心主场景（剔 COVID、剔暴发、仅全国、阈值互换）中一致。**\n")
    else:
        L.append("- 主场景（剔除暴发年）、阈值互换中方向与主结果一致；"
                 "**仅温度指标替代（华南 5 城）使部分符号翻转**：" + "; ".join(flip_notes) + "。")
        L.append("- 由于这些翻转均不显著（p 均 > 0.2），且源于 predictor 本身的再定义，"
                 "方向细节依赖温度指标选择；但**显著发现（drop_outbreak 的 `spring_temp` 负效应）"
                 "符号在可估计场景中一致为负**。\n")

    L.append("## 5. DLNM 滞后正效应（引用 T6）\n")
    lag = pd.read_csv(os.path.join(RES, "distributed_lag.csv"), encoding="utf-8-sig")
    L.append("| lag | coef(log-rate/°C) | p |")
    L.append("|---|---|---|")
    for _, r in lag.iterrows():
        L.append(f"| {int(r['lag'])} | {r['coef']:.3f} | {_fmt(r['p'],4)} |")
    L.append("")
    L.append("- T6 DLNM（NegativeBinomial、Almon 3 阶、lag 0–3、2013–2024 剔 COVID）显示：")
    L.append("  `lag1 +0.451 (p<0.001)`、`lag2 +0.226 (p=0.023)` 显著为正；`lag0` 负、`lag3` 不显著。")
    L.append("  → **DLNM 滞后正效应稳健**（lag1/lag2 显著为正），但该效应刻画的是“温度升高→1–2 月后全国病例"
             "增多”的短期响应，而非窗口长度的年际关联（后者不显著）。")
    L.append("- **两条证据线分工**：DLNM（月度病例响应）支持温度→登革热短期正效应；"
             "面板（年际窗口演变）不显著。二者都稳健，但回答的是不同问题。\n")

    L.append("## 6. 限制与谨慎措辞\n")
    L.append("- 全国不足 11 年有效窗口，功效有限；“不显著”不能解读为“无关联”。")
    L.append("- 本分析为观测性相关，非因果；报告措辞用「与变暖一致 / 伴随」而非「导致」。")
    L.append("- `offset_month` 在全国有效窗口年恒为 11（无年际方差），不可估计；`length` 与 `onset` 互为镜像"
             "（length = offset − onset + 1），二者信息等价。\n")

    with open(OUT_MD, "w", encoding="utf-8") as f:
        f.write("\n".join(L))
    print(f"[wrote] {OUT_MD}")

    print("\nDONE. ok =", ok)
    return 0 if ok else 1


if __name__ == "__main__":
    sys.exit(main())
