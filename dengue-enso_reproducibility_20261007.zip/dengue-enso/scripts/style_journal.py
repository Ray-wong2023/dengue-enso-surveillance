# -*- coding: utf-8 -*-
"""
Journal-specification figure style (Nature / PLoS compatible).

Key rules implemented here (sources: Nature author figure guidelines;
PLoS figure requirements - width 6.68-19.05 cm, 300-600 dpi, Arial/Times/
Symbol 8-12 pt or Nature 5-7 pt final size, RGB, captions in manuscript):

  * canvas designed at FINAL PRINT SIZE: double column 183 mm, single 89 mm
  * sans-serif font stack (Arial -> Helvetica -> DejaVu Sans)
  * base font 6 pt, panel letters bold 8 pt, tick labels 6 pt
  * Okabe-Ito colour-blind-safe palette for series colours
  * bold lowercase panel letters (a, b, c ...) without parentheses
  * no figure titles inside the image (captions live in the manuscript)
  * exports: vector PDF (primary) + 300-dpi PNG (preview) +
    600-dpi LZW TIFF (PLoS-style raster deliverable)
"""
import os
from pathlib import Path

import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
from matplotlib import font_manager
from PIL import Image

MM_PER_IN = 25.4
WIDTH_DOUBLE_MM = 190.0   # Lancet double column
WIDTH_INTER_MM = 140.0    # Lancet 1.5 column
WIDTH_SINGLE_MM = 90.0    # Lancet single column
BASE_PT = 9.0     # Lancet: >=7 pt at final size
PANEL_PT = 9.0
LINE_PT = 0.7          # >= 0.2 mm at final size (= 0.57 pt)
SERIES_COLORS = {       # Okabe-Ito (colour-blind safe) + journal navy/greys
    "black": "#000000", "orange": "#E69F00", "sky": "#56B4E9",
    "green": "#009E73", "yellow": "#F0E442", "blue": "#0072B2",
    "vermillion": "#D55E00", "purple": "#CC79A7", "grey": "#8A8A8A",
    "navy": "#17395C", "midgrey": "#BFBFBF", "lightgrey": "#E8E8E8",
}
FONT_STACK = ["Arial", "Helvetica", "Liberation Sans", "DejaVu Sans"]


def mm_in(mm: float) -> float:
    return mm / MM_PER_IN


def set_style():
    chosen = "DejaVu Sans"
    for f in FONT_STACK:
        try:
            font_manager.findfont(f, fallback_to_default=False)
            chosen = f
            break
        except Exception:  # noqa: BLE001
            continue
    plt.rcParams.update({
        "font.sans-serif": [chosen],
        "font.family": "sans-serif",
        "font.size": BASE_PT,
        "axes.titlesize": BASE_PT,
        "axes.labelsize": BASE_PT,
        "xtick.labelsize": BASE_PT - 0.5,
        "ytick.labelsize": BASE_PT - 0.5,
        "legend.fontsize": BASE_PT - 0.5,
        "axes.linewidth": LINE_PT,
        "xtick.major.width": LINE_PT,
        "ytick.major.width": LINE_PT,
        "xtick.major.size": 2.0,
        "ytick.major.size": 2.0,
        "lines.linewidth": 1.0,
        "axes.unicode_minus": False,
        "axes.grid": False,          # Lancet: minimal ink
        "grid.alpha": 0.0,
        "grid.linewidth": 0.0,
        "axes.spines.top": False,
        "axes.spines.right": False,
        "axes.facecolor": "white",
        "figure.facecolor": "white",
        "savefig.facecolor": "white",
        "legend.frameon": False,
        "pdf.fonttype": 42,     # embed TrueType (editable text in PDF)
        "ps.fonttype": 42,
    })
    return chosen


def panel_letter(ax, letter: str, dx: float = 0.005, dy: float = 1.03):
    """Bold uppercase panel letter above the top-left of the axes."""
    ax.text(dx, dy, letter, transform=ax.transAxes, fontsize=PANEL_PT,
            fontweight="bold", ha="left", va="bottom", zorder=10)


def save(fig, path_no_ext: str):
    """Vector PDF (primary) + 300-dpi PNG (preview) + 600-dpi LZW TIFF.

    bbox_inches="tight" keeps axis labels that sit just outside the nominal
    canvas; the resulting size stays within ~2 mm of the nominal column width,
    which the standards audit tolerates (journals scale to column width).
    """
    import io
    kw = dict(bbox_inches="tight", pad_inches=0.02)
    fig.savefig(path_no_ext + ".pdf", **kw)
    fig.savefig(path_no_ext + ".png", dpi=300, **kw)
    buf = io.BytesIO()
    fig.savefig(buf, format="png", dpi=1200, **kw)
    buf.seek(0)
    with Image.open(buf) as im:
        rgb = im.convert("RGB")
    rgb.save(path_no_ext + ".tif", format="TIFF", compression="tiff_lzw",
             dpi=(1200, 1200))
    return path_no_ext + ".pdf"
