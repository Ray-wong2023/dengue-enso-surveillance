# -*- coding: utf-8 -*-
"""
Revision pass 3: leverage / influence diagnostics for the 2014 outbreak year.

Addresses simulated-reviewer P1/P3 ("2014 leverage diagnostics: Cook's D and
influence analysis").

What this script does (national main calibration, threshold (0.05,0.95),
valid window years within temperature coverage, COVID/incomplete years
dropped — exactly the attribution.py estimation sample):
  1. Replicates the primary panel regressions
     Model 1: length_months ~ annual_temp
     Model 2: length_months ~ spring_temp + suitable_months
     (z-scored predictors, HC1 robust SE) and asserts the coefficients match
     the frozen results/attribution.csv.
  2. OLS influence diagnostics on Model 2 (the specification whose drop-2014
     result is reported in the paper): hat values, Cook's distance, DFBETAS
     for the spring-temperature coefficient; flags years exceeding the
     conventional 4/n Cook's-D threshold.
  3. Leave-one-out refits of Model 2: for each omitted year, the spring
     coefficient and p-value — showing whether significance hinges on 2014
     alone or on any single year.
  4. Leave-one-out Mann-Kendall (tie-corrected) + Theil-Sen + breakpoint for
     each of the four window metrics: does any single year create or mask a
     trend/breakpoint?

Inputs (read-only):  data/processed/windows.csv (FROZEN)
                     data/raw/temperature_cities.csv
                     results/attribution.csv (frozen reference)
Outputs:
  results/leverage_diagnostics.csv   per-year influence + leave-one-out
  results/loo_trend_mk.csv           per-year leave-one-out trend tests
  figures/fig6_leverage.png/.pdf     Cook's D + leave-one-out coef plot

Assertions: replicated Model 2 spring coef/p match attribution.csv; 2014 has
the maximum Cook's D; outputs complete. Failure -> exit(1).
"""
import os
import sys

import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
import numpy as np
import pandas as pd
import statsmodels.formula.api as smf

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
PROC = os.path.join(ROOT, "data", "processed")
RAW = os.path.join(ROOT, "data", "raw")
RES = os.path.join(ROOT, "results")
FIG = os.path.join(ROOT, "figures")
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from style_common import OUTBREAK_COLOR, COLORS, set_style, save_fig  # noqa: E402
from trend_analysis import mann_kendall, sen_slope, breakpoint_test, METRIC_COLS  # noqa: E402

IN_WINDOWS = os.path.join(PROC, "windows.csv")
IN_TEMP = os.path.join(RAW, "temperature_cities.csv")
IN_ATTR = os.path.join(RES, "attribution.csv")
OUT_LEV = os.path.join(RES, "leverage_diagnostics.csv")
OUT_LOO = os.path.join(RES, "loo_trend_mk.csv")
OUT_FIG = os.path.join(FIG, "fig6_leverage")

DEFAULT_THRESHOLD = "(0.05,0.95)"
COVID_YEARS = {2020, 2021}
INCOMPLETE_YEARS = {2022}
NATIONAL_CITIES = ["广州", "深圳", "南宁", "昆明", "福州", "海口", "厦门", "杭州"]
SPRING_MONTHS = [3, 4, 5]
SUITABLE_T = 21.0
OUTBREAK_YEAR = 2014
METRICS = ["onset", "offset", "length", "peak"]


def zscore(s):
    """Identical to attribution.zscore (population SD, ddof=0)."""
    s = pd.to_numeric(s, errors="coerce")
    return (s - s.mean()) / s.std(ddof=0) if s.std(ddof=0) > 0 else s * 0.0


def build_estimation_sample():
    """The exact national estimation sample used by attribution.py."""
    win = pd.read_csv(IN_WINDOWS, encoding="utf-8-sig")
    win = win[win["threshold"] == DEFAULT_THRESHOLD].copy()
    win = win.dropna(subset=["length_months"])
    win = win[~win["year"].isin(COVID_YEARS | INCOMPLETE_YEARS)]
    nat = win[win["province"] == "全国"][["province", "year",
                                          "length_months", "onset_month",
                                          "offset_month", "peak_month"]]
    temp = pd.read_csv(IN_TEMP, encoding="utf-8-sig")
    cities = temp[temp["city"].isin(NATIONAL_CITIES)]
    m = cities.groupby(["year", "month"], as_index=False)["tmean"].mean()
    rows = []
    for year, grp in m.groupby("year"):
        full = grp.set_index("month")["tmean"]
        rows.append({"province": "全国", "year": int(year),
                     "annual_temp": float(full.loc[full.index.isin(range(1, 13))].mean()),
                     "spring_temp": float(full.loc[full.index.isin(SPRING_MONTHS)].mean()),
                     "suitable_months": int((full >= SUITABLE_T).sum())})
    t = pd.DataFrame(rows)
    return nat.merge(t, on=["province", "year"], how="inner").sort_values("year")


def fit_m2(d):
    """Model 2 on sample d -> (spring_coef, spring_p, full_result|None)."""
    zd = d.copy()
    for p in ("annual_temp", "spring_temp", "suitable_months"):
        zd[p] = zscore(d[p])
    res = smf.ols("length_months ~ spring_temp + suitable_months",
                  data=zd).fit(cov_type="HC1")
    return (float(res.params["spring_temp"]), float(res.pvalues["spring_temp"]),
            res)


def main():
    print("=" * 64)
    print("Step 1: build estimation sample (attribution.py replica)")
    d = build_estimation_sample()
    n = len(d)
    years = d["year"].tolist()
    print(f"  n={n} years: {years}")
    if n != 11 or OUTBREAK_YEAR not in years:
        print("[FAIL] unexpected estimation sample")
        return 1

    print("=" * 64)
    print("Step 2: replicate Model 1 / Model 2 and anchor to attribution.csv")
    attr = pd.read_csv(IN_ATTR, encoding="utf-8-sig")
    nat = attr[attr["province"] == "全国"]
    # Model 1
    c1, p1, _ = fit_m2_full(d, "length_months ~ annual_temp")
    ref1 = nat[(nat["metric"] == "length_months") &
               (nat["predictor"] == "annual_temp")].iloc[0]
    # Model 2
    c2, p2, res2 = fit_m2(d)
    ref2 = nat[(nat["metric"] == "length_months") &
               (nat["predictor"] == "spring_temp")].iloc[0]
    print(f"  Model 1 spring(annual): coef {c1:+.4f} vs frozen {ref1['coef']:+.4f}"
          f" | p {p1:.4f} vs {ref1['p']:.4f}")
    print(f"  Model 2 spring:         coef {c2:+.4f} vs frozen {ref2['coef']:+.4f}"
          f" | p {p2:.4f} vs {ref2['p']:.4f}")
    if abs(c1 - ref1["coef"]) > 5e-4 or abs(p1 - ref1["p"]) > 5e-4:
        print("[FAIL] Model 1 does not match frozen attribution.csv")
        return 1
    if abs(c2 - ref2["coef"]) > 5e-4 or abs(p2 - ref2["p"]) > 5e-4:
        print("[FAIL] Model 2 does not match frozen attribution.csv")
        return 1
    print("  replication OK (anchored to frozen results)")

    print("=" * 64)
    print("Step 3: influence diagnostics on Model 2 (hat, Cook's D, DFBETAS)")
    infl = res2.get_influence()
    cooks = infl.cooks_distance[0]
    hat = infl.hat_matrix_diag
    # DFBETAS for spring_temp coefficient
    dfbetas = infl.dfbetas[:, list(res2.params.index).index("spring_temp")]
    thr = 4.0 / n
    rows = []
    for i, yr in enumerate(years):
        rows.append({"year": int(yr), "leverage_hat": round(float(hat[i]), 4),
                     "cooks_d": round(float(cooks[i]), 4),
                     "dfbeta_spring": round(float(dfbetas[i]), 4),
                     "cooks_d_gt_4n": bool(cooks[i] > thr)})
        print(f"  {yr}: hat={hat[i]:.3f}  Cook's D={cooks[i]:.3f}  "
              f"DFBETA_spring={dfbetas[i]:+.3f}{'  <-- >4/n' if cooks[i] > thr else ''}")
    max_cook_year = int(d["year"].iloc[int(np.argmax(cooks))])
    print(f"  max Cook's D year: {max_cook_year} (threshold 4/n = {thr:.3f})")
    if max_cook_year != OUTBREAK_YEAR:
        print(f"  [NOTE] {max_cook_year}, not {OUTBREAK_YEAR}, has the "
              f"largest overall influence — reported honestly in outputs")
    # the direction test that matters for the paper's claim: 2014 pulls the
    # spring coefficient toward zero/positive (DFBETA>0), its omission
    # makes the association more negative -> significant
    d14 = float(dfbetas[years.index(OUTBREAK_YEAR)])
    if d14 <= 0:
        print(f"[FAIL] 2014 DFBETA_spring expected positive (towards 0/+) got {d14}")
        return 1
    c_no14, p_no14, _ = fit_m2(d[d["year"] != OUTBREAK_YEAR])
    if not (p_no14 < 0.05 and c_no14 < c2):
        print(f"[FAIL] drop-2014 refit expected negative+significant, "
              f"got coef {c_no14:+.4f} p={p_no14:.4f}")
        return 1
    print(f"  direction check OK: omit-2014 coef {c_no14:+.4f}, "
          f"p={p_no14:.4f} (mirrors frozen sensitivity p=0.015)")

    print("=" * 64)
    print("Step 4: leave-one-out Model 2 refits (spring coef / p)")
    loo_rows = []
    for yr in years:
        sub = d[d["year"] != yr]
        c, p, _ = fit_m2(sub)
        loo_rows.append({"omitted_year": int(yr), "n": len(sub),
                         "spring_coef": round(c, 4), "spring_p": round(p, 4),
                         "significant_0.05": bool(p < 0.05)})
        print(f"  omit {yr}: coef {c:+.4f}  p={p:.4f} "
              f"{'*' if p < 0.05 else ''}")
    loo = pd.DataFrame(loo_rows)
    n_sig = int(loo["significant_0.05"].sum())
    print(f"  {n_sig}/{len(loo)} leave-one-out refits significant; "
          f"omitting {OUTBREAK_YEAR} -> p={loo[loo['omitted_year']==OUTBREAK_YEAR]['spring_p'].iloc[0]:.4f}")

    print("=" * 64)
    print("Step 5: leave-one-out MK/Sen/breakpoint per window metric")
    w = pd.read_csv(IN_WINDOWS, encoding="utf-8-sig")
    sub = w[(w["province"] == "全国") & (w["threshold"] == DEFAULT_THRESHOLD) &
            w["year"].between(2012, 2024)].sort_values("year")
    trend_rows = []
    for metric, col in METRIC_COLS.items():
        for yr in years:
            s2 = sub[sub["year"] != yr].dropna(subset=[col])
            x = s2["year"].to_numpy(float)
            y = s2[col].to_numpy(float)
            tau, p = mann_kendall(y)
            slope = sen_slope(x, y)
            byr, bp = breakpoint_test(x, y)
            trend_rows.append({"metric": metric, "omitted_year": int(yr),
                               "n": len(y), "mk_tau": round(float(tau), 4),
                               "mk_p": round(float(p), 5),
                               "sen_slope_yr": round(float(slope), 4),
                               "breakpoint_year": byr, "breakpoint_p": bp})
        # also the full-series reference
        s3 = sub.dropna(subset=[col])
        tau, p = mann_kendall(s3[col].to_numpy(float))
        trend_rows.append({"metric": metric, "omitted_year": -1, "n": len(s3),
                           "mk_tau": round(float(tau), 4),
                           "mk_p": round(float(p), 5), "sen_slope_yr": np.nan,
                           "breakpoint_year": np.nan, "breakpoint_p": np.nan})
    loo_trend = pd.DataFrame(trend_rows)
    for metric in METRICS:
        g = loo_trend[(loo_trend["metric"] == metric) &
                      (loo_trend["omitted_year"] >= 0)]
        nsig = int((g["mk_p"] < 0.05).sum())
        print(f"  {metric:7s}: {nsig}/{len(g)} leave-one-out MK significant "
              f"(full-series tau={loo_trend[(loo_trend['metric']==metric)&(loo_trend['omitted_year']==-1)]['mk_tau'].iloc[0]:+.4f})")

    print("=" * 64)
    print("Step 6: write outputs")
    lev = pd.DataFrame(rows)
    lev.insert(1, "spring_coef_full", round(c2, 4))
    lev.insert(2, "spring_p_full", round(p2, 4))
    lev.to_csv(OUT_LEV, index=False, encoding="utf-8-sig")
    print(f"[wrote] {OUT_LEV}")
    loo_out = loo.copy()
    loo_out.to_csv(OUT_LEV.replace(".csv", "_loo_model2.csv"), index=False,
                   encoding="utf-8-sig")
    print(f"[wrote] {OUT_LEV.replace('.csv', '_loo_model2.csv')}")
    loo_trend.to_csv(OUT_LOO, index=False, encoding="utf-8-sig")
    print(f"[wrote] {OUT_LOO} ({len(loo_trend)} rows)")

    print("=" * 64)
    print("Step 7: figure fig6_leverage")
    set_style()
    fig, axes = plt.subplots(1, 2, figsize=(9.6, 4.2))
    ax = axes[0]
    colors_pt = [OUTBREAK_COLOR if y == OUTBREAK_YEAR else "#1783FF"
                 for y in lev["year"]]
    ax.bar(lev["year"].astype(str), lev["cooks_d"], color=colors_pt,
           edgecolor="white")
    ax.axhline(thr, color="0.35", ls="--", lw=1.2)
    ax.annotate(f"4/n = {thr:.2f}", xy=(0.02, thr), xytext=(0.02, thr + 0.02),
                fontsize=8, color="0.35", xycoords="axes fraction")
    ax.set_ylabel("Cook's distance")
    ax.set_title("Influence of each year\n(Model 2: length ~ spring temp + suitable months)")
    ax.tick_params(axis="x", rotation=60)
    ax.annotate("2014 outbreak", xy=(str(OUTBREAK_YEAR),
                                     lev.loc[lev["year"] == OUTBREAK_YEAR,
                                             "cooks_d"].iloc[0]),
                xytext=(0, 6), textcoords="offset points", fontsize=8,
                color=OUTBREAK_COLOR, ha="center")
    ax = axes[1]
    cl = [OUTBREAK_COLOR if y == OUTBREAK_YEAR else "#1783FF"
          for y in loo["omitted_year"]]
    ax.scatter(loo["omitted_year"], loo["spring_coef"], c=cl, s=42,
               zorder=3, edgecolors="white")
    for _, r in loo.iterrows():
        ax.annotate(f"{r['spring_p']:.2f}", (r["omitted_year"], r["spring_coef"]),
                    xytext=(0, 6), textcoords="offset points", fontsize=7,
                    ha="center", color="0.3")
    ax.axhline(0, color="0.5", lw=1, ls="--")
    ax.axhline(c2, color="#1783FF", lw=0.9, ls=":", alpha=0.7)
    ax.axhspan(0, c2, color="grey", alpha=0.0)
    ax.set_xlabel("Year omitted from the Model-2 refit")
    ax.set_ylabel("Spring-temperature coefficient (months/SD)")
    ax.set_title("Leave-one-out refits\n(label = HC1 p-value)")
    fig.tight_layout()
    save_fig(fig, OUT_FIG)
    print(f"[wrote] {OUT_FIG}.png/.pdf")

    print("=" * 64)
    print("Step 8: output assertions")
    ok = True
    if len(lev) != n or lev.isna().any().any():
        print("[FAIL] leverage table incomplete")
        ok = False
    if not bool(lev.loc[lev["year"] == OUTBREAK_YEAR, "cooks_d_gt_4n"].iloc[0]) \
            and float(lev.loc[lev["year"] == OUTBREAK_YEAR, "cooks_d"].iloc[0]) <= thr:
        print("[WARN] 2014 Cook's D does not exceed 4/n (report honestly)")
    if len(loo_trend) != 4 * (n + 1):
        print("[FAIL] loo trend grid incomplete")
        ok = False
    nsig_trend = int((loo_trend[loo_trend["omitted_year"] >= 0]["mk_p"] < 0.05).sum())
    print(f"  leave-one-out MK significant cells: {nsig_trend}/44")
    print(f"\nDONE. ok = {ok}")
    return 0 if ok else 1


def fit_m2_full(d, formula):
    """Fit an OLS with HC1 on z-scored sample d (generic single-predictor)."""
    zd = d.copy()
    for p in ("annual_temp", "spring_temp", "suitable_months"):
        zd[p] = zscore(d[p])
    res = smf.ols(formula, data=zd).fit(cov_type="HC1")
    pred = formula.split("~")[1].strip()
    return float(res.params[pred]), float(res.pvalues[pred]), res


if __name__ == "__main__":
    sys.exit(main())
