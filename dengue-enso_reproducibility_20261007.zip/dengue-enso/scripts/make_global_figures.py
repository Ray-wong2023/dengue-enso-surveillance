# -*- coding: utf-8 -*-
"""
Journal figures for the global detectability paper - enriched layouts.

All canvases designed at final print size (Lancet/Elsevier):
  double column 190 mm (figs 1-4, 6-8), single column 90 mm (fig 5);
  Arial >= 7 pt at final size (base 9 pt); bold uppercase panel letters
  A/B/C/D placed ABOVE each panel (never colliding with data);
  no gridlines; left+bottom spines only; Okabe-Ito CVD-safe palette;
  legends outside data areas or in verified-sparse corners;
  exports vector PDF + 300-dpi PNG + 1200-dpi LZW TIFF.

Panels:
  fig1  A map  B usable-years hist  C country bars  D units-with-windows/yr
  fig2  A length vs |lat|  B onset wrapped  C hemisphere box  D offset wrapped
        E country season calendars
  fig3  A warming hist  B warming vs |lat|  C hemisphere box  D units per band
  fig4  A forest  B per-unit slopes  C long-series examples
        D threshold length distributions  E primary-vs-strict agreement
  fig5  A MDS80 vs n  B cumulative detection  C extra-years hist
        D MDS80 by metric  E 80%-power share by metric  F extra years by metric
  fig6  A national season windows  B DLNM lag response  C leave-one-out
        D detection-limit comparison
  fig7  A elasticity forest  B R2 comparison  C hexbin mechanism
        D pooled psi forest across definitions
  fig8  A onset psi  B length psi  C significant-share bars  D psi vs |lat|
"""
import os
import sys
from pathlib import Path

import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
from matplotlib.patches import Polygon as MplPolygon
import numpy as np
import pandas as pd
from scipy import stats

ROOT = Path(os.getcwd()).resolve()
assert (ROOT / "results").is_dir(), "run from the dengue-enso project root"
RES = ROOT / "results"
FIG = ROOT / "figures"
RAWG = ROOT / "data" / "raw" / "global"
PROC = ROOT / "data" / "processed"
sys.path.insert(0, str(Path(__file__).resolve().parent))
import style_journal as SJ  # noqa: E402
import shp_reader as SHP  # noqa: E402
from global_intensity_timing import _dl  # noqa: E402

PRIMARY_THR = "(0.05,0.95)"
TARGETS = [0.01, 0.02, 0.05, 0.10]
TARGET_LABELS = {0.01: "0.1", 0.02: "0.2", 0.05: "0.5", 0.10: "1.0"}
METRICS = ["onset", "offset", "length", "peak"]
NICE = {"onset": "Onset", "offset": "Offset", "length": "Length", "peak": "Peak"}
C = SJ.SERIES_COLORS
W1 = SJ.mm_in(SJ.WIDTH_DOUBLE_MM)
W2 = SJ.mm_in(SJ.WIDTH_SINGLE_MM)


def _safe(p: Path) -> Path:
    rp = p.resolve()
    if not str(rp).startswith(str(ROOT)):
        raise ValueError(f"path escapes project root: {rp}")
    return rp


def _pfmt(p: float) -> str:
    """Format a p-value for figure annotation: floor at p<0.001."""
    return "p<0.001" if p < 0.001 else f"p={p:.3f}"


def load():
    return {
        "cov": pd.read_csv(_safe(RES / "global_coverage_by_unit.csv"), encoding="utf-8-sig"),
        "sites": pd.read_csv(_safe(RES / "global_unit_sites.csv"), encoding="utf-8-sig"),
        "trends": pd.read_csv(_safe(RES / "global_trends.csv"), encoding="utf-8-sig"),
        "det": pd.read_csv(_safe(RES / "global_detectability.csv"), encoding="utf-8-sig"),
        "meta": pd.read_csv(_safe(RES / "global_meta_analysis.csv"), encoding="utf-8-sig"),
        "inten": pd.read_csv(_safe(RES / "global_intensity_timing.csv"), encoding="utf-8-sig"),
        "psi": pd.read_csv(_safe(RES / "global_psi_estimates.csv"), encoding="utf-8-sig"),
        "warm": pd.read_csv(_safe(RES / "global_warming_rates.csv"), encoding="utf-8-sig"),
        "win": pd.read_csv(_safe(RES / "global_windows.csv"), encoding="utf-8-sig"),
        "cn_trends": pd.read_csv(_safe(RES / "trends.csv"), encoding="utf-8-sig"),
        "cn_power": pd.read_csv(_safe(RES / "power_analysis.csv"), encoding="utf-8-sig"),
        "cn_lag": pd.read_csv(_safe(RES / "distributed_lag.csv"), encoding="utf-8-sig"),
        "cn_loo": pd.read_csv(_safe(RES / "leverage_diagnostics_loo_model2.csv"), encoding="utf-8-sig"),
        "cn_windows": pd.read_csv(_safe(PROC / "windows.csv"), encoding="utf-8-sig"),
    }


def basemap(ax, lons=(-130, 175), lats=(-40, 50)):
    zp = RAWG / "ne_110m_countries.zip"
    shp = RAWG / "_ne110.shp"
    if not shp.is_file():
        import zipfile
        with zipfile.ZipFile(_safe(zp)) as z:
            name = [n for n in z.namelist() if n.endswith(".shp")][0]
            shp.write_bytes(z.read(name))
    for r in SHP.read_shp(_safe(shp)):
        ax.add_patch(MplPolygon(r, closed=True, facecolor="#E3E3E3",
                                edgecolor="#9E9E9E", linewidth=0.3, zorder=1))
    ax.set_xlim(*lons)
    ax.set_ylim(*lats)
    ax.set_aspect("auto")
    ax.grid(False)


def fig1(d):
    fig = plt.figure(figsize=(W1, W1 * 0.72))
    gs = fig.add_gridspec(2, 3, height_ratios=[1.35, 1.0],
                          width_ratios=[1.0, 1.0, 1.0],
                          hspace=0.52, wspace=0.42)

    ax = fig.add_subplot(gs[0, :])
    basemap(ax)
    s = d["sites"].dropna(subset=["lat", "lon"]).drop_duplicates("unit")
    s = s.merge(d["cov"][["unit", "tier", "n_usable_years"]], on="unit", how="left")
    ab = s[s["tier"].isin(["A_trend_strong", "B_trend_low_power"])]
    sc = ax.scatter(ab["lon"], ab["lat"], s=ab["n_usable_years"] * 2.0,
                    c=ab["n_usable_years"], cmap="Blues", vmin=8, vmax=30,
                    alpha=1.0, edgecolors="white", linewidths=0.35, zorder=3)
    cb = fig.colorbar(sc, ax=ax, shrink=0.85, pad=0.01, aspect=26)
    cb.set_label("usable window years", fontsize=SJ.BASE_PT - 0.5)
    cb.ax.tick_params(labelsize=SJ.BASE_PT - 1)
    ax.set_xlabel("Longitude")
    ax.set_ylabel("Latitude")
    ax.set_xticks([-120, -60, 0, 60, 120])
    ax.set_yticks([-30, 0, 30])
    SJ.panel_letter(ax, "A")

    ax2 = fig.add_subplot(gs[1, 0])
    ax2.hist(ab["n_usable_years"], bins=np.arange(6, 33, 3), color=C["blue"],
             edgecolor="white", linewidth=0.5)
    ax2.set_xlabel("usable window years")
    ax2.set_ylabel("number of units")
    ax2.set_ylim(0, 170)
    ax2.yaxis.set_major_locator(plt.MaxNLocator(4))
    SJ.panel_letter(ax2, "B")

    ax3 = fig.add_subplot(gs[1, 1])
    top = ab.groupby("country").size().sort_values(ascending=False).head(8)
    ax3.barh(range(len(top)), top.values[::-1], color=C["green"],
             edgecolor="white", linewidth=0.5)
    ax3.set_xlim(0, 172)
    ax3.set_yticks(range(len(top)))
    ax3.set_yticklabels([str(c).title()[:14] for c in top.index][::-1])
    ax3.tick_params(axis="y", labelsize=SJ.BASE_PT - 2)
    ax3.set_xlabel("units in the primary analysis")
    ax3.xaxis.set_major_locator(plt.MaxNLocator(4))
    SJ.panel_letter(ax3, "C")

    ax4 = fig.add_subplot(gs[1, 2])
    w = d["win"]
    w = w[(w["threshold"] == PRIMARY_THR)].dropna(subset=["onset_month"])
    per_year = w.groupby("year")["unit"].nunique()
    yrs = np.arange(1995, 2026)
    counts = [int(per_year.get(y, 0)) for y in yrs]
    ax4.bar(yrs, counts, color=C["navy"], edgecolor="white", linewidth=0.3)
    ax4.set_xlabel("year")
    ax4.set_ylabel("units with valid windows")
    ax4.set_ylim(0, max(counts) * 1.25)
    ax4.set_xticks([1995, 2000, 2005, 2010, 2015, 2020, 2025])
    ax4.tick_params(axis="x", rotation=45)
    ax4.yaxis.set_major_locator(plt.MaxNLocator(4))
    SJ.panel_letter(ax4, "D")
    SJ.save(fig, str(FIG / "global_fig1_coverage"))


def fig4(d):
    fig = plt.figure(figsize=(W1, W1 * 1.14))
    gs = fig.add_gridspec(3, 2, height_ratios=[1.55, 1.0, 1.0], hspace=0.45,
                          wspace=0.30)

    ax = fig.add_subplot(gs[0, :])
    meta = d["meta"]
    strata = ["n_ge_10", "n_ge_20", "n_ge_25"]
    ypos, ylabels, y = [], [], 0
    for m in METRICS:
        for st in strata:
            r = meta[(meta["metric"] == m) & (meta["stratum"] == st)]
            if not len(r):
                continue
            r = r.iloc[0]
            wgt = 1.0 / (r["se"] ** 2) if r["se"] > 0 else 1.0
            ms = 3.0 + 7.0 * (wgt / (wgt + 4e4))
            filled = st == "n_ge_25"
            ax.errorbar(r["pooled_slope"], y,
                        xerr=[[r["pooled_slope"] - r["ci_lo"]],
                              [r["ci_hi"] - r["pooled_slope"]]],
                        fmt="s", ms=ms, color=C["navy"], capsize=1.4, lw=0.8,
                        mfc=C["navy"] if filled else "white", mew=0.8)
            ypos.append(y)
            ylabels.append(f"{m} · {st.replace('n_ge_', 'n≥')}")
            y += 1
        y += 0.9
    ax.axvline(0, color="0.4", lw=0.6, ls="--")
    ax.set_yticks(ypos)
    ax.set_yticklabels(ylabels)
    ax.set_ylim(-0.6, y - 0.4)
    ax.invert_yaxis()
    ax.set_xlabel("pooled trend (months per year)")
    ax.xaxis.set_major_locator(plt.MaxNLocator(5))
    ax.annotate("filled squares: n≥25 stratum", xy=(0.01, 0.02),
                xycoords="axes fraction", ha="left",
                fontsize=SJ.BASE_PT - 0.5, color="0.3")
    SJ.panel_letter(ax, "A")

    ax = fig.add_subplot(gs[1, 0])
    tr = d["trends"]
    tr = tr[(tr["threshold"] == PRIMARY_THR) & (tr["stratum"] == "complete12") &
            (tr["metric"] == "length")]
    sig = tr["mk_p"] < 0.05
    ax.scatter(tr.loc[~sig, "n_years"], tr.loc[~sig, "sen_slope_yr"], s=9,
               color="0.78", linewidths=0, label="not significant")
    ax.scatter(tr.loc[sig, "n_years"], tr.loc[sig, "sen_slope_yr"], s=14,
               color=C["vermillion"], linewidths=0, label="p<0.05")
    ax.axhline(0, color="0.4", lw=0.6, ls="--")
    ax.set_xlabel("series length (years)")
    ax.set_ylabel("length slope (months/yr)")
    ax.yaxis.set_major_locator(plt.MaxNLocator(4))
    ax.legend(handletextpad=0.3, loc="upper center", bbox_to_anchor=(0.5, -0.26),
              ncol=2, frameon=True, framealpha=0.95, edgecolor="0.85",
              fontsize=SJ.BASE_PT - 2)
    SJ.panel_letter(ax, "B")

    ax = fig.add_subplot(gs[1, 1])
    w = d["win"]
    w = w[(w["threshold"] == PRIMARY_THR) & (w["complete12"] == 1)]
    for country, col in (("THAILAND", C["navy"]), ("NICARAGUA", C["orange"])):
        sub = w[w["country"] == country].dropna(subset=["length_months"])
        g = sub.groupby("year")["length_months"]
        med = g.median()
        q1, q3 = g.quantile(0.25), g.quantile(0.75)
        ax.fill_between(med.index, q1.reindex(med.index), q3.reindex(med.index),
                        color=col, alpha=0.14, lw=0)
        ax.plot(med.index, med.values, lw=1.0, color=col,
                label=f"{country.title()} ({sub['unit'].nunique()} units)")
    ax.set_xlabel("Year")
    ax.set_ylabel("median length (months)")
    ax.yaxis.set_major_locator(plt.MaxNLocator(4))
    ax.xaxis.set_major_locator(plt.MaxNLocator(4))
    ax.legend(handletextpad=0.3, loc="upper center", bbox_to_anchor=(0.5, -0.26),
              ncol=2, columnspacing=1.2, frameon=True, framealpha=0.95,
              edgecolor="0.85", fontsize=SJ.BASE_PT - 2)
    SJ.panel_letter(ax, "C")

    ax = fig.add_subplot(gs[2, 0])
    _panel_threshold_a(ax, d, letter="D")
    ax = fig.add_subplot(gs[2, 1])
    _panel_threshold_b(ax, d, letter="E")
    SJ.save(fig, str(FIG / "global_fig4_trends"))


def fig5(d):
    fig = plt.figure(figsize=(W1, W1 * 1.15))
    gs = fig.add_gridspec(4, 2, hspace=0.62, wspace=0.30)
    det = d["det"]
    ln = det[(det["metric"] == "length") & (det["n_years"] >= 10)]

    ax = fig.add_subplot(gs[0, :])
    ax.scatter(ln["n_years"], ln["mds80_moyr"], s=11, color=C["blue"],
               alpha=0.6, linewidths=0)
    for tg, ls in zip(TARGETS, [":", "--", "-.", (0, (3, 1, 1, 1))]):
        ax.axhline(tg, color="0.35", lw=0.6, ls=ls)
        ax.annotate(TARGET_LABELS[tg], xy=(0.008, tg),
                    xycoords=("axes fraction", "data"), xytext=(2, 2),
                    textcoords="offset points", fontsize=SJ.BASE_PT - 0.5,
                    color="0.25", ha="left")
    ax.set_yscale("log")
    ax.set_ylim(0.008, 1.8)
    ax.set_xlabel("series length (years)")
    ax.set_ylabel("MDS80 (months/yr)")
    ax.yaxis.set_major_locator(plt.MaxNLocator(4))
    ax.xaxis.set_major_locator(plt.MaxNLocator(6))
    ax.xaxis.set_major_formatter(plt.ScalarFormatter())
    ax.annotate("reference rates: months per decade", xy=(0.995, 0.93),
                xycoords="axes fraction", ha="right",
                fontsize=SJ.BASE_PT - 0.5, color="0.25")
    SJ.panel_letter(ax, "A")

    ax = fig.add_subplot(gs[1, 0])
    rates = np.linspace(0.005, 0.15, 60)
    shares = [float((ln["mds80_moyr"] <= r).mean()) * 100 for r in rates]
    ax.plot(rates * 10, shares, color=C["blue"], lw=1.4)
    ax.fill_between(rates * 10, 0, shares, color=C["blue"], alpha=0.12, lw=0)
    for tg in TARGETS:
        ax.axvline(tg * 10, color="0.55", lw=0.6, ls=":")
        ax.annotate(TARGET_LABELS[tg], xy=(tg * 10, 100), xytext=(2, -3),
                    textcoords="offset points", fontsize=SJ.BASE_PT - 1.5,
                    color="0.4", rotation=90, va="top", ha="left")
    ax.set_xlabel("detectable rate (months/decade)")
    ax.set_ylabel("cumulative % of units")
    ax.set_ylim(0, 104)
    ax.yaxis.set_major_locator(plt.MaxNLocator(4))
    SJ.panel_letter(ax, "B")

    ax = fig.add_subplot(gs[1, 1])
    v = ln["extra_years_target_0.02"].dropna()
    ax.hist(v, bins=np.arange(0, 65, 5), color=C["orange"], edgecolor="white",
            linewidth=0.5)
    med = v.median()
    ax.axvline(med, color=C["vermillion"], lw=1.1, ls="--")
    ax.annotate(f"median {med:.0f} yr", xy=(med, ax.get_ylim()[1] * 0.95),
                xytext=(-5, -2), textcoords="offset points", ha="right",
                color=C["vermillion"])
    ax.set_xlabel("extra years to detect 0.2 mo/decade")
    ax.set_ylabel("number of units")
    ax.yaxis.set_major_locator(plt.MaxNLocator(4))
    ax.xaxis.set_major_locator(plt.MaxNLocator(4))
    SJ.panel_letter(ax, "C")

    ax = fig.add_subplot(gs[2, 0])
    meds = {}
    for m in METRICS:
        g = det[(det["metric"] == m) & (det["n_years"] >= 10)]
        meds[m] = float(g["mds80_moyr"].median())
    ax.bar(range(len(METRICS)), [meds[m] for m in METRICS],
           color=[C["orange"], C["sky"], C["green"], C["purple"]],
           edgecolor="white", linewidth=0.5)
    ax.set_ylim(0, max(meds.values()) * 1.30)
    ax.set_xticks(range(len(METRICS)))
    ax.set_xticklabels([NICE[m] for m in METRICS], rotation=25, ha="right")
    ax.set_ylabel("median MDS80 (months/yr)")
    ax.yaxis.set_major_locator(plt.MaxNLocator(4))
    for i, m in enumerate(METRICS):
        ax.annotate(f"{meds[m]:.2f}", (i, meds[m]), xytext=(0, 2),
                    textcoords="offset points", ha="center",
                    fontsize=SJ.BASE_PT - 1.5)
    SJ.panel_letter(ax, "D")

    ax = fig.add_subplot(gs[2, 1])
    _panel_detmetric(ax, d, which="share", letter="E")
    ax = fig.add_subplot(gs[3, :])
    _panel_detmetric(ax, d, which="years", letter="F")
    SJ.save(fig, str(FIG / "global_fig5_detect"))


def fig3(d):
    wr = d["warm"]
    lat = d["sites"].drop_duplicates("unit")[["unit", "lat"]]
    j = wr.merge(lat, on="unit", how="inner").dropna()

    fig = plt.figure(figsize=(W1, W1 * 0.62))
    gs = fig.add_gridspec(2, 2, hspace=0.48, wspace=0.38)

    ax = fig.add_subplot(gs[0, 0])
    ax.hist(wr["slope_c_per_yr"], bins=40, color=C["blue"], alpha=0.85,
            edgecolor="white", linewidth=0.4)
    med = float(wr["slope_c_per_yr"].median())
    ax.axvline(med, color=C["vermillion"], lw=1.2, ls="--")
    ax.annotate(f"median {med:+.3f}", xy=(0.60, 0.92),
                xycoords="axes fraction", ha="left",
                fontsize=SJ.BASE_PT - 1, color=C["vermillion"])
    ax.set_xlabel("warming rate (°C/yr)")
    ax.set_ylabel("number of units")
    ax.yaxis.set_major_locator(plt.MaxNLocator(4))
    ax.xaxis.set_major_locator(plt.MaxNLocator(4))
    SJ.panel_letter(ax, "A")

    ax = fig.add_subplot(gs[0, 1])
    from matplotlib.lines import Line2D
    rho, pv = stats.spearmanr(j["lat"].abs(), j["slope_c_per_yr"])
    ax.scatter(j["lat"].abs(), j["slope_c_per_yr"], s=8, alpha=0.5,
               color=C["navy"], linewidths=0)
    bins = np.arange(0, 70, 5)
    j2 = j.assign(b=np.clip(np.floor(j["lat"].abs() / 5) * 5 + 2.5, 0, 67))
    bm = j2.groupby("b")["slope_c_per_yr"].median()
    ax.plot(bm.index, bm.values, color=C["vermillion"], lw=1.4)
    handles = [Line2D([0], [0], color=C["vermillion"], lw=1.4,
                      label="5°-band median")]
    leg = ax.legend(handles=handles, loc="upper center",
                    bbox_to_anchor=(0.5, -0.22), fontsize=SJ.BASE_PT - 1,
                    framealpha=0.95, edgecolor="0.85",
                    title=f"Spearman ρ={rho:+.2f} (p={pv:.1e})")
    leg.get_title().set_fontsize(SJ.BASE_PT - 1)
    leg.get_title().set_color("0.25")
    ax.set_xlabel("|latitude| (°)")
    ax.set_ylabel("warming rate (°C/yr)")
    ax.yaxis.set_major_locator(plt.MaxNLocator(4))
    SJ.panel_letter(ax, "B")

    ax = fig.add_subplot(gs[1, 0])
    north = j.loc[j["lat"] >= 0, "slope_c_per_yr"]
    south = j.loc[j["lat"] < 0, "slope_c_per_yr"]
    bp = ax.boxplot([north, south], tick_labels=["north", "south"],
                    widths=0.5, patch_artist=True,
                    medianprops=dict(color="w"))
    for box, col in zip(bp["boxes"], [C["blue"], C["orange"]]):
        box.set_facecolor(col)
        box.set_alpha(0.55)
    ax.set_ylabel("warming rate (°C/yr)")
    ax.yaxis.set_major_locator(plt.MaxNLocator(4))
    SJ.panel_letter(ax, "C")

    ax = fig.add_subplot(gs[1, 1])
    bands = np.arange(0, 65, 5)
    counts = [int(((j["lat"].abs() >= a) & (j["lat"].abs() < a + 5)).sum())
              for a in bands]
    ax.bar([f"{a}-{a+5}" for a in bands], counts, color=C["green"],
           edgecolor="white", linewidth=0.4)
    ax.set_xlabel("|latitude| band (°)")
    ax.set_ylabel("number of units")
    ax.tick_params(axis="x", rotation=45)
    ax.yaxis.set_major_locator(plt.MaxNLocator(4))
    SJ.panel_letter(ax, "D")
    SJ.save(fig, str(FIG / "global_fig3_warming"))


def fig2(d):
    win = d["win"]
    win = win[(win["threshold"] == PRIMARY_THR) & (win["complete12"] == 1)]
    med = (win.dropna(subset=["length_months"])
              .groupby("unit")
              .agg(length=("length_months", "median"),
                   onset=("onset_month", "median"),
                   offset=("offset_month", "median"))
              .reset_index())
    lat = d["sites"].drop_duplicates("unit")[["unit", "lat"]]
    j = med.merge(lat, on="unit", how="inner").dropna()
    south = j["lat"] < 0

    fig = plt.figure(figsize=(W1, W1 * 1.22))
    gs = fig.add_gridspec(3, 2, height_ratios=[1.0, 1.0, 2.05], hspace=0.60,
                          wspace=0.38)

    ax = fig.add_subplot(gs[0, 0])
    from matplotlib.lines import Line2D
    rho, pv = stats.spearmanr(j["lat"].abs(), j["length"])
    ax.scatter(j["lat"].abs(), j["length"], s=9, alpha=0.4, color=C["blue"],
               linewidths=0)
    bx, bm = [], []
    for c0 in np.arange(0, 46, 5):
        m = (j["lat"].abs() >= c0) & (j["lat"].abs() < c0 + 5)
        if m.sum() >= 5:
            bx.append(c0 + 2.5)
            bm.append(np.median(j.loc[m, "length"]))
    ax.plot(bx, bm, color=C["vermillion"], lw=1.6, marker="s", ms=3.5)
    ax.set_xlabel("|latitude| (°)")
    ax.set_ylabel("median length (months)")
    ax.yaxis.set_major_locator(plt.MaxNLocator(4))
    ax.legend(handles=[Line2D([0], [0], color=C["vermillion"], lw=1.6,
                              marker="s", ms=3.5, label="5°-band median")],
              loc="upper center", bbox_to_anchor=(0.5, -0.34),
              fontsize=SJ.BASE_PT - 1, framealpha=0.95, edgecolor="0.85",
              title=f"Spearman ρ={rho:+.2f} (p={pv:.1e})")
    leg = ax.get_legend()
    leg.get_title().set_fontsize(SJ.BASE_PT - 1)
    leg.get_title().set_color("0.25")
    SJ.panel_letter(ax, "A")

    ax = fig.add_subplot(gs[0, 1])
    on_n = np.where(j["onset"] >= 7, j["onset"], j["onset"] + 12)
    ax.scatter(j.loc[~south, "lat"], on_n[~south], s=9, alpha=0.45,
               color=C["blue"], linewidths=0, label="northern")
    on_s = np.where(j["onset"] >= 7, j["onset"] - 12, j["onset"])
    ax.scatter(j.loc[south, "lat"], on_s[south], s=9, alpha=0.45,
               color=C["orange"], linewidths=0, label="southern")
    ax.axhline(12, color="0.7", lw=0.6, ls=":")
    ax.set_xlabel("latitude (°)")
    ax.set_ylabel("onset month (wrapped)")
    ax.set_yticks([3, 6, 9, 12, 15])
    ax.set_yticklabels(["Mar", "Jun", "Sep", "Dec", "Mar(+1)"])
    ax.legend(fontsize=SJ.BASE_PT - 1.5, loc="lower right",
              framealpha=0.95, edgecolor="0.85")
    SJ.panel_letter(ax, "B")

    ax = fig.add_subplot(gs[1, 0])
    north_l = j.loc[~south, "length"]
    south_l = j.loc[south, "length"]
    bp = ax.boxplot([north_l, south_l], tick_labels=["north", "south"],
                    widths=0.5, patch_artist=True,
                    medianprops=dict(color="w"))
    for box, col in zip(bp["boxes"], [C["blue"], C["orange"]]):
        box.set_facecolor(col)
        box.set_alpha(0.55)
    ax.set_ylabel("window length (months)")
    ax.yaxis.set_major_locator(plt.MaxNLocator(4))
    SJ.panel_letter(ax, "C")

    ax = fig.add_subplot(gs[1, 1])
    off_n = np.where(j["offset"] >= 7, j["offset"], j["offset"] + 12)
    off_s = np.where(j["offset"] >= 7, j["offset"] - 12, j["offset"])
    ax.scatter(j.loc[~south, "lat"], off_n[~south], s=9, alpha=0.45,
               color=C["blue"], linewidths=0, label="northern")
    ax.scatter(j.loc[south, "lat"], off_s[south], s=9, alpha=0.45,
               color=C["orange"], linewidths=0, label="southern")
    ax.set_xlabel("latitude (°)")
    ax.set_ylabel("offset month (wrapped)")
    ax.set_yticks([3, 6, 9, 12, 15])
    ax.set_yticklabels(["Mar", "Jun", "Sep", "Dec", "Mar(+1)"])
    ax.legend(fontsize=SJ.BASE_PT - 1.5, loc="upper left",
              framealpha=0.95, edgecolor="0.85")
    SJ.panel_letter(ax, "D")

    ax = fig.add_subplot(gs[2, :])
    _panel_calendar(ax, d, letter="E")
    SJ.save(fig, str(FIG / "global_fig2_structure"))


def fig8(d):
    psi_u = d["psi"][d["psi"]["level"] == "unit"]
    lat = d["sites"].drop_duplicates("unit")[["unit", "lat"]]

    fig = plt.figure(figsize=(W1, W1 * 0.62))
    gs = fig.add_gridspec(2, 2, hspace=0.50, wspace=0.40)

    psi = d["psi"]
    # A: onset psi distribution
    ax = fig.add_subplot(gs[0, 0])
    g = psi_u[(psi_u["metric"] == "onset") &
              (psi_u["temp_metric"] == "annual_mean")]
    ax.hist(g["psi"], bins=30, color=C["blue"], alpha=0.85,
            edgecolor="white", linewidth=0.4)
    pooled = 0.0 if len(g) == 0 else float(psi[(psi["level"] == "pooled_within_unit") & (psi["metric"] == "onset") & (psi["temp_metric"] == "annual_mean")].iloc[0]["psi"])
    ax.axvline(pooled, color=C["vermillion"], lw=1.2, ls="--")
    ax.annotate(f"pooled {pooled:+.2f}", xy=(pooled, ax.get_ylim()[1] * 0.9),
                xytext=(-5, 0), textcoords="offset points",
                color=C["vermillion"], ha="right")
    ax.set_xlabel("ψ onset (months/°C)")
    ax.set_ylabel("number of units")
    ax.yaxis.set_major_locator(plt.MaxNLocator(4))
    SJ.panel_letter(ax, "A")

    # B: length psi distribution
    ax = fig.add_subplot(gs[0, 1])
    g2 = psi_u[(psi_u["metric"] == "length") &
               (psi_u["temp_metric"] == "annual_mean")]
    pooled2 = float(psi[(psi["level"] == "pooled_within_unit") & (psi["metric"] == "length") & (psi["temp_metric"] == "annual_mean")].iloc[0]["psi"])
    ax.hist(g2["psi"], bins=30, color=C["blue"], alpha=0.85,
            edgecolor="white", linewidth=0.4)
    ax.axvline(pooled2, color=C["vermillion"], lw=1.2, ls="--")
    ax.annotate(f"pooled {pooled2:+.2f}", xy=(pooled2, ax.get_ylim()[1] * 0.9),
                xytext=(5, 0), textcoords="offset points",
                color=C["vermillion"], ha="left")
    ax.set_xlabel("ψ length (months/°C)")
    ax.set_ylabel("number of units")
    ax.yaxis.set_major_locator(plt.MaxNLocator(4))
    SJ.panel_letter(ax, "B")

    # C: significant-share bars (labels inside, white; ylim headroom)
    ax = fig.add_subplot(gs[1, 0])
    metrics = ["onset", "offset", "length", "peak"]
    shares, ns = [], []
    for m in metrics:
        g3 = psi_u[(psi_u["metric"] == m) &
                   (psi_u["temp_metric"] == "annual_mean")]
        shares.append(float((g3["p"] < 0.05).mean()) * 100)
        ns.append(len(g3))
    ax.bar(range(len(metrics)), shares, color=C["sky"], edgecolor="white",
           linewidth=0.5)
    ax.set_ylim(0, max(shares) * 1.35)
    ax.set_xticks(range(len(metrics)))
    ax.set_xticklabels([NICE[m] for m in metrics], rotation=25, ha="right")
    ax.set_ylabel("units with p<0.05 (%)")
    ax.yaxis.set_major_locator(plt.MaxNLocator(4))
    for i, (v, n) in enumerate(zip(shares, ns)):
        ax.annotate(f"{v:.0f}% (n={n})", (i, v), xytext=(0, 2),
                    textcoords="offset points", ha="center",
                    fontsize=SJ.BASE_PT - 1.5)
    SJ.panel_letter(ax, "C")

    # D: psi(length) vs |latitude|
    ax = fig.add_subplot(gs[1, 1])
    g4 = psi_u[(psi_u["metric"] == "length") &
               (psi_u["temp_metric"] == "annual_mean")].merge(lat, on="unit",
                                                              how="inner")
    g4 = g4.dropna(subset=["lat"])
    rho, pv = stats.spearmanr(g4["lat"].abs(), g4["psi"])
    ax.scatter(g4["lat"].abs(), g4["psi"], s=10, alpha=0.5, color=C["navy"],
               linewidths=0)
    ax.axhline(0, color="0.4", lw=0.6, ls="--")
    ax.annotate(f"Spearman ρ={rho:+.2f} ({_pfmt(pv)})", xy=(0.97, 0.92),
                xycoords="axes fraction", ha="right",
                fontsize=SJ.BASE_PT - 1.5, color="0.25")
    ax.set_xlabel("|latitude| (°)")
    ax.set_ylabel("ψ length (months/°C)")
    ax.yaxis.set_major_locator(plt.MaxNLocator(4))
    SJ.panel_letter(ax, "D")
    SJ.save(fig, str(FIG / "global_fig8_psi"))


COUNTRY_NAMES = {"LAO PEOPLE'S DEMOCRATIC REPUBLIC": "Laos",
                 "UNITED STATES OF AMERICA": "United States"}


def _panel_calendar(ax, d, letter="A", n_countries=16):
    """Country-level season calendars, drawn on a supplied axes."""
    from matplotlib.patches import Patch
    cov = d["cov"]
    prim = cov[cov["tier"].isin(["A_trend_strong", "B_trend_low_power"])]
    w = d["win"]
    wp = w[(w["threshold"] == PRIMARY_THR) & (w["unit"].isin(prim["unit"]))]
    um = wp.groupby("unit").agg(onset=("onset_month", "median"),
                                offset=("offset_month", "median"),
                                peak=("peak_month", "median")).reset_index()
    cal = prim[["unit", "country"]].merge(um, on="unit", how="inner")
    sites = d["sites"].drop_duplicates("unit")[["unit", "lat"]]
    cal = cal.merge(sites, on="unit", how="left")
    g = cal.groupby("country").agg(n=("unit", "size"), onset=("onset", "median"),
                                   offset=("offset", "median"),
                                   peak=("peak", "median"), lat=("lat", "median"))
    top = g.sort_values("n", ascending=False).head(n_countries).copy()
    top["abslat"] = top["lat"].abs()
    top = top.sort_values(["abslat", "n"], ascending=[False, False])

    for i, (country, row) in enumerate(top.iterrows()):
        on, off, pk = row["onset"], row["offset"], row["peak"]
        if off >= on:
            ax.barh(i, off - on + 1, left=on - 0.5, height=0.62,
                    color=C["navy"], alpha=0.85, edgecolor="white", lw=0.4)
        else:
            ax.barh(i, 12.5 - on, left=on - 0.5, height=0.62,
                    color=C["navy"], alpha=0.85, edgecolor="white", lw=0.4)
            ax.barh(i, off + 0.5, left=0.5, height=0.62,
                    color=C["navy"], alpha=0.85, edgecolor="white", lw=0.4)
        ax.plot(pk, i, "o", ms=3.4, color=C["vermillion"], zorder=3)
    labels = [f"{COUNTRY_NAMES.get(c, c.title())} ({int(r['n'])})"
              for c, r in top.iterrows()]
    ax.set_yticks(range(len(top)))
    ax.set_yticklabels(labels, fontsize=SJ.BASE_PT - 1.5)
    ax.invert_yaxis()
    ax.set_xlim(0.5, 12.5)
    ax.set_xticks(range(1, 13))
    ax.set_xticklabels(list("JFMAMJJASOND"), fontsize=SJ.BASE_PT - 1)
    ax.set_xlabel("month")
    handles = [Patch(facecolor=C["navy"], alpha=0.85, label="median season window"),
               plt.Line2D([0], [0], marker="o", color="none", mfc=C["vermillion"],
                          ms=4, label="median peak month")]
    ax.legend(handles=handles, loc="upper center", bbox_to_anchor=(0.5, -0.16),
              ncol=2, handletextpad=0.4, frameon=False, fontsize=SJ.BASE_PT - 2)
    SJ.panel_letter(ax, letter)


def _panel_detmetric(ax, d, which="share", letter="A"):
    """Detection capability by metric, drawn on a supplied axes.

    which='share'  -> grouped bars of 80%-power shares at four reference rates
    which='years'  -> median extra years for 0.2 mo/decade + never-reach share
    """
    det = d["det"]
    d10 = det[det["n_years"] >= 10]
    if which == "share":
        targets = [0.01, 0.02, 0.05, 0.10]
        tgt_labels = ["0.1", "0.2", "0.5", "1.0"]
        shades = [C["navy"], C["blue"], "#7FB2D9", "#C6DBEF"]
        bw = 0.19
        for j, (tgt, col) in enumerate(zip(targets, shades)):
            shares = [100 * (d10.loc[d10["metric"] == m,
                                    f"R_target_{tgt:g}"] >= 1).mean()
                      for m in METRICS]
            xs = np.arange(len(METRICS)) + (j - 1.5) * bw
            ax.bar(xs, shares, width=bw * 0.92, color=col, edgecolor="white",
                   lw=0.3, label=f"{tgt_labels[j]}")
            for xv, sv in zip(xs, shares):
                if sv >= 0.01:  # label every non-zero bar (disambiguates
                    # the near-invisible low reference rates, e.g. 0.2-mo bars)
                    ax.annotate(f"{sv:.1f}%", (xv, sv), xytext=(0, 1.6),
                                textcoords="offset points", ha="center",
                                fontsize=SJ.BASE_PT - 1.5, color="0.25")
        ax.set_xticks(np.arange(len(METRICS)))
        ax.set_xticklabels([NICE[m] for m in METRICS], fontsize=SJ.BASE_PT - 1)
        ax.set_ylabel("units with 80% power (%)")
        ax.set_ylim(0, 46)
        ax.yaxis.set_major_locator(plt.MaxNLocator(4))
        ax.legend(title="reference rate (months/decade)", loc="upper center",
                  bbox_to_anchor=(0.5, -0.18), ncol=4, handletextpad=0.3,
                  columnspacing=0.9, frameon=False, fontsize=SJ.BASE_PT - 2,
                  title_fontsize=SJ.BASE_PT - 2)
    else:
        meds, nevers = [], []
        for m in METRICS:
            g = d10[d10["metric"] == m]
            meds.append(float(g["extra_years_target_0.02"].median()))
            nevers.append(100 * (1 - g["extra_years_target_0.02"].notna().mean()))
        ax.bar(range(len(METRICS)), meds, width=0.55, color=C["sky"],
               edgecolor="white", lw=0.4)
        for i, (v, nv) in enumerate(zip(meds, nevers)):
            ax.annotate(f"{v:.0f} yr", (i, v), xytext=(0, 2),
                        textcoords="offset points", ha="center",
                        fontsize=SJ.BASE_PT - 2)
            ax.annotate(f"{nv:.0f}% never", (i, v), xytext=(0, 12),
                        textcoords="offset points", ha="center",
                        fontsize=SJ.BASE_PT - 2, color="0.35")
        ax.set_xticks(range(len(METRICS)))
        ax.set_xticklabels([NICE[m] for m in METRICS], fontsize=SJ.BASE_PT - 1)
        ax.set_ylabel("extra years to detect 0.2 mo/decade")
        ax.set_ylim(0, 66)
        ax.yaxis.set_major_locator(plt.MaxNLocator(4))
    SJ.panel_letter(ax, letter)


def _panel_psi_forest(ax, d, letter="A"):
    """Pooled psi forest across metrics and temperature definitions."""
    from matplotlib.lines import Line2D
    pw = d["psi"][d["psi"]["level"] == "pooled_within_unit"]
    defs = [("annual_mean", "annual mean", C["navy"], "o", True),
            ("pre_season_mean", "pre-season mean", C["sky"], "s", False)]

    y = 0
    ypos, ylabels = [], []
    for m in METRICS:
        for tm, lab, col, mk, filled in defs:
            r = pw[(pw["metric"] == m) & (pw["temp_metric"] == tm)]
            if not len(r):
                continue
            r = r.iloc[0]
            lo = r["psi"] - 1.96 * r["se"]
            hi = r["psi"] + 1.96 * r["se"]
            ax.errorbar(r["psi"], y, xerr=[[r["psi"] - lo], [hi - r["psi"]]],
                        fmt=mk, ms=4.5, color=col, capsize=1.6, lw=1.0,
                        mfc=col if filled else "white", mew=1.0)
            ypos.append(y)
            ylabels.append(f"{NICE[m]} · {lab}")
            y += 1
        y += 0.6
    ax.axvline(0, color="0.4", lw=0.6, ls="--")
    ax.set_yticks(ypos)
    ax.set_yticklabels(ylabels, fontsize=SJ.BASE_PT - 1)
    ax.set_ylim(-0.6, y - 0.2)
    ax.invert_yaxis()
    ax.set_xlabel("pooled ψ (months per °C)")
    ax.xaxis.set_major_locator(plt.MaxNLocator(5))
    handles = [Line2D([0], [0], marker="o", color=C["navy"], ms=4.5, lw=1.0,
                      label="annual mean temperature"),
               Line2D([0], [0], marker="s", color=C["sky"], ms=4.5, lw=1.0,
                      mfc="white", label="pre-season mean temperature")]
    ax.legend(handles=handles, loc="upper center", bbox_to_anchor=(0.5, -0.30),
              ncol=2, frameon=False, fontsize=SJ.BASE_PT - 2,
              handletextpad=0.5, columnspacing=1.4)
    SJ.panel_letter(ax, letter)


def _threshold_medians(d):
    """Per-unit median window length under each threshold pair (shared by the
    two threshold-robustness panels)."""
    cov = d["cov"]
    prim = set(cov[cov["tier"].isin(["A_trend_strong", "B_trend_low_power"])]["unit"])
    w = d["win"]
    w = w[w["unit"].isin(prim)].dropna(subset=["length_months"])
    thr = [("(0.01,0.99)", "1–99%", "#C6DBEF"),
           ("(0.05,0.95)", "5–95% (primary)", C["blue"]),
           ("(0.10,0.90)", "10–90%", C["navy"])]
    med = {t: w[w["threshold"] == t].groupby("unit")["length_months"].median()
           for t, _l, _c in thr}
    return thr, med, w


def _panel_threshold_a(ax, d, letter="A"):
    """Distributions of unit-level median window length by threshold pair."""
    thr, med, _w = _threshold_medians(d)
    for t, lab, col in thr:
        ax.hist(med[t], bins=np.arange(0.0, 13.5, 1.0), histtype="stepfilled",
                color=col, alpha=0.55, label=lab)
    ax.set_xlabel("median window length (months)")
    ax.set_ylabel("number of units")
    ax.set_xlim(0, 13)
    ax.yaxis.set_major_locator(plt.MaxNLocator(4))
    ax.legend(loc="upper center", bbox_to_anchor=(0.5, -0.26), ncol=1,
              frameon=False, fontsize=SJ.BASE_PT - 2, labelspacing=0.3)
    SJ.panel_letter(ax, letter)


def _panel_threshold_b(ax, d, letter="B"):
    """Unit-level agreement between the primary and stricter definitions."""
    _thr, med, _w = _threshold_medians(d)
    j = pd.concat([med["(0.05,0.95)"].rename("x"),
                   med["(0.10,0.90)"].rename("y")], axis=1).dropna()
    rng = np.random.default_rng(0)
    ax.scatter(j["x"] + rng.uniform(-0.16, 0.16, len(j)),
               j["y"] + rng.uniform(-0.16, 0.16, len(j)),
               s=7, alpha=0.35, color=C["navy"], linewidths=0)
    lim = 13.2
    ax.plot([0, lim], [0, lim], color="0.5", lw=0.6, ls="--")
    ax.set_xlim(0, lim)
    ax.set_ylim(0, lim)
    rho, _pv = stats.spearmanr(j["x"], j["y"])
    ax.annotate(f"Spearman ρ={rho:+.2f} (n={len(j)})", xy=(0.03, 0.95),
                xycoords="axes fraction", ha="left", va="top",
                fontsize=SJ.BASE_PT - 1.5, color="0.25")
    ax.set_xlabel("median length, 5–95% (months)")
    ax.set_ylabel("median length, 10–90% (months)")
    ax.set_xticks([0, 4, 8, 12])
    ax.set_yticks([0, 4, 8, 12])
    SJ.panel_letter(ax, letter)


def fig7(d):
    it = d["inten"]

    fig = plt.figure(figsize=(W1, W1 * 1.00))
    gs = fig.add_gridspec(3, 2, height_ratios=[1.0, 1.0, 1.30], hspace=0.55,
                          wspace=0.40)

    ax = fig.add_subplot(gs[0, 0])
    xs, ys, los, his = [], [], [], []
    for i, m in enumerate(METRICS):
        g = it[it["metric"] == m]
        pl = _dl(g["slope_logcases"], g["se_logcases"])
        if not pl:
            continue
        xs.append(i)
        ys.append(pl["pooled"])
        los.append(pl["pooled"] - 1.96 * pl["se"])
        his.append(pl["pooled"] + 1.96 * pl["se"])
    ax.errorbar(xs, ys, yerr=[np.array(ys) - np.array(los),
                              np.array(his) - np.array(ys)],
                fmt="s", ms=4.0, capsize=1.6, lw=0.9, color=C["navy"],
                ecolor="0.4")
    ax.axhline(0, color="0.4", lw=0.6, ls="--")
    ax.set_xticks(range(len(METRICS)))
    ax.set_xticklabels([NICE[m] for m in METRICS], rotation=25, ha="right")
    ax.set_ylabel("months per 10× cases")
    ax.yaxis.set_major_locator(plt.MaxNLocator(4))
    SJ.panel_letter(ax, "A")

    ax = fig.add_subplot(gs[0, 1])
    g = it.dropna(subset=["r2_intensity", "r2_temp"])
    ax.scatter(g["r2_temp"], g["r2_intensity"], s=10, alpha=0.35,
               color=C["blue"], linewidths=0)
    lim = max(g["r2_temp"].max(), g["r2_intensity"].max()) * 1.06
    ax.plot([0, lim], [0, lim], color="0.5", lw=0.6, ls="--")
    g_len = it[(it["metric"] == "length")].dropna(subset=["r2_intensity", "r2_temp"])
    frac = float((g_len["r2_intensity"] > g_len["r2_temp"]).mean())
    ax.annotate(f"intensity larger in\n{frac:.0%} of window-length fits",
                xy=(0.97, 0.08), xycoords="axes fraction", ha="right",
                fontsize=SJ.BASE_PT - 0.5, color="0.25")
    ax.set_xlabel("R² temperature")
    ax.set_ylabel("R² intensity")
    SJ.panel_letter(ax, "B")

    ax = fig.add_subplot(gs[1, :])
    w = d["win"]
    w = w[(w["threshold"] == PRIMARY_THR) & (w["complete12"] == 1)].dropna(
        subset=["length_months"])
    dev_x, dev_y = [], []
    for unit, gg in w.groupby("unit"):
        if len(gg) < 10:
            continue
        x = np.log10(gg["annual_cases"].clip(lower=1).to_numpy(float))
        y = gg["length_months"].to_numpy(float)
        dev_x.append(x - x.mean())
        dev_y.append(y - y.mean())
    dx = np.concatenate(dev_x)
    dy = np.concatenate(dev_y)
    hb = ax.hexbin(dx, dy, gridsize=45, cmap="Greys", mincnt=1, linewidths=0)
    cb = fig.colorbar(hb, ax=ax, shrink=0.9, pad=0.01, aspect=18)
    cb.set_label("unit-years", fontsize=SJ.BASE_PT - 0.5)
    cb.ax.tick_params(labelsize=SJ.BASE_PT - 1)
    pooled_el = float(_dl(it[it["metric"] == "length"]["slope_logcases"],
                          it[it["metric"] == "length"]["se_logcases"])["pooled"])
    xs2 = np.linspace(dx.min(), dx.max(), 40)
    b_raw, a_raw, rr, pr, se_raw = stats.linregress(dx, dy)
    ax.plot(xs2, pooled_el * xs2, color=C["vermillion"], lw=1.4)
    ax.axhline(0, color="0.4", lw=0.5, ls="--")
    ax.annotate(f"pooled within-unit elasticity {pooled_el:+.2f} mo per 10x cases",
                xy=(0.99, 0.06), xycoords="axes fraction", ha="right",
                color=C["vermillion"])
    ax.annotate(f"raw pooled slope {b_raw:+.2f} (grey)", xy=(0.01, 0.13),
                xycoords="axes fraction", ha="left", color="0.35")
    ax.set_xlabel(r"$\log_{10}$(cases), unit-demeaned")
    ax.set_ylabel("window length (months), demeaned")
    ax.yaxis.set_major_locator(plt.MaxNLocator(4))
    SJ.panel_letter(ax, "C")

    ax = fig.add_subplot(gs[2, :])
    _panel_psi_forest(ax, d, letter="D")
    SJ.save(fig, str(FIG / "global_fig7_intensity"))


def fig6(d):
    """China flagship case (4 panels)."""
    fig = plt.figure(figsize=(W1, W1 * 0.62))
    gs = fig.add_gridspec(2, 2, hspace=0.48, wspace=0.30,
                          height_ratios=[1.0, 1.0])

    ax = fig.add_subplot(gs[0, 0])
    w = d["cn_windows"]
    w = w[(w["province"] == "全国") & (w["threshold"] == PRIMARY_THR)]
    years_all = list(range(2012, 2025))
    for _, r in w.iterrows():
        y = int(r["year"])
        if y not in years_all or pd.isna(r["onset_month"]):
            continue
        ax.plot([y, y], [r["onset_month"], r["offset_month"]],
                color=C["navy"], lw=4.5, solid_capstyle="butt", zorder=4)
        if not pd.isna(r["peak_month"]):
            ax.scatter(y, r["peak_month"], s=22, color=C["vermillion"],
                       edgecolors="white", linewidths=0.6, zorder=5)
    for y in years_all:
        sub = w[w["year"] == y]
        if sub.empty or pd.isna(sub["onset_month"].iloc[0]):
            ax.axvspan(y - 0.4, y + 0.4, color="0.88", zorder=0.5)
            ax.text(y, 6.6, "no data", rotation=90, ha="center", va="center",
                    fontsize=SJ.BASE_PT - 1.5, color="0.45")
    covid = w[w["note"].str.contains("COVID", na=False)]["year"].unique()
    for y in covid:
        ax.axvspan(y - 0.4, y + 0.4, color=C["grey"], alpha=0.28, zorder=0.6)
    # 2022 carries a degenerate one-month window (onset = offset = October;
    # November-December reporting missing) so no visible bar length is drawn;
    # note it in the free strip above the bars
    sub22 = w[w["year"] == 2022]
    if not sub22.empty and pd.notna(sub22["onset_month"].iloc[0]):
        ax.text(2012.3, 12.6,
                "2022 window = 1 month (Oct),\nNov-Dec reporting missing",
                ha="left", va="top", fontsize=SJ.BASE_PT - 1.5,
                color="0.35", linespacing=1.15)
    ax.set_xlim(2011.4, 2024.6)
    ax.set_xticks(years_all)
    ax.tick_params(axis="x", rotation=45, labelsize=SJ.BASE_PT - 1)
    ax.set_yticks([1, 4, 7, 10, 12])
    ax.set_ylim(0.5, 12.8)
    ax.set_ylabel("month")
    ax.annotate("grey: no monthly data / COVID-disrupted",
                xy=(0.99, 0.02), xycoords="axes fraction", ha="right",
                fontsize=SJ.BASE_PT - 1.5, color="0.35")
    SJ.panel_letter(ax, "A")

    ax = fig.add_subplot(gs[0, 1])
    lag = d["cn_lag"]
    ax.errorbar(lag["lag"], lag["coef"],
                yerr=[lag["coef"] - lag["ci_low"], lag["ci_high"] - lag["coef"]],
                fmt="s", ms=4.5, color=C["navy"], capsize=2.2, lw=1.0,
                ecolor="0.4")
    for _, r in lag.iterrows():
        if r["p"] < 0.05 and r["coef"] > 0:
            lbl = (f"lag{int(r['lag'])} {r['coef']:+.2f} "
                   f"({_pfmt(r['p'])})")
            dx_off, ha = (0, "center")
            if int(r["lag"]) == 2:
                dx_off, ha = 8, "left"
            ax.annotate(lbl, xy=(r["lag"], r["ci_high"]), xytext=(dx_off, 5),
                        textcoords="offset points", ha=ha,
                        fontsize=SJ.BASE_PT - 1.5, color=C["navy"])
    ax.axhline(0, color="0.4", lw=0.6, ls="--")
    ax.set_xticks([0, 1, 2, 3])
    ax.set_xlabel("temperature lag (months)")
    ax.set_ylabel("log-case-rate change per °C")
    ax.set_ylim(-0.75, 0.85)
    ax.annotate("negative binomial, Almon(3), lags 0–3",
                xy=(0.03, 0.05), xycoords="axes fraction",
                fontsize=SJ.BASE_PT - 1.5, color="0.35")
    SJ.panel_letter(ax, "B")

    ax = fig.add_subplot(gs[1, 0])
    loo = d["cn_loo"].sort_values("omitted_year")
    cols = [C["vermillion"] if y == 2014 else C["blue"]
            for y in loo["omitted_year"]]
    ax.scatter(loo["omitted_year"], loo["spring_coef"], c=cols, s=26,
               zorder=3, edgecolors="white", linewidths=0.4)
    for k, (_, r) in enumerate(loo.iterrows()):
        if int(r["omitted_year"]) == 2014:
            dx, dy, ha, va = 7, 0, "left", "center"
        else:
            above = (k % 2 == 0)
            dy, va = (5, "bottom") if above else (-5, "top")
            dx, ha = 0, "center"
        ax.annotate(f"{r['spring_p']:.2f}", (r["omitted_year"],
                    r["spring_coef"]), xytext=(dx, dy),
                    textcoords="offset points", ha=ha, va=va,
                    fontsize=SJ.BASE_PT - 2, color="0.35")
    ax.axhline(0, color="0.4", lw=0.6, ls="--")
    ax.set_xlabel("year omitted from the model")
    ax.set_ylabel("spring-temp coef (months/SD)")
    ax.set_xticks([2008, 2011, 2014, 2017, 2020, 2023])
    ax.annotate("only omitting 2014 reaches significance",
                xy=(0.03, 0.90), xycoords="axes fraction",
                fontsize=SJ.BASE_PT - 1.5, color=C["vermillion"])
    SJ.panel_letter(ax, "C")

    ax = fig.add_subplot(gs[1, 1])
    det = d["det"]
    ln = det[(det["metric"] == "length") & (det["n_years"] >= 10)]
    med = float(ln["mds80_moyr"].median())
    cn_val = float(d["cn_power"][d["cn_power"]["metric"] == "length"]
                   .iloc[0]["mds80_moyr"])
    ax.hist(ln["mds80_moyr"], bins=22, color="0.84", edgecolor="white",
            linewidth=0.4)
    ax.axvline(med, color=C["blue"], lw=1.2, ls="--")
    med_lbl = f"global median {med:.2f}"
    ax.annotate(med_lbl, xy=(med, ax.get_ylim()[1] * 0.62),
                xytext=(4, 0), textcoords="offset points", color=C["blue"],
                ha="left")
    ax.axvline(cn_val, color=C["vermillion"], lw=1.3)
    cn_lbl = "China (MDS80 0.42)"
    ax.annotate(cn_lbl, xy=(cn_val, ax.get_ylim()[1] * 0.90),
                xytext=(6, 0), textcoords="offset points",
                color=C["vermillion"], ha="left")
    ax.set_xlabel("MDS80, window length (months/yr)")
    ax.set_ylabel("number of units")
    ax.yaxis.set_major_locator(plt.MaxNLocator(3))
    ax.xaxis.set_major_locator(plt.MaxNLocator(4))
    SJ.panel_letter(ax, "D")
    SJ.save(fig, str(FIG / "global_fig6_china"))


def main():
    chosen = SJ.set_style()
    print(f"[style] {chosen}, base {SJ.BASE_PT} pt")
    d = load()
    for name, fn in [("fig1", fig1), ("fig2", fig2), ("fig3", fig3),
                     ("fig4", fig4), ("fig5", fig5), ("fig6", fig6),
                     ("fig7", fig7), ("fig8", fig8)]:
        fn(d)
        print(f"[ok] {name}")
    ok = True
    for n in ("global_fig1_coverage", "global_fig2_structure",
              "global_fig3_warming", "global_fig4_trends",
              "global_fig5_detect", "global_fig6_china",
              "global_fig7_intensity", "global_fig8_psi"):
        for ext in (".pdf", ".png", ".tif"):
            p = FIG / (n + ext)
            if not p.is_file() or p.stat().st_size < 5000:
                print(f"[FAIL] missing/small {p}")
                ok = False
    print(f"DONE. ok = {ok}")
    return 0 if ok else 1


if __name__ == "__main__":
    sys.exit(main())
