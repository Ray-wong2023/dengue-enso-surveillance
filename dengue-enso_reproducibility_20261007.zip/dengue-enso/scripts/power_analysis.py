# -*- coding: utf-8 -*-
"""
Revision pass 1: statistical power for the national MK trend tests (n=11).

Addresses simulated-reviewer P1 ("report power / minimum detectable slope
for the n=11 Mann-Kendall tests").

What this script does (main calibration: national, threshold (0.05,0.95),
period 2012-2024, valid window years only):
  1. Vectorised Mann-Kendall test, verified to reproduce the original
     trend_analysis.mann_kendall exactly on the observed series.
  2. Monte-Carlo power curves: for each window metric, simulate series
     y = s * (t - mean(t)) + N(0, SD_obs) on the ACTUAL valid calendar years
     (preserving the 2020 -> 2022 gap), scan true slope s in months/year,
     and estimate power at alpha = 0.05 (two-sided), N_SIM per point with
     common random numbers across slopes.
  3. Minimum detectable slope (MDS) at 80% and 90% power (linear
     interpolation of the power curve), plus the 95% CI of the Theil-Sen
     slope (scipy.stats.theilslopes) for each metric (national main + the
     exploratory Guangdong 1998-2008 onset/length series).
  4. Sample-size sweep: standardised effect (slope in SD units per year,
     equidistant years), power for n = 11..40, and the n needed for 80%
     power per effect size (metric-independent after standardisation).

Inputs (read-only):  data/processed/windows.csv (FROZEN)
Outputs:
  results/power_analysis.csv   per-metric power summary
  results/power_n_sweep.csv    n x effect-size power grid + n80
  figures/fig5_power_curves.png/.pdf  power curves with MDS markers

Assertions: vectorised MK == original MK on observed data; MDS80 <= MDS90;
power curve (nearly) monotone; output rows complete. Failure -> exit(1).
"""
import itertools
import os
import sys

import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
import numpy as np
import pandas as pd
from scipy import stats

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
PROC = os.path.join(ROOT, "data", "processed")
RES = os.path.join(ROOT, "results")
FIG = os.path.join(ROOT, "figures")
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from style_common import COLORS, set_style, save_fig  # noqa: E402

IN_WINDOWS = os.path.join(PROC, "windows.csv")
OUT_POWER = os.path.join(RES, "power_analysis.csv")
OUT_SWEEP = os.path.join(RES, "power_n_sweep.csv")
OUT_FIG = os.path.join(FIG, "fig5_power_curves")

MAIN_PROV = "全国"
MAIN_THR = "(0.05,0.95)"
PERIOD = (2012, 2024)
METRIC_COLS = {
    "onset": "onset_month",
    "offset": "offset_month",
    "length": "length_months",
    "peak": "peak_month",
}
GD_PERIOD = (1998, 2008)          # exploratory Guangdong window
METRICS = ["onset", "offset", "length", "peak"]

ALPHA = 0.05
Z_CRIT = stats.norm.ppf(1 - ALPHA / 2)   # 1.959964
N_SIM = 20_000
SLOPE_GRID = np.round(np.arange(0.0, 0.6001, 0.005), 4)   # months/year
RNG_SEED = 20260905

SWEEP_N = np.arange(11, 41)
SWEEP_DELTAS = [0.10, 0.20, 0.30, 0.50]   # SD per calendar year
N_SWEEP_SIM = 10_000


def mk_pvalue_vec(Y):
    """Vectorised two-sided MK p-values for simulated series.

    Y: (m, n) matrix of m simulated series of n chronologically ordered
    observations. Continuous noise -> no ties, but the tie-corrected
    variance formula is used anyway (reduces to the untied one).
    Returns (m,) p-value array.
    """
    m, n = Y.shape
    diff = Y[:, :, None] - Y[:, None, :]          # y_j - y_i, all pairs
    S = np.sign(np.triu(diff, k=1)).sum(axis=(1, 2))
    var_s = n * (n - 1) * (2 * n + 5) / 18.0
    z = (S - np.sign(S) * 0.5) / np.sqrt(var_s)
    return 2.0 * (1.0 - stats.norm.cdf(np.abs(z)))


def mann_kendall(x):
    """Original scalar MK (mirrors trend_analysis.mann_kendall)."""
    x = np.asarray(x, dtype=float)
    n = len(x)
    s = 0.0
    for i in range(n - 1):
        s += np.sign(x[i + 1:] - x[i]).sum()
    ties = [len(list(g)) for _, g in itertools.groupby(np.sort(x))]
    var_s = (n * (n - 1) * (2 * n + 5) -
             sum(t * (t - 1) * (2 * t + 5) for t in ties)) / 18.0
    if var_s <= 0:
        return (0.0, 1.0)
    z = (s - np.sign(s) * 0.5) / np.sqrt(var_s)
    p = 2.0 * (1.0 - stats.norm.cdf(abs(z)))
    return (s / (n * (n - 1) / 2.0), p)


def load_main_series():
    """National main-calibration valid window years + metrics."""
    w = pd.read_csv(IN_WINDOWS, encoding="utf-8-sig")
    sub = w[(w["province"] == MAIN_PROV) &
            (w["threshold"] == MAIN_THR) &
            w["year"].between(*PERIOD)].sort_values("year")
    sub = sub.dropna(subset=["onset_month"])       # valid window years only
    years = sub["year"].to_numpy(dtype=float)
    data = {m: sub[c].to_numpy(dtype=float)
            for m, c in METRIC_COLS.items()}
    return years, data


def load_gd_series():
    """Guangdong exploratory series 1998-2008 (threshold (0.05,0.95))."""
    w = pd.read_csv(IN_WINDOWS, encoding="utf-8-sig")
    sub = w[(w["province"] == "广东") &
            (w["threshold"] == MAIN_THR) &
            w["year"].between(*GD_PERIOD)].sort_values("year")
    sub = sub.dropna(subset=["onset_month"])
    return (sub["year"].to_numpy(dtype=float),
            {m: sub[c].to_numpy(dtype=float) for m, c in METRIC_COLS.items()})


def power_curve(years, sd_obs, slopes, rng):
    """Monte-Carlo power at each candidate true slope (months/year).

    Common random numbers: one noise matrix reused across slopes.
    """
    t = years - years[0]
    tc = t - t.mean()
    eps = rng.normal(0.0, sd_obs, size=(N_SIM, len(t)))
    power = np.empty(len(slopes))
    for i, s in enumerate(slopes):
        Y = eps + s * tc[None, :]
        p = mk_pvalue_vec(Y)
        power[i] = float((p < ALPHA).mean())
    return power


def interp_reach(slopes, power, target):
    """First slope where power >= target (linear interpolation)."""
    idx = np.argmax(power >= target)
    if power[idx] < target:
        return np.nan
    if idx == 0:
        return float(slopes[0])
    x0, x1 = slopes[idx - 1], slopes[idx]
    y0, y1 = power[idx - 1], power[idx]
    if y1 == y0:
        return float(x1)
    return float(x0 + (target - y0) / (y1 - y0) * (x1 - x0))


def n_sweep(rng):
    """Power(n, delta) for standardised slopes on equidistant years."""
    rows = []
    for n in SWEEP_N:
        t = np.arange(n, dtype=float)
        tc = t - t.mean()
        eps = rng.normal(0.0, 1.0, size=(N_SWEEP_SIM, n))
        for d in SWEEP_DELTAS:
            Y = eps + d * tc[None, :]
            p = mk_pvalue_vec(Y)
            rows.append({"n_years": int(n),
                         "delta_sd_per_year": d,
                         "power": round(float((p < ALPHA).mean()), 4)})
    sweep = pd.DataFrame(rows)
    n80 = []
    for d in SWEEP_DELTAS:
        s = sweep[sweep["delta_sd_per_year"] == d].sort_values("n_years")
        reach = interp_reach(s["n_years"].to_numpy(float),
                             s["power"].to_numpy(float), 0.80)
        n80.append({"delta_sd_per_year": d, "n_for_80pct_power": reach})
    return sweep, pd.DataFrame(n80)


def main():
    rng = np.random.default_rng(RNG_SEED)
    print("=" * 64)
    print("Step 0: input assertions")
    if not os.path.exists(IN_WINDOWS):
        print("[FAIL] missing windows.csv")
        return 1

    print("=" * 64)
    print("Step 1: load national main-calibration series (n valid years)")
    years, data = load_main_series()
    n_obs = len(years)
    span = years[-1] - years[0]
    print(f"  valid window years {int(years[0])}-{int(years[-1])}: "
          f"n={n_obs}, span={span:.0f} calendar years")
    if n_obs != 11:
        print(f"[FAIL] expected n=11 valid window years, got {n_obs}")
        return 1

    print("=" * 64)
    print("Step 2: verify vectorised MK (continuous series) against the")
    print("        original; observed data use the tie-corrected original")
    for k in range(3):
        xs = np.sort(rng.uniform(0, 100, size=11))
        tau0, p0 = mann_kendall(xs)
        pv = mk_pvalue_vec(xs[None, :])[0]
        if abs(pv - p0) > 1e-10:
            print(f"[FAIL] MK mismatch (continuous check {k}): "
                  f"{pv} vs {p0}")
            return 1
    print("  vectorised == original on continuous series (3/3)")
    frozen = {"onset": (-0.0909, 0.71481), "offset": (-0.1091, 0.38450),
              "length": (0.0909, 0.71481), "peak": (0.2182, 0.29381)}
    for m, vals in data.items():
        tau0, p0 = mann_kendall(vals)          # tie-corrected, as in paper
        ft, fp = frozen[m]
        if abs(tau0 - ft) > 5e-5 or abs(p0 - fp) > 5e-5:
            print(f"[FAIL] {m}: observed MK {tau0:.4f}/{p0:.5f} != frozen "
                  f"trends.csv {ft}/{fp}")
            return 1
        print(f"  {m:7s} tau={tau0:+.4f} p={p0:.5f}  == frozen trends.csv OK")

    print("=" * 64)
    print("Step 3: Monte-Carlo power curves + minimum detectable slope")
    rows = []
    curves = {}
    for m in METRICS:
        vals = data[m]
        sd_obs = float(np.std(vals, ddof=1))
        slope_sen, intercept, lo, hi = stats.theilslopes(vals, years,
                                                         alpha=0.95)
        pow_curve = power_curve(years, sd_obs, SLOPE_GRID, rng)
        curves[m] = pow_curve
        mds80 = interp_reach(SLOPE_GRID, pow_curve, 0.80)
        mds90 = interp_reach(SLOPE_GRID, pow_curve, 0.90)
        sen_unit = abs(slope_sen) / sd_obs if sd_obs > 0 else np.nan
        # power at the observed |Sen slope| (interpolate on the grid)
        p_at_sen = (float(np.interp(abs(slope_sen), SLOPE_GRID, pow_curve))
                    if abs(slope_sen) <= SLOPE_GRID[-1] else 1.0)
        rows.append({
            "metric": m,
            "n_years": n_obs,
            "span_years": int(span),
            "sd_obs_months": round(sd_obs, 3),
            "sen_slope_moyr": round(float(slope_sen), 4),
            "sen_ci_lo_moyr": round(float(lo), 4),
            "sen_ci_hi_moyr": round(float(hi), 4),
            "power_at_observed_sen": round(p_at_sen, 3),
            "mds80_moyr": round(mds80, 3),
            "mds90_moyr": round(mds90, 3),
            "mds80_total_span_months": round(mds80 * span, 2),
            "mds80_in_sd_units": round(mds80 / sd_obs, 3),
            "observed_sen_in_sd_units": round(sen_unit, 3),
        })
        print(f"  {m:7s} SD={sd_obs:.3f}  Sen={slope_sen:+.3f} "
              f"[{lo:+.3f},{hi:+.3f}]  MDS80={mds80:.3f} mo/yr "
              f"(= {mds80 * span:.2f} mo over span)  "
              f"power@obs={p_at_sen:.2f}")
    power_df = pd.DataFrame(rows)
    os.makedirs(RES, exist_ok=True)
    power_df.to_csv(OUT_POWER, index=False, encoding="utf-8-sig")
    print(f"[wrote] {OUT_POWER}")

    # Guangdong exploratory CIs (context for the Discussion)
    gd_years, gd = load_gd_series()
    gd_rows = []
    for m in ("onset", "length"):
        vals = gd[m]
        slope_sen, _, lo, hi = stats.theilslopes(vals, gd_years, alpha=0.95)
        gd_rows.append({"series": "Guangdong 1998-2008", "metric": m,
                        "n_years": len(vals),
                        "sen_slope_moyr": round(float(slope_sen), 4),
                        "sen_ci_lo_moyr": round(float(lo), 4),
                        "sen_ci_hi_moyr": round(float(hi), 4)})
    gd_df = pd.DataFrame(gd_rows)
    print("  Guangdong exploratory Sen 95% CI:")
    print(gd_df.to_string(index=False))

    print("=" * 64)
    print("Step 4: sample-size sweep (standardised effect, equidistant yrs)")
    sweep, n80 = n_sweep(rng)
    sweep.to_csv(OUT_SWEEP, index=False, encoding="utf-8-sig")
    print(f"[wrote] {OUT_SWEEP} ({len(sweep)} rows)")
    n80.to_csv(os.path.join(RES, "power_n80.csv"), index=False,
               encoding="utf-8-sig")
    print("[wrote] power_n80.csv")
    print("  years needed for 80% power:")
    print(n80.to_string(index=False))

    print("=" * 64)
    print("Step 5: figure fig5_power_curves")
    set_style()
    fig, axes = plt.subplots(2, 2, figsize=(9.0, 6.6), sharex=True)
    nice = {"onset": "Onset", "offset": "Offset",
            "length": "Length", "peak": "Peak timing"}
    for ax, m, c in zip(axes.ravel(), METRICS, COLORS):
        r = power_df[power_df["metric"] == m].iloc[0]
        ax.axhline(0.80, color="0.55", lw=0.9, ls="--", zorder=1)
        ax.plot(SLOPE_GRID, curves[m], color=c, lw=2.0, zorder=3,
                label="Monte-Carlo power")
        ax.axvline(r["mds80_moyr"], color=c, lw=1.2, ls=":", zorder=2)
        ax.scatter([r["mds80_moyr"]], [0.80], color=c, s=28, zorder=4,
                   edgecolors="white")
        obs = abs(r["sen_slope_moyr"])
        ax.axvline(obs, color="#FF4D4F", lw=1.2, ls="-.", zorder=2)
        ax.annotate(f"80% power: {r['mds80_moyr']:.2f} mo/yr",
                    xy=(r["mds80_moyr"], 0.80),
                    xytext=(r["mds80_moyr"] + 0.02, 0.60), fontsize=8,
                    color=c)
        ax.annotate(f"observed |Sen| = {obs:.2f}",
                    xy=(obs, 0.02), xytext=(obs + 0.02, 0.13),
                    fontsize=8, color="#FF4D4F")
        ax.set_title(f"{nice[m]} (n=11, SD={r['sd_obs_months']:.2f} mo)")
        ax.set_ylim(0, 1.02)
        ax.set_xlim(0, SLOPE_GRID[-1])
    axes[0, 0].set_ylabel("Power")
    axes[1, 0].set_ylabel("Power")
    for ax in axes[1]:
        ax.set_xlabel("True trend (months/year)")
    fig.suptitle("Mann–Kendall power, national window metrics 2012–2024 "
                 "(α=0.05 two-sided, 20,000 simulations per point)",
                 fontsize=10)
    fig.tight_layout(rect=(0, 0, 1, 0.97))
    os.makedirs(FIG, exist_ok=True)
    save_fig(fig, OUT_FIG)
    print(f"[wrote] {OUT_FIG}.png/.pdf")

    print("=" * 64)
    print("Step 6: output assertions")
    ok = True
    if len(power_df) != 4 or power_df.isna().any().any():
        print("[FAIL] power_analysis.csv incomplete or has NaN")
        ok = False
    if not np.all(power_df["mds80_moyr"] <= power_df["mds90_moyr"]):
        print("[FAIL] MDS80 > MDS90 somewhere")
        ok = False
    for m, curve in curves.items():
        dips = np.sum(np.diff(curve) < -0.02)
        if dips > 2:
            print(f"[FAIL] power curve for {m} non-monotone ({dips} dips)")
            ok = False
    if len(sweep) != len(SWEEP_N) * len(SWEEP_DELTAS):
        print("[FAIL] n_sweep grid incomplete")
        ok = False
    if not np.all(n80["n_for_80pct_power"] >= 11):
        print("[FAIL] n80 below current sample — check simulation")
        ok = False
    print(f"\nDONE. ok = {ok}")
    return 0 if ok else 1


if __name__ == "__main__":
    sys.exit(main())
