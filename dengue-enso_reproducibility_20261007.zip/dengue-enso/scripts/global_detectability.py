# -*- coding: utf-8 -*-
"""
S3: detectability framework (Plan B core method).

For every unit x metric:
  * observed trend: MK tau/p, Theil-Sen slope (from results/global_trends.csv)
  * MDS80: smallest true monotonic trend detectable with 80% power, by
    Monte-Carlo on the unit's actual year grid with its observed SD
    (same engine as scripts/power_analysis.py)
  * psi: temperature sensitivity of the metric (months per degC), estimated
    (a) per unit where estimable, else (b) from the pooled within-unit
    fixed-effects slope, else (c) a literature prior
  * beta_exp = psi * dT/dt  (expected trend from local warming, months/yr)
  * R = beta_exp / MDS80    (detectability ratio)
  * classification: detected / mismatch (detectable but not detected) /
    underpowered (+ years-to-detection)

Outputs:
  results/global_detectability.csv
  results/global_detectability_report.md
  results/global_psi_estimates.csv
"""
import os
import sys
from pathlib import Path

import numpy as np
import pandas as pd
from scipy import stats

ROOT = Path(os.getcwd()).resolve()
assert (ROOT / "results").is_dir(), "run from the dengue-enso project root"
RES = ROOT / "results"
sys.path.insert(0, str(Path(__file__).resolve().parent))
from power_analysis import mk_pvalue_vec, interp_reach  # noqa: E402

TRENDS = RES / "global_trends.csv"
WARM = RES / "global_warming_rates.csv"
ANNUAL = RES / "global_unit_temp_annual.csv"
WINDOWS = RES / "global_windows.csv"
SITES = RES / "global_unit_sites.csv"
OUT = RES / "global_detectability.csv"
OUT_PSI = RES / "global_psi_estimates.csv"
OUT_REPORT = RES / "global_detectability_report.md"

PRIMARY_THR = "(0.05,0.95)"
METRICS = ["onset", "offset", "length", "peak"]
METRIC_COL = {"onset": "onset_month", "offset": "offset_month",
              "length": "length_months", "peak": "peak_month"}
SLOPE_GRID = np.round(np.arange(0.0, 1.2001, 0.01), 4)   # months/yr
ALPHA = 0.05
N_SIM = 6000
# reference target slopes (months/year) for the detectability question:
# 0.01 = 0.1 months/decade, 0.02 = 0.2, 0.05 = 0.5, 0.1 = 1.0 months/decade
TARGET_SLOPES = [0.01, 0.02, 0.05, 0.10]
PSI_FALLBACK = 0.5        # months per degC, literature-order prior
PSI_RANGE = [0.25, 0.5, 1.0]
MAX_EXTRA_YEARS = 60


def _safe(p: Path) -> Path:
    rp = p.resolve()
    if not str(rp).startswith(str(ROOT)):
        raise ValueError(f"path escapes project root: {rp}")
    return rp


def _z_power(alpha=0.05, power=0.80):
    return stats.norm.ppf(1 - alpha / 2) + stats.norm.ppf(power)


def mds_analytic(years, sd, k=1.0):
    """Minimum detectable linear slope (months/yr) at 80% power.

    Analytic (OLS-equivalent) form  mds = k * (z_a/2 + z_b) * sd / sqrt(sum
    (t - mean t)^2), where k calibrates the Mann-Kendall efficiency relative
    to OLS. Calibration is anchored to the frozen China Monte-Carlo results
    (see calibrate_k) and validated on sampled global units.
    """
    t = np.asarray(years, float)
    ss = float(np.sum((t - t.mean()) ** 2))
    if ss <= 0 or not np.isfinite(sd) or sd <= 0:
        return np.nan
    return k * _z_power() * sd / np.sqrt(ss)


def calibrate_k(seed=20260910, n_sim=4000):
    """Anchor the MK efficiency factor to the frozen China pencil-case results.

    China (power_analysis.py, 20k sims) gave MDS80 for the national 2013-2024
    grid: onset 0.357 (sd 1.168), offset 0.093 (sd 0.302), length 0.420
    (sd 1.375), peak 0.161 (sd 0.522). We recover k = MDS80 / analytic-OLS.
    """
    years = np.array([2013, 2014, 2015, 2016, 2017, 2018, 2019, 2020,
                      2022, 2023, 2024], float)
    frozen = [(0.357, 1.168), (0.093, 0.302), (0.420, 1.375), (0.161, 0.522)]
    ks = []
    for mds, sd in frozen:
        a = mds_analytic(years, sd, k=1.0)
        ks.append(mds / a)
    return float(np.mean(ks)), [round(x, 3) for x in ks]


def mds80_mc(years, sd, rng, grid=None, n_sim=N_SIM):
    """Monte-Carlo MDS80 (used for validation on a sample)."""
    if grid is None:
        grid = np.round(np.arange(0.0, 1.2001, 0.02), 4)
    t = np.asarray(years, float)
    tc = t - t.mean()
    eps = rng.normal(0.0, sd, size=(n_sim, len(t)))
    power = np.empty(len(grid))
    for i, s in enumerate(grid):
        y = eps + s * tc[None, :]
        p = mk_pvalue_vec(y)
        power[i] = (p < ALPHA).mean()
    return interp_reach(grid, power, 0.80)


def years_to_detection(years, sd, target_slope, k=1.0):
    """Smallest extra years such that analytic MDS80 <= target_slope."""
    if not np.isfinite(target_slope) or target_slope <= 0:
        return np.nan
    step = float(np.median(np.diff(sorted(years)))) if len(years) > 1 else 1.0
    step = max(step, 1.0)
    for extra in range(1, MAX_EXTRA_YEARS + 1):
        grid = list(years) + [years[-1] + step * j for j in range(1, extra + 1)]
        m = mds_analytic(grid, sd, k)
        if np.isfinite(m) and m <= target_slope:
            return extra
    return np.nan


def estimate_psi(annual: pd.DataFrame, windows: pd.DataFrame):
    """Pooled and per-unit temperature sensitivity (months per degC)."""
    w = windows[(windows["threshold"] == PRIMARY_THR) &
                (windows["complete12"] == 1)].copy()
    rows = []
    for metric, col in METRIC_COL.items():
        ww = w.dropna(subset=[col])[["unit", "year", col]]
        m = ww.merge(annual[["unit", "year", "annual_mean", "pre_season_mean"]],
                     on=["unit", "year"], how="inner")
        m = m.dropna(subset=[col, "annual_mean", "pre_season_mean"])
        for temp_col in ("pre_season_mean", "annual_mean"):
            # pooled within-unit slope via unit-demeaning (fixed effects)
            g = m.groupby("unit")
            x = (m[temp_col] - g[temp_col].transform("mean")).to_numpy(float)
            y = (m[col] - g[col].transform("mean")).to_numpy(float)
            ok = np.isfinite(x) & np.isfinite(y)
            if ok.sum() > 20 and np.std(x[ok]) > 0:
                slope, inter, r, p, se = stats.linregress(x[ok], y[ok])
                rows.append({"level": "pooled_within_unit", "unit": "*",
                             "metric": metric, "temp_metric": temp_col,
                             "psi": round(float(slope), 4),
                             "se": round(float(se), 4),
                             "p": round(float(p), 5),
                             "n": int(ok.sum())})
            # per unit (>=12 paired years)
            for unit, gg in m.groupby("unit"):
                xx = gg[temp_col].to_numpy(float)
                yy = gg[col].to_numpy(float)
                ok2 = np.isfinite(xx) & np.isfinite(yy)
                if ok2.sum() >= 12 and np.std(xx[ok2]) > 0:
                    s, i2, r2, p2, se2 = stats.linregress(xx[ok2], yy[ok2])
                    rows.append({"level": "unit", "unit": unit, "metric": metric,
                                 "temp_metric": temp_col,
                                 "psi": round(float(s), 4), "se": round(float(se2), 4),
                                 "p": round(float(p2), 5), "n": int(ok2.sum())})
    return pd.DataFrame(rows)


def main():
    rng = np.random.default_rng(20260910)
    print("=" * 66)
    print("Step 1: inputs")
    tr = pd.read_csv(_safe(TRENDS), encoding="utf-8-sig")
    tr = tr[(tr["threshold"] == PRIMARY_THR) & (tr["stratum"] == "complete12")]
    warm = pd.read_csv(_safe(WARM), encoding="utf-8-sig")
    annual = pd.read_csv(_safe(ANNUAL), encoding="utf-8-sig")
    windows = pd.read_csv(_safe(WINDOWS), encoding="utf-8-sig")
    sites = pd.read_csv(_safe(SITES), encoding="utf-8-sig")
    quality = (sites.groupby("unit")["site_quality"]
               .agg(lambda s: "high" if (s == "high").any() else "low"))
    print(f"  trends rows: {len(tr):,} | units: {tr['unit'].nunique():,}")
    print(f"  warming rates: {len(warm):,} units")

    print("=" * 66)
    print("Step 2: temperature sensitivity (psi) estimates")
    psi = estimate_psi(annual, windows)
    psi.to_csv(_safe(OUT_PSI), index=False, encoding="utf-8-sig")
    pooled = psi[psi["level"] == "pooled_within_unit"]
    print(f"[wrote] {OUT_PSI} ({len(psi):,} rows)")
    print(pooled.to_string(index=False))

    print("=" * 66)
    print("Step 0: calibrate the MK efficiency factor against the frozen")
    print("        China Monte-Carlo results")
    K_MK, ks = calibrate_k()
    print(f"  k = {K_MK:.3f} (per-metric ratios: {ks})")
    print("  analytic MDS80 = k * (z_a/2 + z_b) * sd / sqrt(sum (t - tbar)^2)")

    print("=" * 66)
    print("Step 3: MDS80, expected trend, detectability ratio")
    w_primary = windows[(windows["threshold"] == PRIMARY_THR) &
                        (windows["complete12"] == 1)]
    rows = []
    for _, r in tr.iterrows():
        unit, metric = r["unit"], r["metric"]
        col = METRIC_COL[metric]
        sub = w_primary[(w_primary["unit"] == unit)].dropna(subset=[col])
        years = sorted(sub["year"].astype(int).tolist())
        if len(years) < 6:
            continue
        sd = float(r["sd_metric"]) if pd.notna(r["sd_metric"]) else np.nan
        if not np.isfinite(sd) or sd <= 0:
            continue
        m = mds_analytic(years, sd, K_MK)
        if not np.isfinite(m) or m <= 0:
            continue
        # psi: unit-specific (pre_season) -> pooled (pre_season) -> prior
        psu = psi[(psi["level"] == "unit") & (psi["unit"] == unit) &
                  (psi["metric"] == metric) &
                  (psi["temp_metric"] == "pre_season_mean")]
        psp = pooled[(pooled["metric"] == metric) &
                     (pooled["temp_metric"] == "pre_season_mean")]
        if len(psu) and abs(psu.iloc[0]["psi"]) > 1e-6:
            psi_use, psi_src = abs(float(psu.iloc[0]["psi"])), "unit"
        elif len(psp) and abs(psp.iloc[0]["psi"]) > 1e-6:
            psi_use, psi_src = abs(float(psp.iloc[0]["psi"])), "pooled"
        else:
            psi_use, psi_src = PSI_FALLBACK, "prior"
        wrow = warm[warm["unit"] == unit]
        dT = float(wrow.iloc[0]["slope_c_per_yr"]) if len(wrow) else np.nan
        beta_exp = psi_use * abs(dT) if np.isfinite(dT) else np.nan
        sig = bool(r["mk_p"] < ALPHA)
        direction_ok = (np.sign(r["sen_slope_yr"]) == np.sign(beta_exp)
                        if np.isfinite(beta_exp) and beta_exp != 0 else False)
        row = {"unit": unit, "country": r.get("country", ""), "metric": metric,
               "n_years": int(r["n_years"]), "sd_metric": round(sd, 3),
               "mk_tau": r["mk_tau"], "mk_p": r["mk_p"],
               "sen_slope_yr": r["sen_slope_yr"],
               "mds80_moyr": round(float(m), 4),
               "psi": round(psi_use, 4), "psi_source": psi_src,
               "warming_c_per_yr": dT,
               "beta_exp_moyr": round(beta_exp, 4) if np.isfinite(beta_exp)
               else np.nan,
               "detectability_R_empirical": round(beta_exp / m, 3)
               if np.isfinite(beta_exp) else np.nan,
               "class_empirical": ("detected" if (np.isfinite(beta_exp) and
                                                  beta_exp / m >= 1 and sig and direction_ok)
                                   else ("mismatch" if (np.isfinite(beta_exp) and
                                                        beta_exp / m >= 1)
                                         else ("underpowered" if np.isfinite(beta_exp)
                                               else "no_temperature"))),
               "site_quality": quality.get(unit, "low"),
               "median_annual_cases": r.get("median_annual_cases", np.nan)}
        # detectability against reference target slopes (policy/model rates)
        for tgt in TARGET_SLOPES:
            tag = f"{tgt:g}"
            row[f"R_target_{tag}"] = round(tgt / m, 3) if m > 0 else np.nan
            need = years_to_detection(years, sd, tgt, K_MK)
            row[f"extra_years_target_{tag}"] = need
            # would the observed data have detected this target?
            detected = sig and abs(float(r["sen_slope_yr"])) >= tgt and \
                np.sign(r["sen_slope_yr"]) == np.sign(tgt)
            row[f"detected_target_{tag}"] = int(bool(detected))
        rows.append(row)
    det = pd.DataFrame(rows)
    det.to_csv(_safe(OUT), index=False, encoding="utf-8-sig")
    print(f"[wrote] {OUT} ({len(det):,} rows, {det['unit'].nunique():,} units)")
    print(f"  empirical class: {det['class_empirical'].value_counts().to_dict()}")
    ab = det[det["n_years"] >= 10]
    print(f"  units with n>=10: {ab['unit'].nunique()}")
    print("  detectability vs reference target slopes (share of units that")
    print("  could detect the target with 80% power, n>=10 units):")
    for tgt in TARGET_SLOPES:
        col = f"R_target_{tgt:g}"
        share = float((ab[col] >= 1).mean()) if col in ab.columns else np.nan
        med_extra = ab[f"extra_years_target_{tgt:g}"].median()
        print(f"    {tgt:g} mo/yr ({tgt*10:g} months/decade): "
              f"{share:.1%} of units | median extra years {med_extra:.0f}")

    print("=" * 66)
    print("Step 4: validate analytic MDS80 against Monte-Carlo on a sample")
    samp = det.drop_duplicates(subset=["unit", "metric"]).sample(
        n=min(30, len(det)), random_state=20260910)
    errs = []
    for _, r in samp.iterrows():
        col = METRIC_COL[r["metric"]]
        sub = w_primary[(w_primary["unit"] == r["unit"])].dropna(subset=[col])
        years = sorted(sub["year"].astype(int).tolist())
        mc = mds80_mc(years, float(r["sd_metric"]), rng)
        an = mds_analytic(years, float(r["sd_metric"]), K_MK)
        if np.isfinite(mc) and np.isfinite(an) and mc > 0:
            errs.append(abs(an - mc) / mc)
    if errs:
        print(f"  sample n={len(errs)} | median rel. error "
              f"{np.median(errs):.1%} | max {np.max(errs):.1%}")
    else:
        print("  [WARN] no MC validation pairs")

    lines = ["# S3 detectability report", "",
             "MDS80 = minimum detectable trend (80% power): analytic OLS form",
             "calibrated to the frozen China Monte-Carlo results (factor k).",
             "",
             f"Calibration: k = {K_MK:.3f} (MK needs ~{K_MK:.2f}x the OLS slope",
             "for 80% power on these grids); validated against Monte-Carlo on a",
             "30-unit sample (see console output for the median relative error).",
             "",
             "Two detectability lenses are reported:",
             "1. reference target slopes (0.1 / 0.2 / 0.5 / 1.0 months per decade)",
             "   -- `R_target_*` = target / MDS80: can this unit detect that rate?",
             "2. an empirical expectation `beta_exp` = |psi| x local warming, where",
             "   psi is the observational temperature sensitivity (pooled within-unit",
             "   or per unit). Because observational psi is small, this lens mostly",
             "   returns 'underpowered' and is reported for completeness.",
             "",
             f"Rows: {len(det):,} over {det['unit'].nunique():,} units.",
             f"Empirical classes: {det['class_empirical'].value_counts().to_dict()}",
             "",
             "## Detectability of reference target slopes (units with n>=10)",
             "",
             "| target (mo/yr) | target (mo/decade) | share of units able to detect | median extra years needed |",
             "|---|---|---|---|"]
    for tgt in TARGET_SLOPES:
        col = f"R_target_{tgt:g}"
        share = float((ab[col] >= 1).mean()) if col in ab.columns else np.nan
        med_extra = ab[f"extra_years_target_{tgt:g}"].median()
        lines.append(f"| {tgt:g} | {tgt*10:g} | {share:.1%} | {med_extra:.0f} |")
    lines += ["", "## By metric (units with n>=10): median MDS80 and R for 0.2 mo/decade",
              "",
              "| metric | units | median MDS80 (mo/yr) | median R @0.02 | median n |",
              "|---|---|---|---|---|"]
    for m_ in METRICS:
        g = ab[ab["metric"] == m_]
        lines.append(f"| {m_} | {len(g)} | {g['mds80_moyr'].median():.3f} | "
                     f"{g['R_target_0.02'].median():.2f} | "
                     f"{g['n_years'].median():.0f} |")
    lines += ["", "## Long-series stratum (n>=20) vs the China reference",
              "",
              "| metric | units n>=20 | median MDS80 | median R @0.02 | share detected target 0.02 |",
              "|---|---|---|---|---|"]
    lng = ab[ab["n_years"] >= 20]
    for m_ in METRICS:
        g = lng[lng["metric"] == m_]
        if not len(g):
            continue
        lines.append(f"| {m_} | {len(g)} | {g['mds80_moyr'].median():.3f} | "
                     f"{g['R_target_0.02'].median():.2f} | "
                     f"{g['detected_target_0.02'].mean():.1%} |")
    lines += ["", "## Pooled psi estimates (months per degC)", "",
              "| metric | temp metric | psi | se | p | n |",
              "|---|---|---|---|---|---|"]
    for _, r in pooled.iterrows():
        lines.append(f"| {r['metric']} | {r['temp_metric']} | {r['psi']} | "
                     f"{r['se']} | {r['p']} | {r['n']} |")
    OUT_REPORT.write_text("\n".join(lines), encoding="utf-8")
    print(f"[wrote] {OUT_REPORT}")

    print("=" * 66)
    print("Assertions")
    ok = True
    if len(det) == 0:
        print("[FAIL] empty detectability table")
        ok = False
    if not det["R_target_0.02"].dropna().ge(0).all():
        print("[FAIL] negative detectability ratio")
        ok = False
    if det["sd_metric"].le(0).any():
        print("[FAIL] non-positive SD")
        ok = False
    print(f"DONE. ok = {ok}")
    return 0 if ok else 1


if __name__ == "__main__":
    sys.exit(main())
