# -*- coding: utf-8 -*-
"""
S3: global trend tests on season-window metrics (Plan B).

Generalises the frozen China trend engine (scripts/trend_analysis.py:
tie-corrected Mann-Kendall, Theil-Sen slope, segmented-regression breakpoint)
to every admin unit in results/global_windows.csv.

Primary stratum: complete 12-month years (complete12 == 1).
Sensitivity strata: 10-11 month years included (all_missing_allowed) and
threshold interchange to (0.01,0.99) / (0.10,0.90).

Per unit x threshold x metric x period we report MK tau/p, Sen slope,
breakpoint (nominal + permutation-calibrated p, 2,000 permutations by default
for the global run; the China module used 5,000), n_years, span, and the
within-series SD used later by the detectability module.

Outputs:
  results/global_trends.csv          unit-level trend table (primary stratum)
  results/global_trends_sens.csv     threshold/gap sensitivity variants
  results/global_trends_meta.json    run metadata

Usage (from project root):
    python scripts/global_trend_analysis.py [--per-perm 2000] [--min-years 6]
"""
import json
import os
import sys
from pathlib import Path

import numpy as np
import pandas as pd

sys.path.insert(0, str(Path(__file__).resolve().parent))
from trend_analysis import mann_kendall, sen_slope, breakpoint_test  # noqa: E402

ROOT = Path(os.getcwd()).resolve()
assert (ROOT / "results").is_dir(), "run from the dengue-enso project root"
RES = ROOT / "results"
PROC = ROOT / "data" / "processed"

IN_WINDOWS = RES / "global_windows.csv"
OUT_TRENDS = RES / "global_trends.csv"
OUT_SENS = RES / "global_trends_sens.csv"
OUT_META = RES / "global_trends_meta.json"

METRIC_COLS = {"onset": "onset_month", "offset": "offset_month",
               "length": "length_months", "peak": "peak_month"}
PRIMARY_THR = "(0.05,0.95)"
SENS_THRESHOLDS = ["(0.01,0.99)", "(0.10,0.90)"]
MIN_YEARS = 6


def _safe(p: Path) -> Path:
    rp = p.resolve()
    if not str(rp).startswith(str(ROOT)):
        raise ValueError(f"path escapes project root: {rp}")
    return rp


def breakpoint_f(x, y):
    """Segmented-scan F statistic (same construction as the China module)."""
    x = np.asarray(x, float)
    y = np.asarray(y, float)
    n = len(x)
    A = np.vstack([x, np.ones_like(x)]).T
    coef, _, _, _ = np.linalg.lstsq(A, y, rcond=None)
    rss_single = float(((y - A @ coef) ** 2).sum())
    best_k, best_rss = None, np.inf
    for k in range(2, n - 1):
        rss = 0.0
        for lo, hi in ((0, k), (k, n)):
            xs, ys = x[lo:hi], y[lo:hi]
            B = np.vstack([xs, np.ones_like(xs)]).T
            c, _, _, _ = np.linalg.lstsq(B, ys, rcond=None)
            rss += float(((ys - B @ c) ** 2).sum())
        if rss < best_rss:
            best_rss, best_k = rss, k
    if best_rss <= 0 or n < 5:
        return best_k, np.nan
    return best_k, float(((rss_single - best_rss) / 2) / (best_rss / (n - 4)))


def safe_breakpoint(x, y):
    """breakpoint_test with a guard for degenerate (perfect-fit) small samples."""
    try:
        return breakpoint_test(x, y)
    except ZeroDivisionError:
        return (np.nan, np.nan)


def analyse_series(years, vals, metric, rng=None, n_perm=0):
    """MK + Sen + (optionally permutation-calibrated) breakpoint."""
    tau, p = mann_kendall(vals)
    slope = sen_slope(years, vals)
    bp_year, bp_p = safe_breakpoint(years, vals)
    bp_perm_p = np.nan
    if n_perm and len(years) >= 6 and rng is not None:
        _, obs_f = breakpoint_f(years, vals)
        if np.isfinite(obs_f):
            cnt = 0
            for _ in range(n_perm):
                _, f = breakpoint_f(years, rng.permutation(vals))
                if f >= obs_f:
                    cnt += 1
            bp_perm_p = (1.0 + cnt) / (1.0 + n_perm)
    return {
        "mk_tau": round(float(tau), 4), "mk_p": round(float(p), 5),
        "sen_slope_yr": round(float(slope), 4),
        "sd_metric": round(float(np.std(vals, ddof=1)), 4) if len(vals) > 1 else np.nan,
        "breakpoint_year": bp_year, "breakpoint_p": bp_p,
        "breakpoint_perm_p": bp_perm_p,
        "n_years": len(vals),
        "first_year": int(years[0]), "last_year": int(years[-1]),
        "span_years": int(years[-1] - years[0]),
    }


def build_rows(w, threshold, stratum, min_years, rng, n_perm):
    sub = w[w["threshold"] == threshold]
    if stratum == "complete12":
        sub = sub[sub["complete12"] == 1]
    elif stratum == "ge10m":
        sub = sub[sub["n_months"] >= 10]
    rows = []
    for unit, g in sub.groupby("unit", sort=False):
        for metric, col in METRIC_COLS.items():
            s = g.dropna(subset=[col]).sort_values("year")
            if len(s) < min_years:
                continue
            r = analyse_series(s["year"].to_numpy(float),
                               s[col].to_numpy(float), metric, rng, n_perm)
            r.update({"unit": unit,
                      "country": g["country"].iloc[0] if "country" in g.columns else "",
                      "threshold": threshold, "stratum": stratum, "metric": metric,
                      "median_annual_cases": float(np.nanmedian(s["annual_cases"]))})
            rows.append(r)
    return rows


def main():
    n_perm = 2000
    min_years = MIN_YEARS
    for i, a in enumerate(sys.argv):
        if a == "--per-perm":
            n_perm = int(sys.argv[i + 1])
        if a == "--min-years":
            min_years = int(sys.argv[i + 1])
    rng = np.random.default_rng(20260910)

    print("=" * 66)
    print(f"Step 1: load global windows (min_years={min_years}, n_perm={n_perm})")
    if not IN_WINDOWS.exists():
        print(f"[FAIL] missing {IN_WINDOWS}")
        return 1
    w = pd.read_csv(_safe(IN_WINDOWS), encoding="utf-8-sig")
    w = w[w["threshold"] != "all"].copy()
    for c in METRIC_COLS.values():
        w[c] = pd.to_numeric(w[c], errors="coerce")
    units = w["unit"].nunique()
    print(f"  rows {len(w):,} | units {units:,}")

    print("=" * 66)
    print("Step 2: primary stratum (12-month years, threshold 5-95%)")
    rows = build_rows(w, PRIMARY_THR, "complete12", min_years, rng, n_perm)
    tr = pd.DataFrame(rows)
    if tr.empty:
        print("[FAIL] no unit reached the minimum series length")
        return 1
    tr.to_csv(OUT_TRENDS, index=False, encoding="utf-8-sig")
    print(f"[wrote] {OUT_TRENDS} ({len(tr):,} rows, {tr['unit'].nunique():,} units)")
    for m in METRIC_COLS:
        g = tr[tr["metric"] == m]
        print(f"  {m:7s}: {len(g):,} units, "
              f"{int((g['mk_p'] < 0.05).sum())} significant at p<0.05, "
              f"median n={int(g['n_years'].median())}, "
              f"median tau={g['mk_tau'].median():+.3f}")

    print("=" * 66)
    print("Step 3: sensitivity strata (10-11 month years; other thresholds)")
    sens = []
    sens += build_rows(w, PRIMARY_THR, "ge10m", min_years, None, 0)
    for thr in SENS_THRESHOLDS:
        sens += build_rows(w, thr, "complete12", min_years, None, 0)
    ss = pd.DataFrame(sens)
    ss.to_csv(OUT_SENS, index=False, encoding="utf-8-sig")
    print(f"[wrote] {OUT_SENS} ({len(ss):,} rows)")

    meta = {"min_years": min_years, "n_perm": n_perm,
            "primary_threshold": PRIMARY_THR,
            "units_primary": int(tr["unit"].nunique()),
            "rows_primary": int(len(tr)),
            "sig_length_primary": int(((tr["metric"] == "length") &
                                       (tr["mk_p"] < 0.05)).sum()),
            "sig_onset_primary": int(((tr["metric"] == "onset") &
                                      (tr["mk_p"] < 0.05)).sum()),
            "sig_peak_primary": int(((tr["metric"] == "peak") &
                                     (tr["mk_p"] < 0.05)).sum())}
    OUT_META.write_text(json.dumps(meta, indent=2, ensure_ascii=False),
                        encoding="utf-8")
    print(f"[wrote] {OUT_META}")

    print("=" * 66)
    print("Assertions")
    ok = True
    if not tr["mk_p"].between(0, 1).all():
        print("[FAIL] mk_p out of range")
        ok = False
    if not tr["mk_tau"].between(-1, 1).all():
        print("[FAIL] tau out of range")
        ok = False
    if (tr["n_years"] < min_years).any():
        print("[FAIL] short series slipped through")
        ok = False
    print(f"DONE. ok = {ok}")
    return 0 if ok else 1


if __name__ == "__main__":
    sys.exit(main())
